/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FilterState, LibraryScope, WorkspaceTab } from '../types';
import {
  Search,
  Sparkles,
  ChevronDown,
  Mic,
  LayoutGrid,
  GalleryHorizontalEnd,
  Sun,
  Moon,
  Plus,
  GitCompare,
  AudioLines,
  Gamepad2,
  Library,
  Heart,
  FolderOpen,
  Wand2,
  Users,
} from 'lucide-react';

interface FilterBarProps {
  workspaceTab: WorkspaceTab;
  onWorkspaceTabChange: (tab: WorkspaceTab) => void;
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  uniqueGenders: string[];
  uniquePitches: string[];
  favoritesCount: number;
  customCount: number;
  importedFilesCount?: number;
  onOpenAiCasting: () => void;
  onOpenVoiceCreator: () => void;
  onOpenCompare: () => void;
  compareCount: number;
  viewMode: 'carousel' | 'grid';
  onViewModeChange: (mode: 'carousel' | 'grid') => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const FilterBar: React.FC<FilterBarProps> = ({
  workspaceTab,
  onWorkspaceTabChange,
  filters,
  onFilterChange,
  uniqueGenders,
  uniquePitches,
  favoritesCount,
  customCount,
  importedFilesCount = 0,
  onOpenAiCasting,
  onOpenVoiceCreator,
  onOpenCompare,
  compareCount,
  viewMode,
  onViewModeChange,
  isDarkMode,
  toggleTheme,
}) => {
  const handleScopeChange = (libraryScope: LibraryScope) => {
    onFilterChange({ ...filters, libraryScope });
  };

  return (
    <header className="relative z-50 w-full bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl border-b border-zinc-200 dark:border-zinc-800 transition-colors shrink-0">
      {/* Primary Top Bar */}
      <div className="max-w-[1800px] mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Left: Brand + Workspace Tabs (Desktop) */}
        <div className="flex items-center gap-3 sm:gap-5 min-w-0">
          <div className="flex items-center gap-2.5 select-none shrink-0">
            <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center shadow-sm shrink-0">
              <Mic size={18} className="text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-zinc-900 dark:text-white whitespace-nowrap truncate">
                AI Voice Studio
              </h1>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl border border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={() => onWorkspaceTabChange('library')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'library'
                  ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Library size={14} />
              <span>Voice Library</span>
            </button>

            <button
              type="button"
              onClick={() => onWorkspaceTabChange('design')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'design'
                  ? 'bg-white dark:bg-indigo-600 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Wand2 size={14} />
              <span>Voice Design</span>
            </button>

            <button
              type="button"
              onClick={() => onWorkspaceTabChange('conversation')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'conversation'
                  ? 'bg-white dark:bg-indigo-600 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Users size={14} />
              <span>Conversations</span>
            </button>

            <button
              type="button"
              onClick={() => onWorkspaceTabChange('studio')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'studio'
                  ? 'bg-white dark:bg-indigo-600 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <AudioLines size={14} />
              <span>Audio Studio</span>
            </button>

            <button
              type="button"
              onClick={() => onWorkspaceTabChange('gaming')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'gaming'
                  ? 'bg-white dark:bg-emerald-600 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Gamepad2 size={14} />
              <span>Gaming Mode</span>
            </button>

            <button
              type="button"
              onClick={() => onWorkspaceTabChange('files')}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                workspaceTab === 'files'
                  ? 'bg-white dark:bg-teal-600 text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <FolderOpen size={14} />
              <span>Files</span>
              {importedFilesCount > 0 && (
                <span className="font-mono tabular-nums text-[11px] opacity-80">
                  {importedFilesCount}
                </span>
              )}
            </button>
          </nav>
        </div>

        {/* Right: Primary Studio Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenVoiceCreator}
            className="min-h-[40px] flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 bg-zinc-100 dark:bg-zinc-900 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            <Plus size={14} className="text-indigo-500" />
            <span className="hidden sm:inline">Create / Clone</span>
            <span className="sm:hidden">Create</span>
          </button>

          <button
            type="button"
            onClick={onOpenCompare}
            className={`min-h-[40px] flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
              compareCount >= 2
                ? 'bg-indigo-600/15 text-indigo-600 dark:text-indigo-300 border-indigo-500/40'
                : 'bg-zinc-100 dark:bg-zinc-900 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-900 dark:text-white border-zinc-200 dark:border-zinc-700'
            }`}
          >
            <GitCompare size={14} className="text-indigo-500" />
            <span className="hidden sm:inline">Compare</span>
            {compareCount > 0 && (
              <span className="font-mono tabular-nums text-[11px] font-bold text-indigo-500 dark:text-indigo-300">
                {compareCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOpenAiCasting}
            className="min-h-[40px] flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            <Sparkles size={14} />
            <span className="hidden sm:inline">AI Casting</span>
            <span className="sm:hidden">Cast</span>
          </button>

          <button
            type="button"
            onClick={toggleTheme}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors shrink-0"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {isDarkMode ? <Sun size={15} /> : <Moon size={15} />}
          </button>
        </div>
      </div>

      {/* Library Filter Sub-Bar (Only in Library view) */}
      {workspaceTab === 'library' && (
        <div className="border-t border-zinc-100 dark:border-zinc-800/80 bg-zinc-50/70 dark:bg-zinc-900/40">
          <div className="max-w-[1800px] mx-auto px-3 sm:px-6 lg:px-8 py-2 flex flex-wrap items-center justify-between gap-2.5">
            {/* Scope Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide max-w-full">
              {[
                { id: 'all' as LibraryScope, label: 'All Voices' },
                {
                  id: 'favorites' as LibraryScope,
                  label: `My Voice Library (${favoritesCount})`,
                  icon: <Heart size={12} className={favoritesCount > 0 ? 'fill-rose-500 text-rose-500' : ''} />,
                },
                { id: 'custom' as LibraryScope, label: `Custom (${customCount})` },
                { id: 'gaming' as LibraryScope, label: 'Gaming Ready' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => handleScopeChange(tab.id)}
                  className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                    filters.libraryScope === tab.id
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800 hover:border-indigo-500/40'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Search, Dropdowns & View Toggle */}
            <div className="flex items-center gap-2 flex-1 sm:flex-initial justify-end min-w-0">
              <div className="relative flex-1 sm:w-44 lg:w-52 min-w-[120px]">
                <Search
                  size={13}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none"
                />
                <input
                  type="text"
                  placeholder="Search voices..."
                  value={filters.search}
                  onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
                  className="w-full min-h-[36px] pl-8 pr-2.5 py-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg text-xs text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                />
              </div>

              <div className="hidden lg:flex items-center gap-1.5 shrink-0">
                <div className="relative">
                  <select
                    value={filters.gender}
                    onChange={(e) => onFilterChange({ ...filters, gender: e.target.value })}
                    className="appearance-none min-h-[36px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 pl-2.5 pr-7 rounded-lg text-xs font-medium"
                    aria-label="Filter by gender"
                  >
                    <option value="All">All Genders</option>
                    {uniqueGenders.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={12}
                    className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-zinc-400"
                  />
                </div>

                <div className="relative">
                  <select
                    value={filters.pitch}
                    onChange={(e) => onFilterChange({ ...filters, pitch: e.target.value })}
                    className="appearance-none min-h-[36px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 pl-2.5 pr-7 rounded-lg text-xs font-medium"
                    aria-label="Filter by pitch"
                  >
                    <option value="All">All Pitches</option>
                    {uniquePitches.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={12}
                    className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-zinc-400"
                  />
                </div>

                <div className="relative">
                  <select
                    value={filters.language}
                    onChange={(e) => onFilterChange({ ...filters, language: e.target.value })}
                    className="appearance-none min-h-[36px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 pl-2.5 pr-7 rounded-lg text-xs font-medium"
                    aria-label="Filter by language"
                  >
                    <option value="All">All Languages</option>
                    <option value="English">English</option>
                    <option value="Telugu">తెలుగు (Telugu)</option>
                    <option value="Tanglish">Tanglish</option>
                  </select>
                  <ChevronDown
                    size={12}
                    className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-zinc-400"
                  />
                </div>
              </div>

              {/* Grid / Carousel Toggle */}
              <div className="flex bg-white dark:bg-zinc-900 p-0.5 rounded-lg border border-zinc-200 dark:border-zinc-800 shrink-0">
                <button
                  type="button"
                  onClick={() => onViewModeChange('grid')}
                  className={`p-1.5 rounded-md transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-indigo-600 text-white'
                      : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                  }`}
                  title="Grid View"
                  aria-label="Grid View"
                >
                  <LayoutGrid size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => onViewModeChange('carousel')}
                  className={`p-1.5 rounded-md transition-colors ${
                    viewMode === 'carousel'
                      ? 'bg-indigo-600 text-white'
                      : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                  }`}
                  title="Carousel View"
                  aria-label="Carousel View"
                >
                  <GalleryHorizontalEnd size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default FilterBar;