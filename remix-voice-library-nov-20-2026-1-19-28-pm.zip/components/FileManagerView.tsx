/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  FolderOpen,
  Upload,
  FileAudio,
  FileText,
  Play,
  Pause,
  RotateCcw,
  Trash2,
  ShieldCheck,
  Mic,
  AudioLines,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Lock,
} from 'lucide-react';
import { ImportedFileRecord } from '../types';
import { formatBytes, formatStudioTime } from '../utils/audioStudioPlayer';
import {
  AUDIO_FILE_ACCEPT,
  SCRIPT_FILE_ACCEPT,
  ALL_SUPPORTED_FILE_ACCEPT,
  canUseOpenFilePicker,
  openSystemOpenFilePicker,
} from '../utils/fileVault';

interface FileManagerViewProps {
  files: ImportedFileRecord[];
  isLoadingVault: boolean;
  onImportFiles: (
    files: File[],
    requiredKind?: 'audio' | 'script'
  ) => Promise<{ saved: ImportedFileRecord[]; rejected: string[] }>;
  onDeleteFile: (id: string) => Promise<void>;
  onClearAllFiles: () => Promise<void>;
  onSendAudioToClone: (record: ImportedFileRecord, consentConfirmed: boolean) => void;
  onLoadScriptToStudio: (record: ImportedFileRecord) => void;
}

type FileFilterTab = 'all' | 'audio' | 'script';

const FileManagerView: React.FC<FileManagerViewProps> = ({
  files,
  isLoadingVault,
  onImportFiles,
  onDeleteFile,
  onClearAllFiles,
  onSendAudioToClone,
  onLoadScriptToStudio,
}) => {
  const [filterTab, setFilterTab] = useState<FileFilterTab>('all');
  const [isImporting, setIsImporting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [statusNotice, setStatusNotice] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // Per-file cloning consent drawer (ensures zero upload without explicit consent)
  const [consentPromptId, setConsentPromptId] = useState<string | null>(null);
  const [consentCheckedById, setConsentCheckedById] = useState<Record<string, boolean>>({});

  // Real pre-processing audio playback via HTMLAudioElement
  const [activeAudioId, setActiveAudioId] = useState<string | null>(null);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioCurrentTime, setAudioCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);

  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const activeObjectUrlRef = useRef<string | null>(null);

  const audioInputRef = useRef<HTMLInputElement>(null);
  const scriptInputRef = useRef<HTMLInputElement>(null);
  const allInputRef = useRef<HTMLInputElement>(null);

  const cleanupAudioPlayer = () => {
    if (audioElRef.current) {
      audioElRef.current.pause();
      audioElRef.current.onended = null;
      audioElRef.current.ontimeupdate = null;
      audioElRef.current.onloadedmetadata = null;
      audioElRef.current.onerror = null;
      audioElRef.current.src = '';
      audioElRef.current = null;
    }
    if (activeObjectUrlRef.current) {
      URL.revokeObjectURL(activeObjectUrlRef.current);
      activeObjectUrlRef.current = null;
    }
    setActiveAudioId(null);
    setIsAudioPlaying(false);
    setAudioCurrentTime(0);
    setAudioDuration(0);
  };

  useEffect(() => {
    return () => {
      cleanupAudioPlayer();
    };
  }, []);

  // Stop playback if the currently playing file is deleted
  useEffect(() => {
    if (activeAudioId && !files.some((f) => f.id === activeAudioId)) {
      cleanupAudioPlayer();
    }
  }, [files, activeAudioId]);

  const audioFilesCount = useMemo(
    () => files.filter((f) => f.kind === 'audio').length,
    [files]
  );
  const scriptFilesCount = useMemo(
    () => files.filter((f) => f.kind === 'script').length,
    [files]
  );

  const visibleFiles = useMemo(() => {
    if (filterTab === 'audio') return files.filter((f) => f.kind === 'audio');
    if (filterTab === 'script') return files.filter((f) => f.kind === 'script');
    return files;
  }, [files, filterTab]);

  const handleSelectedFileList = async (
    selected: File[],
    requiredKind?: 'audio' | 'script'
  ) => {
    if (selected.length === 0) return;
    setIsImporting(true);
    setStatusNotice(null);

    try {
      const { saved, rejected } = await onImportFiles(selected, requiredKind);
      if (saved.length > 0 && rejected.length === 0) {
        setStatusNotice({
          type: 'success',
          text: `Imported ${saved.length} ${saved.length === 1 ? 'file' : 'files'} locally to your private File Manager.`,
        });
      } else if (saved.length > 0 && rejected.length > 0) {
        setStatusNotice({
          type: 'info',
          text: `Imported ${saved.length} file(s). Skipped: ${rejected.join(' ')}`,
        });
      } else if (rejected.length > 0) {
        setStatusNotice({
          type: 'error',
          text: rejected.join(' '),
        });
      }
    } catch (err: any) {
      setStatusNotice({
        type: 'error',
        text: err?.message || 'Could not import selected file.',
      });
    } finally {
      setIsImporting(false);
    }
  };

  const triggerSystemFilePicker = async (mode: 'all' | 'audio' | 'script') => {
    setStatusNotice(null);

    // On Android Chrome / embedded frames, input[type=file] opens the native Android DocumentsUI system picker.
    // When File System Access API is explicitly available in top-level context, try it first and fall back seamlessly.
    if (canUseOpenFilePicker()) {
      const result = await openSystemOpenFilePicker(mode);
      if (result === 'cancelled') return;
      if (Array.isArray(result)) {
        await handleSelectedFileList(result, mode === 'all' ? undefined : mode);
        return;
      }
    }

    if (mode === 'audio') audioInputRef.current?.click();
    else if (mode === 'script') scriptInputRef.current?.click();
    else allInputRef.current?.click();
  };

  const handleInputChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    requiredKind?: 'audio' | 'script'
  ) => {
    const picked = Array.from(e.target.files || []);
    e.target.value = '';
    if (picked.length > 0) {
      await handleSelectedFileList(picked, requiredKind);
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const dropped = Array.from(e.dataTransfer.files || []);
    if (dropped.length > 0) {
      await handleSelectedFileList(dropped);
    }
  };

  const handleTogglePlayAudio = async (record: ImportedFileRecord) => {
    if (record.kind !== 'audio') return;
    setStatusNotice(null);

    if (activeAudioId === record.id && audioElRef.current) {
      if (isAudioPlaying) {
        audioElRef.current.pause();
        setIsAudioPlaying(false);
      } else {
        try {
          await audioElRef.current.play();
          setIsAudioPlaying(true);
        } catch (err: any) {
          setStatusNotice({
            type: 'error',
            text: err?.message || `Unable to play ${record.name} in this browser.`,
          });
        }
      }
      return;
    }

    cleanupAudioPlayer();

    const url = URL.createObjectURL(record.blob);
    activeObjectUrlRef.current = url;
    const audio = new Audio(url);
    audioElRef.current = audio;

    setActiveAudioId(record.id);
    setAudioCurrentTime(0);
    setAudioDuration(record.durationSec || 0);

    audio.onloadedmetadata = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setAudioDuration(audio.duration);
      }
    };
    audio.ontimeupdate = () => {
      setAudioCurrentTime(audio.currentTime || 0);
    };
    audio.onended = () => {
      setIsAudioPlaying(false);
      setAudioCurrentTime(0);
    };
    audio.onerror = () => {
      setIsAudioPlaying(false);
      setStatusNotice({
        type: 'error',
        text: `Browser cannot decode ${record.formatLabel} (${record.name}) for preview playback.`,
      });
    };

    try {
      await audio.play();
      setIsAudioPlaying(true);
    } catch (err: any) {
      setIsAudioPlaying(false);
      setStatusNotice({
        type: 'error',
        text: err?.message || `Playback failed for ${record.name}.`,
      });
    }
  };

  const handleReplayAudio = async (record: ImportedFileRecord) => {
    if (activeAudioId === record.id && audioElRef.current) {
      audioElRef.current.currentTime = 0;
      setAudioCurrentTime(0);
      await audioElRef.current.play().catch(() => {});
      setIsAudioPlaying(true);
    } else {
      await handleTogglePlayAudio(record);
    }
  };

  const handleSeekAudio = (recordId: string, timeSec: number) => {
    if (activeAudioId === recordId && audioElRef.current) {
      audioElRef.current.currentTime = timeSec;
      setAudioCurrentTime(timeSec);
    }
  };

  const handleDelete = async (record: ImportedFileRecord) => {
    setDeletingId(record.id);
    setStatusNotice(null);
    try {
      if (activeAudioId === record.id) {
        cleanupAudioPlayer();
      }
      if (consentPromptId === record.id) {
        setConsentPromptId(null);
      }
      await onDeleteFile(record.id);
      setStatusNotice({
        type: 'info',
        text: `Deleted "${record.name}" from your device vault.`,
      });
    } catch (err: any) {
      setStatusNotice({
        type: 'error',
        text: err?.message || `Failed to delete ${record.name}.`,
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleConfirmClearAll = async () => {
    cleanupAudioPlayer();
    setConsentPromptId(null);
    await onClearAllFiles();
    setConfirmClearAll(false);
    setStatusNotice({
      type: 'info',
      text: 'All imported files have been permanently deleted from local storage.',
    });
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar pb-24 md:pb-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Hidden System File Pickers (Android DocumentsUI + Desktop File Picker Compatible) */}
        <input
          ref={audioInputRef}
          type="file"
          multiple
          accept={AUDIO_FILE_ACCEPT}
          onChange={(e) => handleInputChange(e, 'audio')}
          className="hidden"
          aria-hidden="true"
        />
        <input
          ref={scriptInputRef}
          type="file"
          multiple
          accept={SCRIPT_FILE_ACCEPT}
          onChange={(e) => handleInputChange(e, 'script')}
          className="hidden"
          aria-hidden="true"
        />
        <input
          ref={allInputRef}
          type="file"
          multiple
          accept={ALL_SUPPORTED_FILE_ACCEPT}
          onChange={(e) => handleInputChange(e)}
          className="hidden"
          aria-hidden="true"
        />

        {/* Workspace Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <FolderOpen size={17} />
              <span className="text-xs font-bold uppercase tracking-wider">
                File Manager &amp; Audio Import
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
              Import Phone Audio &amp; Scripts
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
              Select MP3, WAV, M4A, AAC, OGG, WebM audio samples for authorized voice cloning, or import TXT / SRT scripts for TTS.
            </p>
          </div>

          {files.length > 0 && (
            <div className="shrink-0">
              {!confirmClearAll ? (
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(true)}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 hover:border-red-500/40 text-red-600 dark:text-red-400 text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
                >
                  <Trash2 size={14} />
                  <span>Delete All Files ({files.length})</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl p-1.5">
                  <span className="text-xs font-medium text-red-600 dark:text-red-300 px-2">
                    Delete all {files.length} files?
                  </span>
                  <button
                    type="button"
                    onClick={handleConfirmClearAll}
                    className="min-h-[36px] px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    Yes, Delete All
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClearAll(false)}
                    className="min-h-[36px] px-3 rounded-lg bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 text-xs font-medium whitespace-nowrap"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Security & Privacy Notice */}
        <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Lock size={18} />
          </div>
          <div className="space-y-1 text-xs sm:text-sm">
            <p className="font-semibold text-zinc-900 dark:text-white">
              Private On-Device File Vault — Explicit Selection &amp; Consent Required
            </p>
            <p className="text-zinc-500 dark:text-zinc-400 leading-relaxed">
              This app never accesses phone storage automatically. Only files you explicitly choose from your system file picker are stored locally in browser storage. Audio is never uploaded to AI servers unless you grant cloning permission, and you can delete any file immediately.
            </p>
          </div>
        </div>

        {/* Import Picker Panel */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`rounded-2xl border-2 border-dashed transition-colors p-5 sm:p-7 text-center space-y-4 ${
            isDragging
              ? 'border-indigo-500 bg-indigo-500/10'
              : 'border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900/70'
          }`}
        >
          <div className="max-w-xl mx-auto space-y-1.5">
            <div className="inline-flex w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 items-center justify-center mb-1">
              {isImporting ? <Loader2 size={22} className="animate-spin" /> : <Upload size={22} />}
            </div>
            <h3 className="text-base sm:text-lg font-bold text-zinc-900 dark:text-white">
              {isImporting ? 'Importing Selected Files...' : 'Choose Files from Your Phone or Computer'}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Audio up to 15 MB (MP3, WAV, M4A, AAC, OGG, WebM, FLAC) · Scripts up to 1 MB (TXT, MD, SRT, VTT)
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 max-w-2xl mx-auto">
            <button
              type="button"
              onClick={() => triggerSystemFilePicker('audio')}
              disabled={isImporting}
              className="min-h-[48px] flex-1 px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              <FileAudio size={18} />
              <span>Select Audio (MP3, WAV, M4A)</span>
            </button>

            <button
              type="button"
              onClick={() => triggerSystemFilePicker('script')}
              disabled={isImporting}
              className="min-h-[48px] flex-1 px-5 py-3 rounded-xl bg-zinc-900 dark:bg-zinc-800 hover:bg-zinc-800 dark:hover:bg-zinc-700 disabled:opacity-50 text-white text-sm font-semibold border border-zinc-700/60 flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              <FileText size={18} />
              <span>Import Text Script (.txt, .srt)</span>
            </button>

            <button
              type="button"
              onClick={() => triggerSystemFilePicker('all')}
              disabled={isImporting}
              className="min-h-[48px] px-4 py-3 rounded-xl bg-zinc-100 dark:bg-zinc-950 hover:bg-zinc-200 dark:hover:bg-zinc-800 disabled:opacity-50 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              <FolderOpen size={17} />
              <span>System Picker</span>
            </button>
          </div>
        </div>

        {/* Status Feedback Banner */}
        {statusNotice && (
          <div
            className={`flex items-start gap-2.5 px-4 py-3 rounded-xl text-xs sm:text-sm border ${
              statusNotice.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                : statusNotice.type === 'error'
                ? 'bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-300'
                : 'bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            {statusNotice.type === 'success' ? (
              <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
            ) : (
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
            )}
            <span>{statusNotice.text}</span>
          </div>
        )}

        {/* Filter Segmented Control */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-zinc-200/70 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl">
            {[
              { id: 'all' as FileFilterTab, label: `All Files (${files.length})` },
              { id: 'audio' as FileFilterTab, label: `Audio Samples (${audioFilesCount})` },
              { id: 'script' as FileFilterTab, label: `TTS Scripts (${scriptFilesCount})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterTab(tab.id)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  filterTab === tab.id
                    ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <p className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
            {visibleFiles.length} {visibleFiles.length === 1 ? 'item' : 'items'} stored locally
          </p>
        </div>

        {/* File List */}
        {isLoadingVault ? (
          <div className="py-14 flex flex-col items-center justify-center gap-2 text-zinc-500 dark:text-zinc-400">
            <Loader2 size={24} className="animate-spin text-indigo-500" />
            <span className="text-sm font-medium">Loading local file vault...</span>
          </div>
        ) : visibleFiles.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-10 text-center space-y-2">
            <p className="text-base font-bold text-zinc-900 dark:text-white">
              {files.length === 0 ? 'No files imported yet' : 'No matching files in this category'}
            </p>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 max-w-md mx-auto">
              Use the system file picker buttons above to import audio recordings (MP3, WAV, M4A) or text scripts (TXT, MD, SRT) from your phone.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {visibleFiles.map((record) => {
              const isAudio = record.kind === 'audio';
              const isThisPlaying = activeAudioId === record.id && isAudioPlaying;
              const isThisLoaded = activeAudioId === record.id;
              const effectiveDuration =
                (isThisLoaded && audioDuration > 0 ? audioDuration : record.durationSec) || 0;
              const showConsentDrawer = consentPromptId === record.id;
              const isConsentChecked = Boolean(consentCheckedById[record.id]);

              return (
                <div
                  key={record.id}
                  className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-4"
                >
                  {/* Top Row: File Name, Unboxed Metadata, Delete */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                          isAudio
                            ? 'bg-indigo-600/10 border-indigo-500/25 text-indigo-600 dark:text-indigo-400'
                            : 'bg-teal-600/10 border-teal-500/25 text-teal-600 dark:text-teal-400'
                        }`}
                      >
                        {isAudio ? <FileAudio size={18} /> : <FileText size={18} />}
                      </div>

                      <div className="min-w-0 space-y-1">
                        <h4
                          className="text-sm sm:text-base font-bold text-zinc-900 dark:text-white truncate"
                          title={record.name}
                        >
                          {record.name}
                        </h4>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                          <span className="font-semibold text-zinc-700 dark:text-zinc-200">
                            {record.formatLabel}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{formatBytes(record.size)}</span>
                          {isAudio && effectiveDuration > 0 && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{formatStudioTime(effectiveDuration)}</span>
                            </>
                          )}
                          {isAudio && record.estimatedHz && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>~{record.estimatedHz} Hz</span>
                            </>
                          )}
                          {!isAudio && record.textContent && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{record.textContent.length} chars</span>
                            </>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>Local only</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDelete(record)}
                      disabled={deletingId === record.id}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-500 hover:text-red-600 dark:hover:text-red-400 hover:border-red-500/40 transition-colors shrink-0"
                      title={`Delete ${record.name}`}
                      aria-label={`Delete ${record.name}`}
                    >
                      {deletingId === record.id ? (
                        <Loader2 size={16} className="animate-spin" />
                      ) : (
                        <Trash2 size={16} />
                      )}
                    </button>
                  </div>

                  {/* Audio Player OR Script Text Preview */}
                  {isAudio ? (
                    <div className="bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 space-y-2.5">
                      <div className="flex items-center gap-2.5">
                        <button
                          type="button"
                          onClick={() => handleTogglePlayAudio(record)}
                          className="min-h-[42px] px-3.5 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 dark:hover:bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0 whitespace-nowrap"
                        >
                          {isThisPlaying ? (
                            <>
                              <Pause size={13} className="fill-current" />
                              <span>Pause</span>
                            </>
                          ) : (
                            <>
                              <Play size={13} className="fill-current" />
                              <span>{isThisLoaded && audioCurrentTime > 0 ? 'Resume' : 'Play Audio'}</span>
                            </>
                          )}
                        </button>

                        {isThisLoaded && (
                          <button
                            type="button"
                            onClick={() => handleReplayAudio(record)}
                            className="min-h-[42px] min-w-[42px] flex items-center justify-center rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white shrink-0"
                            title="Replay audio"
                            aria-label="Replay audio"
                          >
                            <RotateCcw size={13} />
                          </button>
                        )}

                        <div className="flex-1 flex items-center gap-2 min-w-0">
                          <input
                            type="range"
                            min={0}
                            max={Math.max(0.1, effectiveDuration || 0.1)}
                            step={0.1}
                            value={isThisLoaded ? Math.min(audioCurrentTime, effectiveDuration || 0.1) : 0}
                            disabled={!isThisLoaded || effectiveDuration === 0}
                            onChange={(e) => handleSeekAudio(record.id, parseFloat(e.target.value))}
                            className="flex-1 accent-indigo-500 cursor-pointer disabled:opacity-40"
                            aria-label={`Playback timeline for ${record.name}`}
                          />
                          <span className="text-[11px] font-mono tabular-nums text-zinc-500 dark:text-zinc-400 shrink-0">
                            {formatStudioTime(isThisLoaded ? audioCurrentTime : 0)} / {formatStudioTime(effectiveDuration)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3">
                      <p className="text-xs text-zinc-700 dark:text-zinc-300 leading-relaxed line-clamp-3 whitespace-pre-wrap break-words">
                        {record.textContent}
                      </p>
                    </div>
                  )}

                  {/* Consent Confirmation Gate (Audio Cloning) OR Action Row */}
                  {isAudio ? (
                    showConsentDrawer ? (
                      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 space-y-3">
                        <div className="flex items-start gap-2 text-xs text-amber-800 dark:text-amber-200">
                          <ShieldCheck size={16} className="shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
                          <p className="leading-relaxed">
                            Authorization required before uploading this audio sample for AI voice cloning. Never upload recordings of celebrities or other people without explicit permission.
                          </p>
                        </div>

                        <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-zinc-800 dark:text-zinc-100">
                          <input
                            type="checkbox"
                            checked={isConsentChecked}
                            onChange={(e) =>
                              setConsentCheckedById((prev) => ({
                                ...prev,
                                [record.id]: e.target.checked,
                              }))
                            }
                            className="mt-0.5 w-4 h-4 accent-indigo-600 rounded cursor-pointer shrink-0"
                          />
                          <span className="font-medium leading-snug">
                            I confirm this audio is my own voice or I have explicit permission from the speaker to upload and clone it.
                          </span>
                        </label>

                        <div className="flex flex-wrap items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setConsentPromptId(null)}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-xs font-medium text-zinc-700 dark:text-zinc-300"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={!isConsentChecked}
                            onClick={() => {
                              if (isThisPlaying) audioElRef.current?.pause();
                              setIsAudioPlaying(false);
                              setConsentPromptId(null);
                              onSendAudioToClone(record, true);
                            }}
                            className="min-h-[40px] px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-45 disabled:cursor-not-allowed text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <Mic size={14} />
                            <span>Continue to Voice Cloning</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <span className="text-[11px] text-zinc-400">
                          Preview first, then authorize for cloning
                        </span>
                        <button
                          type="button"
                          onClick={() => setConsentPromptId(record.id)}
                          className="min-h-[44px] px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
                        >
                          <Mic size={14} />
                          <span>Use for Voice Cloning</span>
                        </button>
                      </div>
                    )
                  ) : (
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <span className="text-[11px] text-zinc-400">
                        Ready for English, Telugu, or Tanglish TTS
                      </span>
                      <button
                        type="button"
                        onClick={() => onLoadScriptToStudio(record)}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
                      >
                        <AudioLines size={14} />
                        <span>Load into Audio Studio</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default FileManagerView;
