/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { Play, Pause, Activity, Trash2, GitCompare, Check, Heart, Sliders } from 'lucide-react';
import { Voice } from '../types';
import AudioVisualizer from './AudioVisualizer';
import {
  playVoiceSample,
  stopVoiceSample,
  unlockAudioContext,
  getVoiceAnalyser,
} from '../utils/webAudioVoicePreview';

interface VoiceCardProps {
  voice: Voice;
  isPlaying: boolean;
  isFavorite?: boolean;
  onPlayToggle: (voiceName: string) => void;
  onToggleFavorite?: (voiceName: string) => void;
  onOpenInStudio?: (voiceName: string) => void;
  onDeleteCustomVoice?: (voiceName: string) => void;
  compareSlotLabel?: string | null;
  onToggleCompare?: (voiceName: string) => void;
}

const VoiceCard: React.FC<VoiceCardProps> = ({
  voice,
  isPlaying,
  isFavorite = false,
  onPlayToggle,
  onToggleFavorite,
  onOpenInStudio,
  onDeleteCustomVoice,
  compareSlotLabel = null,
  onToggleCompare,
}) => {
  const wasPlayingRef = useRef(false);
  const onPlayToggleRef = useRef(onPlayToggle);
  onPlayToggleRef.current = onPlayToggle;

  useEffect(() => {
    if (isPlaying) {
      wasPlayingRef.current = true;
      playVoiceSample(voice, () => {
        onPlayToggleRef.current(voice.name);
      });
    } else if (wasPlayingRef.current) {
      wasPlayingRef.current = false;
      stopVoiceSample(voice.name);
    }

    return () => {
      if (wasPlayingRef.current) {
        wasPlayingRef.current = false;
        stopVoiceSample(voice.name);
      }
    };
  }, [isPlaying, voice]);

  const handleCardPlay = () => {
    unlockAudioContext();
    onPlayToggle(voice.name);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleCardPlay();
    }
  };

  return (
    <div
      className={`group relative bg-white dark:bg-zinc-900 border transition-all duration-200 flex flex-col rounded-2xl overflow-hidden ${
        compareSlotLabel
          ? 'border-indigo-500 ring-1 ring-indigo-500/40'
          : isPlaying
          ? 'border-cyan-500/70 ring-1 ring-cyan-500/30'
          : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
      }`}
    >
      {/* Top Preview Strip */}
      <div
        onClick={handleCardPlay}
        role="button"
        tabIndex={0}
        onKeyDown={handleKeyDown}
        aria-label={`${isPlaying ? 'Stop' : 'Preview'} ${voice.name}`}
        className="relative h-20 w-full bg-zinc-50 dark:bg-zinc-950/80 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between px-4 cursor-pointer overflow-hidden"
      >
        <div className="absolute inset-0 pointer-events-none">
          {isPlaying && (
            <AudioVisualizer
              isPlaying={true}
              color="#6366f1"
              analyser={getVoiceAnalyser()}
            />
          )}
        </div>

        <div className="relative z-10 flex items-center gap-3 min-w-0">
          <div
            className={`h-11 w-11 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
              isPlaying
                ? 'bg-indigo-600 text-white'
                : 'bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 group-hover:border-indigo-500/60'
            }`}
          >
            {isPlaying ? (
              <Pause size={16} className="fill-current" />
            ) : (
              <Play size={16} className="fill-current ml-0.5" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-zinc-900 dark:text-white tracking-tight truncate">
                {voice.name}
              </h3>
              {voice.isCustom && (
                <span className="shrink-0 px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 text-[10px] font-bold uppercase tracking-wider">
                  {voice.isCloned ? 'Cloned' : 'Custom'}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
              {voice.analysis.gender} · {voice.pitch}
              {voice.language ? ` · ${voice.language === 'Telugu' ? 'తెలుగు' : voice.language}` : ''}
              {voice.accent && voice.accent !== 'Standard' ? ` (${voice.accent})` : ''}
            </p>
          </div>
        </div>

        {!isPlaying && (
          <Activity size={18} className="relative z-10 text-zinc-300 dark:text-zinc-700 shrink-0" />
        )}
      </div>

      {/* Body & Action Controls */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-3">
        <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed line-clamp-2">
          {voice.stylePrompt || voice.analysis.characteristics.join(' · ')}
        </p>

        <div className="flex items-center justify-between gap-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-1.5">
            {onToggleFavorite && (
              <button
                type="button"
                onClick={() => onToggleFavorite(voice.name)}
                className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border transition-colors ${
                  isFavorite
                    ? 'bg-rose-500/15 border-rose-500/40 text-rose-500'
                    : 'bg-zinc-50 dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-zinc-400 hover:text-rose-400'
                }`}
                title={isFavorite ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
                aria-label={isFavorite ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
              >
                <Heart size={15} className={isFavorite ? 'fill-current' : ''} />
              </button>
            )}

            {onToggleCompare && (
              <button
                type="button"
                onClick={() => onToggleCompare(voice.name)}
                className={`min-h-[40px] px-2.5 flex items-center gap-1 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                  compareSlotLabel
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-zinc-50 dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:border-indigo-500/50'
                }`}
                title={compareSlotLabel ? `Remove ${voice.name} from compare` : `Compare ${voice.name}`}
              >
                {compareSlotLabel ? <Check size={13} /> : <GitCompare size={13} />}
                <span>{compareSlotLabel ? compareSlotLabel : 'Compare'}</span>
              </button>
            )}

            {voice.isCustom && onDeleteCustomVoice && (
              <button
                type="button"
                onClick={() => onDeleteCustomVoice(voice.name)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-400 hover:text-red-500 transition-colors"
                title={`Delete ${voice.name}`}
                aria-label={`Delete ${voice.name}`}
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>

          {onOpenInStudio && (
            <button
              type="button"
              onClick={() => onOpenInStudio(voice.name)}
              className="min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 dark:hover:bg-indigo-600 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              <Sliders size={13} />
              <span>Studio</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default VoiceCard;