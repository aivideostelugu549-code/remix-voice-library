/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Voice } from '../types';
import VoiceCard from './VoiceCard';

interface GridViewProps {
  voices: Voice[];
  playingVoice: string | null;
  favoriteNames: string[];
  onPlayToggle: (voiceName: string) => void;
  onToggleFavorite: (voiceName: string) => void;
  onOpenInStudio: (voiceName: string) => void;
  onDeleteCustomVoice?: (voiceName: string) => void;
  compareSelection?: string[];
  onToggleCompare?: (voiceName: string) => void;
}

const SLOT_LABELS = ['A', 'B', 'C', 'D'];

const GridView: React.FC<GridViewProps> = ({
  voices,
  playingVoice,
  favoriteNames,
  onPlayToggle,
  onToggleFavorite,
  onOpenInStudio,
  onDeleteCustomVoice,
  compareSelection = [],
  onToggleCompare,
}) => {
  return (
    <div className="w-full h-full overflow-y-auto custom-scrollbar">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-28 sm:pb-24">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
          {voices.map((voice) => {
            const idx = compareSelection.indexOf(voice.name);
            const compareSlotLabel = idx >= 0 ? SLOT_LABELS[idx] || String(idx + 1) : null;
            return (
              <VoiceCard
                key={voice.name}
                voice={voice}
                isPlaying={playingVoice === voice.name}
                isFavorite={favoriteNames.includes(voice.name)}
                onPlayToggle={onPlayToggle}
                onToggleFavorite={onToggleFavorite}
                onOpenInStudio={onOpenInStudio}
                onDeleteCustomVoice={onDeleteCustomVoice}
                compareSlotLabel={compareSlotLabel}
                onToggleCompare={onToggleCompare}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default GridView;