/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Users,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Wand2,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Music,
  Volume2,
  Sliders,
  Download,
  RefreshCw,
  MessageSquarePlus,
  Square,
  ChevronDown,
  ChevronUp,
  Languages,
} from 'lucide-react';
import {
  Voice,
  LanguageMode,
  TeluguAccent,
  ConversationSceneType,
  ConversationBgmPreset,
  ConversationSfxCue,
  ConversationCharacter,
  ConversationLine,
} from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  StudioAudioController,
  StudioPlaybackState,
  checkClientEthicalVoicePolicy,
  encodeAudioForExport,
  saveBlobToPhoneOrDevice,
  sanitizeUserFilename,
  formatStudioTime,
} from '../utils/audioStudioPlayer';
import {
  mixAndConcatenateConversation,
  ConversationTimelineSegment,
  CharacterStemTrack,
} from '../utils/conversationAudioMixer';

interface BatchConversationStudioViewProps {
  voices: Voice[];
}

const SCENE_TYPES: ConversationSceneType[] = [
  'Funny Argument',
  'Comedy Scene',
  'Gaming Conversation',
  'Horror Storytelling',
  'Interview',
  'Podcast',
];

const CHARACTER_ROLES = [
  'Funny Friend',
  'Energetic Lead',
  'Calm Host',
  'Scary Narrator',
  'Pro Gamer',
  'Sarcastic Roaster',
  'Cute Comic Relief',
  'Guest Expert',
];

const EMOTION_OPTIONS = [
  'Funny',
  'Excited',
  'Angry',
  'Calm',
  'Scared',
  'Sarcastic',
  'Dramatic',
  'Curious',
  'Whispered',
  'Natural',
];

const STYLE_OPTIONS = [
  'Conversational',
  'Fast & Punchy',
  'Gaming Callout',
  'Storyteller',
  'Whispered Suspense',
  'Podcast Host',
  'Soft & Friendly',
];

const SFX_OPTIONS: Array<{ id: ConversationSfxCue; label: string }> = [
  { id: 'none', label: 'No SFX' },
  { id: 'comedy-pop', label: 'Comedy Pop' },
  { id: 'gaming-ding', label: 'Gaming Ding' },
  { id: 'horror-sting', label: 'Horror Sting' },
  { id: 'transition-whoosh', label: 'Whoosh' },
  { id: 'applause-swell', label: 'Applause' },
];

const BGM_OPTIONS: Array<{ id: ConversationBgmPreset; label: string }> = [
  { id: 'none', label: 'No Background Music' },
  { id: 'podcast-lofi', label: 'Lo-Fi Chill Podcast' },
  { id: 'gaming-synth', label: 'Upbeat Gaming Synth' },
  { id: 'comedy-groove', label: 'Comedy Acoustic Groove' },
  { id: 'horror-drone', label: 'Suspense Horror Drone' },
];

interface StarterScenePreset {
  id: string;
  label: string;
  sceneType: ConversationSceneType;
  language: LanguageMode;
  accent: TeluguAccent;
  bgm: ConversationBgmPreset;
  characters: Array<{ name: string; role: string; preferredGender: 'Male' | 'Female' }>;
  lines: Array<{
    charIdx: number;
    text: string;
    emotion: string;
    speakingStyle: string;
    sfxCue: ConversationSfxCue;
  }>;
}

const STARTER_PRESETS: StarterScenePreset[] = [
  {
    id: 'telugu-argument',
    label: 'Funny Biryani Argument',
    sceneType: 'Funny Argument',
    language: 'Tanglish',
    accent: 'Telangana',
    bgm: 'comedy-groove',
    characters: [
      { name: 'Raju', role: 'Funny Friend', preferredGender: 'Male' },
      { name: 'Karthik', role: 'Sarcastic Roaster', preferredGender: 'Male' },
      { name: 'Sravani', role: 'Calm Host', preferredGender: 'Female' },
    ],
    lines: [
      {
        charIdx: 0,
        text: 'అరేయ్ కార్తీక్! లాస్ట్ పీస్ చికెన్ నా ప్లేట్ లోంచి ఎప్పుడు లేపావ్ రా?! <gasp>',
        emotion: 'Angry',
        speakingStyle: 'Fast & Punchy',
        sfxCue: 'comedy-pop',
      },
      {
        charIdx: 1,
        text: '<laugh> నేను తీయలేదు బాబాయ్, అది గాలికి ఎగిరి నా స్పూన్ లో పడింది అంతే!',
        emotion: 'Funny',
        speakingStyle: 'Conversational',
        sfxCue: 'none',
      },
      {
        charIdx: 2,
        text: 'ఆపండి రా ఇద్దరూ! ఇంకో ఆర్డర్ పెడదాం కానీ ఈ డ్రామా తట్టుకోలేకపోతున్నా.',
        emotion: 'Sarcastic',
        speakingStyle: 'Soft & Friendly',
        sfxCue: 'none',
      },
      {
        charIdx: 0,
        text: 'సరే సరే, డబుల్ మసాలా చెప్పు మామా... కానీ కార్తీక్ గాడు బిల్ కట్టాలి ఈసారి!',
        emotion: 'Excited',
        speakingStyle: 'Fast & Punchy',
        sfxCue: 'applause-swell',
      },
    ],
  },
  {
    id: 'gaming-squad',
    label: 'Telugu Gaming Squad',
    sceneType: 'Gaming Conversation',
    language: 'Tanglish',
    accent: 'Telangana',
    bgm: 'gaming-synth',
    characters: [
      { name: 'Vikram OP', role: 'Pro Gamer', preferredGender: 'Male' },
      { name: 'Bunty', role: 'Funny Friend', preferredGender: 'Male' },
      { name: 'Ananya', role: 'Energetic Lead', preferredGender: 'Female' },
    ],
    lines: [
      {
        charIdx: 0,
        text: 'లెఫ్ట్ లో ఫుల్ స్క్వాడ్ వస్తుంది! కవర్ తీసుకోండి ఫాస్ట్ గా!',
        emotion: 'Excited',
        speakingStyle: 'Gaming Callout',
        sfxCue: 'gaming-ding',
      },
      {
        charIdx: 1,
        text: 'నా పింగ్ 400 చూపిస్తుంది మామా... <breath> నా క్యారెక్టర్ గోడకేసి గుద్దుకుంటుంది!',
        emotion: 'Funny',
        speakingStyle: 'Fast & Punchy',
        sfxCue: 'comedy-pop',
      },
      {
        charIdx: 2,
        text: 'రివైవ్ పట్టుకో బంటీ, వెనకాల నుంచి నేను స్మోక్ వేశాను! క్లచ్ చేద్దాం!',
        emotion: 'Excited',
        speakingStyle: 'Gaming Callout',
        sfxCue: 'none',
      },
      {
        charIdx: 0,
        text: 'బూమ్! లాస్ట్ నాక్ కూడా ఫినిష్! <laugh> చికెన్ డిన్నర్ మనదే రా బాయ్స్!',
        emotion: 'Excited',
        speakingStyle: 'Gaming Callout',
        sfxCue: 'applause-swell',
      },
    ],
  },
  {
    id: 'horror-story',
    label: 'Midnight Horror Story',
    sceneType: 'Horror Storytelling',
    language: 'Telugu',
    accent: 'Andhra',
    bgm: 'horror-drone',
    characters: [
      { name: 'Narrator', role: 'Scary Narrator', preferredGender: 'Male' },
      { name: 'Meera', role: 'Guest Expert', preferredGender: 'Female' },
    ],
    lines: [
      {
        charIdx: 0,
        text: 'అర్ధరాత్రి ఒంటి గంట... హైవే పక్కన ఉన్న ఆ పాత బంగ్లా తలుపు మెల్లగా తెరుచుకుంది.',
        emotion: 'Dramatic',
        speakingStyle: 'Storyteller',
        sfxCue: 'horror-sting',
      },
      {
        charIdx: 1,
        text: '<gasp> ఎవరు అక్కడ? ఫోన్ సిగ్నల్ కూడా కట్ అయిపోయింది... ఎవరో నా పేరు పిలుస్తున్నారు!',
        emotion: 'Scared',
        speakingStyle: 'Whispered Suspense',
        sfxCue: 'none',
      },
      {
        charIdx: 0,
        text: 'వెనక్కి తిరిగి చూసిన మీరా గడ్డకట్టుకుపోయింది... ఎందుకంటే అక్కడ నీడ మాత్రమే ఉంది, మనిషి లేడు.',
        emotion: 'Scared',
        speakingStyle: 'Whispered Suspense',
        sfxCue: 'horror-sting',
      },
    ],
  },
  {
    id: 'podcast-interview',
    label: 'Creator Podcast Interview',
    sceneType: 'Podcast',
    language: 'English',
    accent: 'Standard',
    bgm: 'podcast-lofi',
    characters: [
      { name: 'Nikhil', role: 'Calm Host', preferredGender: 'Male' },
      { name: 'Priya', role: 'Guest Expert', preferredGender: 'Female' },
    ],
    lines: [
      {
        charIdx: 0,
        text: 'Welcome back to Creator Spotlight! <breath> Today we have Priya talking about viral Telugu storytelling.',
        emotion: 'Calm',
        speakingStyle: 'Podcast Host',
        sfxCue: 'transition-whoosh',
      },
      {
        charIdx: 1,
        text: 'Thanks Nikhil! Honest regional dialogue beats over-polished scripts every single time.',
        emotion: 'Natural',
        speakingStyle: 'Conversational',
        sfxCue: 'none',
      },
    ],
  },
];

let uidCounter = 1;
const nextId = (prefix: string) => `${prefix}_${Date.now()}_${uidCounter++}`;

function pickDistinctVoices(
  voices: Voice[],
  defs: Array<{ preferredGender?: 'Male' | 'Female' }>
): string[] {
  const used = new Set<string>();
  return defs.map((def, idx) => {
    const match = voices.find(
      (v) =>
        !used.has(v.name) &&
        (!def.preferredGender || v.analysis.gender === def.preferredGender)
    );
    const fallback =
      match ||
      voices.find((v) => !used.has(v.name)) ||
      voices[idx % Math.max(1, voices.length)];
    if (fallback) used.add(fallback.name);
    return fallback?.name || 'Puck';
  });
}

const BatchConversationStudioView: React.FC<BatchConversationStudioViewProps> = ({ voices }) => {
  const initialVoiceNames = useMemo(
    () => pickDistinctVoices(voices, STARTER_PRESETS[0].characters),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const [sceneType, setSceneType] = useState<ConversationSceneType>(STARTER_PRESETS[0].sceneType);
  const [language, setLanguage] = useState<LanguageMode>(STARTER_PRESETS[0].language);
  const [accent, setAccent] = useState<TeluguAccent>(STARTER_PRESETS[0].accent);

  const [characters, setCharacters] = useState<ConversationCharacter[]>(() =>
    STARTER_PRESETS[0].characters.map((c, idx) => ({
      id: nextId('char'),
      name: c.name,
      role: c.role,
      voiceName: initialVoiceNames[idx] || voices[idx % Math.max(1, voices.length)]?.name || 'Puck',
    }))
  );

  const [lines, setLines] = useState<ConversationLine[]>(() => {
    const firstChars = characters;
    return STARTER_PRESETS[0].lines.map((l) => ({
      id: nextId('line'),
      characterId: firstChars[l.charIdx]?.id || firstChars[0]?.id || '',
      text: l.text,
      emotion: l.emotion,
      speakingStyle: l.speakingStyle,
      sfxCue: l.sfxCue,
      status: 'idle',
      audioBase64: null,
      error: null,
    }));
  });

  // Advanced audio mix controls
  const [speed, setSpeed] = useState<number>(1.0);
  const [pitchSemitones, setPitchSemitones] = useState<number>(0);
  const [pauseDurationSec, setPauseDurationSec] = useState<number>(0.45);
  const [bgmPreset, setBgmPreset] = useState<ConversationBgmPreset>(STARTER_PRESETS[0].bgm);
  const [bgmVolume, setBgmVolume] = useState<number>(0.24);
  const [sfxVolume, setSfxVolume] = useState<number>(0.7);

  // AI Script Generator UI state
  const [showAiWriter, setShowAiWriter] = useState(false);
  const [aiTopic, setAiTopic] = useState('');
  const [aiCharCount, setAiCharCount] = useState(3);
  const [aiLineCount, setAiLineCount] = useState(8);
  const [isWritingScript, setIsWritingScript] = useState(false);
  const [isAutoCasting, setIsAutoCasting] = useState(false);

  // Batch execution state
  const [isBatchRunning, setIsBatchRunning] = useState(false);
  const [batchProgress, setBatchProgress] = useState({ done: 0, total: 0, currentLabel: '' });
  const cancelBatchRef = useRef(false);

  // Mixing & Export state
  const [isMixing, setIsMixing] = useState(false);
  const [mixNeedsUpdate, setMixNeedsUpdate] = useState(false);
  const [masterAudioBase64, setMasterAudioBase64] = useState<string | null>(null);
  const [timelineSegments, setTimelineSegments] = useState<ConversationTimelineSegment[]>([]);
  const [characterTracks, setCharacterTracks] = useState<CharacterStemTrack[]>([]);
  const [studioError, setStudioError] = useState<string | null>(null);
  const [stemDownloadStatus, setStemDownloadStatus] = useState<string | null>(null);

  // Playback controllers (master + single line/stem preview)
  const [playingTarget, setPlayingTarget] = useState<string | null>(null); // 'master' | lineId | `stem:${charId}`
  const [playback, setPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });

  const controllerRef = useRef<StudioAudioController | null>(null);
  const isMountedRef = useRef(true);
  const charactersRef = useRef(characters);
  charactersRef.current = characters;
  const linesRef = useRef(lines);
  linesRef.current = lines;

  useEffect(() => {
    isMountedRef.current = true;
    controllerRef.current = new StudioAudioController((next) => {
      if (isMountedRef.current) setPlayback(next);
    });
    return () => {
      isMountedRef.current = false;
      cancelBatchRef.current = true;
      controllerRef.current?.dispose();
      controllerRef.current = null;
    };
  }, []);

  // Track which line is currently speaking during Master playback
  const activeSegment = useMemo(() => {
    if (playingTarget !== 'master' || (!playback.isPlaying && !playback.isPaused)) return null;
    return (
      timelineSegments.find(
        (seg) => playback.currentTime >= seg.startSec && playback.currentTime <= seg.endSec
      ) || null
    );
  }, [playingTarget, playback.isPlaying, playback.isPaused, playback.currentTime, timelineSegments]);

  const readyCount = useMemo(
    () => lines.filter((l) => l.status === 'ready' && Boolean(l.audioBase64)).length,
    [lines]
  );
  const failedCount = useMemo(() => lines.filter((l) => l.status === 'error').length, [lines]);

  // Warn user if duplicate voices exist among characters
  const duplicateVoiceWarning = useMemo(() => {
    const counts = new Map<string, number>();
    characters.forEach((c) => counts.set(c.voiceName, (counts.get(c.voiceName) || 0) + 1));
    return Array.from(counts.values()).some((cnt) => cnt > 1);
  }, [characters]);

  const applyPreset = (preset: StarterScenePreset) => {
    controllerRef.current?.stop();
    setPlayingTarget(null);
    setMasterAudioBase64(null);
    setTimelineSegments([]);
    setCharacterTracks([]);
    setStudioError(null);
    setMixNeedsUpdate(false);

    const assignedVoices = pickDistinctVoices(voices, preset.characters);
    const newChars: ConversationCharacter[] = preset.characters.map((c, idx) => ({
      id: nextId('char'),
      name: c.name,
      role: c.role,
      voiceName: assignedVoices[idx] || 'Puck',
    }));

    const newLines: ConversationLine[] = preset.lines.map((l) => ({
      id: nextId('line'),
      characterId: newChars[l.charIdx]?.id || newChars[0].id,
      text: l.text,
      emotion: l.emotion,
      speakingStyle: l.speakingStyle,
      sfxCue: l.sfxCue,
      status: 'idle',
      audioBase64: null,
      error: null,
    }));

    setSceneType(preset.sceneType);
    setLanguage(preset.language);
    setAccent(preset.accent);
    setBgmPreset(preset.bgm);
    setCharacters(newChars);
    setLines(newLines);
  };

  // Character management (2-10 characters)
  const handleAddCharacter = () => {
    if (characters.length >= 10) return;
    const used = new Set(characters.map((c) => c.voiceName));
    const nextVoice =
      voices.find((v) => !used.has(v.name)) ||
      voices[characters.length % Math.max(1, voices.length)];
    const idx = characters.length + 1;
    setCharacters((prev) => [
      ...prev,
      {
        id: nextId('char'),
        name: `Character ${idx}`,
        role: CHARACTER_ROLES[(idx - 1) % CHARACTER_ROLES.length],
        voiceName: nextVoice?.name || 'Puck',
      },
    ]);
  };

  const handleRemoveCharacter = (charId: string) => {
    if (characters.length <= 2) return;
    const remaining = characters.filter((c) => c.id !== charId);
    const fallbackCharId = remaining[0].id;
    setCharacters(remaining);
    setLines((prev) =>
      prev.map((l) =>
        l.characterId === charId
          ? { ...l, characterId: fallbackCharId, status: 'idle', audioBase64: null }
          : l
      )
    );
    if (masterAudioBase64) setMixNeedsUpdate(true);
  };

  const handleUpdateCharacter = (
    charId: string,
    patch: Partial<ConversationCharacter>,
    invalidateAudio = false
  ) => {
    setCharacters((prev) => prev.map((c) => (c.id === charId ? { ...c, ...patch } : c)));
    if (invalidateAudio) {
      setLines((prev) =>
        prev.map((l) =>
          l.characterId === charId ? { ...l, status: 'idle', audioBase64: null, error: null } : l
        )
      );
      setMasterAudioBase64(null);
      setCharacterTracks([]);
    }
  };

  const handleAutoAssignVoices = async () => {
    if (isAutoCasting || characters.length < 2) return;
    setIsAutoCasting(true);
    setStudioError(null);
    try {
      const simplifiedVoices = voices.map((v) => ({
        name: v.name,
        gender: v.analysis.gender,
        pitch: v.analysis.pitch,
        characteristics: v.analysis.characteristics,
        language: v.language,
      }));
      const res = await fetch('/api/voice-studio/conversation-autocast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sceneType,
          characters: characters.map((c) => ({ id: c.id, name: c.name, role: c.role })),
          availableVoices: simplifiedVoices,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Auto-assign voices failed.');
      }

      const assignments: Array<{ id: string; voiceName: string }> = Array.isArray(data.assignments)
        ? data.assignments
        : [];
      const assignMap = new Map(assignments.map((a) => [a.id, a.voiceName]));
      const validVoiceNames = new Set(voices.map((v) => v.name));
      const used = new Set<string>();

      setCharacters((prev) =>
        prev.map((c, idx) => {
          const suggested = assignMap.get(c.id);
          let chosen =
            suggested && validVoiceNames.has(suggested) && !used.has(suggested)
              ? suggested
              : voices.find((v) => !used.has(v.name))?.name ||
                voices[idx % Math.max(1, voices.length)]?.name ||
                c.voiceName;
          used.add(chosen);
          return { ...c, voiceName: chosen };
        })
      );
      // Reset line audio since voice casting changed
      setLines((prev) => prev.map((l) => ({ ...l, status: 'idle', audioBase64: null, error: null })));
      setMasterAudioBase64(null);
      setCharacterTracks([]);
    } catch (err: any) {
      setStudioError(err?.message || 'Could not auto-assign character voices.');
    } finally {
      setIsAutoCasting(false);
    }
  };

  // AI Conversation Writer
  const handleAiGenerateScript = async () => {
    const policyErr = checkClientEthicalVoicePolicy(aiTopic);
    if (policyErr) {
      setStudioError(policyErr);
      return;
    }
    setIsWritingScript(true);
    setStudioError(null);
    try {
      const simplifiedVoices = voices.map((v) => ({
        name: v.name,
        gender: v.analysis.gender,
        pitch: v.analysis.pitch,
        characteristics: v.analysis.characteristics,
      }));
      const res = await fetch('/api/voice-studio/conversation-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sceneType,
          language,
          accent,
          characterCount: aiCharCount,
          lineCount: aiLineCount,
          topic: aiTopic.trim() || undefined,
          availableVoices: simplifiedVoices,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate conversation script.');
      }

      const rawChars = Array.isArray(data.characters) ? data.characters.slice(0, 10) : [];
      const rawLines = Array.isArray(data.lines) ? data.lines : [];
      if (rawChars.length < 2 || rawLines.length === 0) {
        throw new Error('AI script writer returned an incomplete conversation. Please try again.');
      }

      const validVoiceSet = new Set(voices.map((v) => v.name));
      const usedVoices = new Set<string>();
      const nextChars: ConversationCharacter[] = rawChars.map((rc: any, idx: number) => {
        let vName = typeof rc.voiceName === 'string' ? rc.voiceName : '';
        if (!validVoiceSet.has(vName) || usedVoices.has(vName)) {
          vName =
            voices.find((v) => !usedVoices.has(v.name))?.name ||
            voices[idx % Math.max(1, voices.length)]?.name ||
            'Puck';
        }
        usedVoices.add(vName);
        return {
          id: nextId('char'),
          name: String(rc.name || `Character ${idx + 1}`).trim(),
          role: String(rc.role || CHARACTER_ROLES[idx % CHARACTER_ROLES.length]),
          voiceName: vName,
        };
      });

      const charByName = new Map(nextChars.map((c) => [c.name.toLowerCase(), c.id]));
      const validSfx = new Set<ConversationSfxCue>([
        'none',
        'comedy-pop',
        'gaming-ding',
        'horror-sting',
        'transition-whoosh',
        'applause-swell',
      ]);

      const nextLines: ConversationLine[] = rawLines.map((rl: any, idx: number) => {
        const cName = String(rl.characterName || '').trim().toLowerCase();
        const cid =
          charByName.get(cName) || nextChars[idx % nextChars.length].id;
        const cue = validSfx.has(rl.sfxCue) ? (rl.sfxCue as ConversationSfxCue) : 'none';
        return {
          id: nextId('line'),
          characterId: cid,
          text: String(rl.text || '').trim(),
          emotion: String(rl.emotion || 'Natural'),
          speakingStyle: String(rl.speakingStyle || 'Conversational'),
          sfxCue: cue,
          status: 'idle',
          audioBase64: null,
          error: null,
        };
      });

      controllerRef.current?.stop();
      setPlayingTarget(null);
      setMasterAudioBase64(null);
      setCharacterTracks([]);
      setTimelineSegments([]);
      setCharacters(nextChars);
      setLines(nextLines);
      setShowAiWriter(false);
    } catch (err: any) {
      setStudioError(err?.message || 'Failed to generate AI conversation script.');
    } finally {
      setIsWritingScript(false);
    }
  };

  // Dialogue Row CRUD + Reordering
  const handleAddLine = () => {
    const lastLine = lines[lines.length - 1];
    const lastCharIdx = lastLine
      ? characters.findIndex((c) => c.id === lastLine.characterId)
      : -1;
    const nextChar = characters[(lastCharIdx + 1) % characters.length] || characters[0];
    setLines((prev) => [
      ...prev,
      {
        id: nextId('line'),
        characterId: nextChar.id,
        text: '',
        emotion: 'Natural',
        speakingStyle: sceneType === 'Gaming Conversation' ? 'Gaming Callout' : 'Conversational',
        sfxCue: 'none',
        status: 'idle',
        audioBase64: null,
        error: null,
      },
    ]);
  };

  const handleUpdateLine = (
    lineId: string,
    patch: Partial<ConversationLine>,
    invalidateAudio = false
  ) => {
    setLines((prev) =>
      prev.map((l) => {
        if (l.id !== lineId) return l;
        const updated = { ...l, ...patch };
        if (invalidateAudio) {
          updated.status = 'idle';
          updated.audioBase64 = null;
          updated.error = null;
        }
        return updated;
      })
    );
    if (invalidateAudio) setMixNeedsUpdate(true);
  };

  const handleDeleteLine = (lineId: string) => {
    if (lines.length <= 1) return;
    setLines((prev) => prev.filter((l) => l.id !== lineId));
    setMixNeedsUpdate(true);
  };

  const handleMoveLine = (index: number, delta: -1 | 1) => {
    const target = index + delta;
    if (target < 0 || target >= lines.length) return;
    setLines((prev) => {
      const copy = [...prev];
      const [moved] = copy.splice(index, 1);
      copy.splice(target, 0, moved);
      return copy;
    });
    if (masterAudioBase64) setMixNeedsUpdate(true);
  };

  // Single line TTS fetch with rate-limit retry
  const synthesizeSingleLine = async (
    line: ConversationLine,
    attempt = 0
  ): Promise<string> => {
    const currentChars = charactersRef.current;
    const char = currentChars.find((c) => c.id === line.characterId) || currentChars[0];
    const voiceObj = voices.find((v) => v.name === char.voiceName) || voices[0];
    const baseVoice = voiceObj?.baseVoice || voiceObj?.name || 'Puck';

    const policyErr = checkClientEthicalVoicePolicy(`${char.name} ${line.text}`);
    if (policyErr) {
      throw new Error(policyErr);
    }

    const styleParts = [
      voiceObj?.stylePrompt || '',
      `Character role: ${char.role}.`,
      `Speaking style: ${line.speakingStyle}.`,
      `Scene tone: ${sceneType}.`,
    ]
      .filter(Boolean)
      .join(' ');

    const res = await fetch('/api/voice-studio/preview', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: line.text.trim(),
        baseVoice,
        stylePrompt: styleParts,
        language,
        accent,
        ageImpression: voiceObj?.ageImpression,
        emotion: line.emotion,
        energy: sceneType === 'Gaming Conversation' || line.emotion === 'Excited' ? 85 : 60,
        speed: voiceObj?.speed ?? speed,
        pitchSemitones: voiceObj?.pitchSemitones ?? pitchSemitones,
        gamingStyle: sceneType === 'Gaming Conversation' ? 'Gaming Commentary' : undefined,
      }),
    });

    if ((res.status === 429 || res.status >= 502) && attempt < 2 && !cancelBatchRef.current) {
      const waitMs = 900 * Math.pow(2, attempt);
      await new Promise((r) => setTimeout(r, waitMs));
      return synthesizeSingleLine(line, attempt + 1);
    }

    const data = await res.json();
    if (!res.ok || !data.audioBase64) {
      throw new Error(data.error || `TTS failed (HTTP ${res.status})`);
    }
    return data.audioBase64;
  };

  const runMixConversation = async (overrideLines?: ConversationLine[]) => {
    const activeLines = overrideLines || linesRef.current;
    if (activeLines.filter((l) => l.status === 'ready' && l.audioBase64).length === 0) {
      return;
    }
    setIsMixing(true);
    setStudioError(null);
    try {
      const mixed = await mixAndConcatenateConversation({
        lines: activeLines,
        characters: charactersRef.current,
        pauseDurationSec,
        speed,
        pitchSemitones,
        bgmPreset,
        bgmVolume,
        sfxVolume,
      });
      if (!isMountedRef.current) return;
      setMasterAudioBase64(mixed.masterBase64);
      setTimelineSegments(mixed.segments);
      setCharacterTracks(mixed.characterTracks);
      setMixNeedsUpdate(false);

      if (controllerRef.current) {
        await controllerRef.current.loadBase64(mixed.masterBase64);
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        setStudioError(err?.message || 'Failed to mix conversation audio.');
      }
    } finally {
      if (isMountedRef.current) setIsMixing(false);
    }
  };

  const handleGenerateSingleLine = async (line: ConversationLine) => {
    if (!line.text.trim()) {
      handleUpdateLine(line.id, { status: 'error', error: 'Dialogue text cannot be empty.' });
      return;
    }
    setStudioError(null);
    handleUpdateLine(line.id, { status: 'generating', error: null });
    try {
      const audioBase64 = await synthesizeSingleLine(line);
      if (!isMountedRef.current) return;
      const updated = linesRef.current.map((l) =>
        l.id === line.id ? { ...l, status: 'ready' as const, audioBase64, error: null } : l
      );
      setLines(updated);
      setMixNeedsUpdate(true);
      if (updated.some((l) => l.status === 'ready')) {
        await runMixConversation(updated);
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        handleUpdateLine(line.id, {
          status: 'error',
          error: err?.message || 'Failed to synthesize this dialogue line.',
        });
      }
    }
  };

  const handleBatchGenerate = async (onlyFailed = false) => {
    const queue = lines.filter((l) => {
      if (!l.text.trim()) return false;
      if (onlyFailed) return l.status === 'error' || l.status === 'idle';
      return true;
    });

    if (queue.length === 0) {
      setStudioError('Enter dialogue text in at least one row before generating.');
      return;
    }

    controllerRef.current?.stop();
    setPlayingTarget(null);
    cancelBatchRef.current = false;
    setIsBatchRunning(true);
    setStudioError(null);
    setBatchProgress({ done: 0, total: queue.length, currentLabel: 'Starting batch...' });

    const queueIds = new Set(queue.map((q) => q.id));
    setLines((prev) =>
      prev.map((l) =>
        queueIds.has(l.id) ? { ...l, status: 'idle', error: null } : l
      )
    );

    let completed = 0;
    let cursor = 0;
    const CONCURRENCY = 2;
    let latestLines = [...linesRef.current];

    const worker = async () => {
      while (cursor < queue.length && !cancelBatchRef.current) {
        const myIndex = cursor++;
        const targetLine = queue[myIndex];
        const char = charactersRef.current.find((c) => c.id === targetLine.characterId);

        setBatchProgress({
          done: completed,
          total: queue.length,
          currentLabel: `${char?.name || 'Speaker'} (Line ${myIndex + 1})`,
        });

        setLines((prev) =>
          prev.map((l) =>
            l.id === targetLine.id ? { ...l, status: 'generating', error: null } : l
          )
        );

        try {
          const audioBase64 = await synthesizeSingleLine(targetLine);
          latestLines = latestLines.map((l) =>
            l.id === targetLine.id
              ? { ...l, status: 'ready' as const, audioBase64, error: null }
              : l
          );
        } catch (err: any) {
          latestLines = latestLines.map((l) =>
            l.id === targetLine.id
              ? {
                  ...l,
                  status: 'error' as const,
                  audioBase64: null,
                  error: err?.message || 'Synthesis failed',
                }
              : l
          );
        }

        if (!isMountedRef.current) return;
        completed += 1;
        setLines([...latestLines]);
        setBatchProgress({
          done: completed,
          total: queue.length,
          currentLabel:
            completed >= queue.length ? 'Mixing conversation audio...' : `${completed} / ${queue.length} done`,
        });

        // Gentle pacing pause to respect Gemini TTS rate limits on long scripts
        if (cursor < queue.length && !cancelBatchRef.current) {
          await new Promise((r) => setTimeout(r, 220));
        }
      }
    };

    await Promise.all(
      Array.from({ length: Math.min(CONCURRENCY, queue.length) }, () => worker())
    );

    if (!isMountedRef.current) return;
    setIsBatchRunning(false);

    const anyReady = latestLines.some((l) => l.status === 'ready' && Boolean(l.audioBase64));
    if (anyReady) {
      await runMixConversation(latestLines);
    } else {
      setStudioError('All dialogue lines failed to generate. Check errors listed on each row.');
    }
  };

  // Playback handlers
  const handlePlayToggleAudio = async (targetKey: string, base64Audio: string | null | undefined) => {
    const controller = controllerRef.current;
    if (!controller || !base64Audio) return;

    if (playingTarget === targetKey) {
      if (playback.isPlaying) {
        controller.pause();
      } else if (playback.isPaused) {
        await controller.play(false);
      } else {
        await controller.play(true);
      }
      return;
    }

    controller.stop();
    await controller.loadBase64(base64Audio);
    setPlayingTarget(targetKey);
    await controller.play(true);
  };

  const handleReplayMaster = async () => {
    if (!controllerRef.current || !masterAudioBase64) return;
    if (playingTarget !== 'master') {
      await controllerRef.current.loadBase64(masterAudioBase64);
      setPlayingTarget('master');
    }
    await controllerRef.current.play(true);
  };

  const handleDownloadStem = async (track: CharacterStemTrack, format: 'mp3' | 'wav') => {
    setStemDownloadStatus(`Encoding ${track.characterName}'s dialogue track (${format.toUpperCase()})...`);
    try {
      const blob = await encodeAudioForExport({
        base64Audio: track.audioBase64,
        format,
        mp3Kbps: 192,
        wavSampleRate: 44100,
      });
      const filename = sanitizeUserFilename(
        `${track.characterName}_${track.voiceName}_Dialogue_Track`,
        format
      );
      const result = await saveBlobToPhoneOrDevice(blob, filename, false);
      setStemDownloadStatus(
        result.status === 'saved'
          ? `Downloaded ${result.filename}`
          : 'Download cancelled.'
      );
    } catch (err: any) {
      setStemDownloadStatus(err?.message || 'Failed to export character track.');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar pb-24 md:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Studio Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Users size={17} />
              <span className="text-xs font-bold uppercase tracking-wider">
                Batch Conversation Studio
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
              Multi-Character AI Dialogue &amp; Audio Mixer
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 max-w-2xl">
              Cast 2–10 characters with consistent AI voices, edit Telugu, Tanglish &amp; English scripts line by line, mix pauses, music &amp; SFX, and export the full episode or individual character tracks.
            </p>
          </div>

          {/* Starter Templates */}
          <div className="flex flex-wrap items-center gap-1.5">
            {STARTER_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                disabled={isBatchRunning}
                onClick={() => applyPreset(preset)}
                className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white dark:bg-zinc-900 hover:bg-indigo-600/15 border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-200 transition-colors whitespace-nowrap"
              >
                {preset.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setShowAiWriter((v) => !v)}
              className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
            >
              <Wand2 size={14} />
              <span>AI Script Writer</span>
              {showAiWriter ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>
          </div>
        </div>

        {/* Optional AI Conversation Script Generator Drawer */}
        {showAiWriter && (
          <div className="bg-white dark:bg-zinc-900/95 border border-indigo-500/40 rounded-2xl p-4 sm:p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                <Sparkles size={15} className="text-indigo-500" />
                <span>Generate Multi-Character Script &amp; Auto-Cast Voices</span>
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-6">
                <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                  Topic / Premise
                </label>
                <input
                  type="text"
                  value={aiTopic}
                  onChange={(e) => setAiTopic(e.target.value)}
                  placeholder="e.g., Friends arguing over splitting hostel Wi-Fi bill in funny Telangana Tanglish"
                  className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                  Characters (2–10)
                </label>
                <select
                  value={aiCharCount}
                  onChange={(e) => setAiCharCount(Number(e.target.value))}
                  className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-semibold text-zinc-900 dark:text-white"
                >
                  {[2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                    <option key={n} value={n}>
                      {n} Characters
                    </option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                  Dialogue Lines
                </label>
                <select
                  value={aiLineCount}
                  onChange={(e) => setAiLineCount(Number(e.target.value))}
                  className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-semibold text-zinc-900 dark:text-white"
                >
                  {[4, 6, 8, 10, 12, 16, 20].map((n) => (
                    <option key={n} value={n}>
                      {n} Lines
                    </option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2 flex items-end">
                <button
                  type="button"
                  disabled={isWritingScript || isBatchRunning}
                  onClick={handleAiGenerateScript}
                  className="w-full min-h-[42px] px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                >
                  {isWritingScript ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
                  <span>{isWritingScript ? 'Writing...' : 'Write Script'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main 12-Col Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column (4 cols): Character Roster & Advanced Controls */}
          <div className="lg:col-span-4 space-y-5">
            {/* Character Roster (2-10 Characters) */}
            <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                    <Users size={15} className="text-indigo-500" />
                    <span>Characters ({characters.length}/10)</span>
                  </h3>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    Each character keeps their assigned voice across every turn.
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={isAutoCasting || isBatchRunning}
                    onClick={handleAutoAssignVoices}
                    className="min-h-[36px] px-2.5 py-1 rounded-lg bg-indigo-600/15 hover:bg-indigo-600/25 text-indigo-600 dark:text-indigo-300 border border-indigo-500/30 text-xs font-semibold flex items-center gap-1 whitespace-nowrap"
                    title="Automatically cast distinct voices for each character"
                  >
                    {isAutoCasting ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
                    <span>Auto-Assign Voices</span>
                  </button>
                  <button
                    type="button"
                    disabled={characters.length >= 10 || isBatchRunning}
                    onClick={handleAddCharacter}
                    className="min-h-[36px] px-2.5 py-1 rounded-lg bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1 whitespace-nowrap"
                  >
                    <Plus size={13} />
                    <span>Add</span>
                  </button>
                </div>
              </div>

              {duplicateVoiceWarning && (
                <p className="text-[11px] text-amber-500 bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2">
                  Tip: Two characters share the same voice. Click <strong>Auto-Assign Voices</strong> or choose unique voices so every character sounds distinct.
                </p>
              )}

              <div className="space-y-2.5 max-h-[380px] overflow-y-auto custom-scrollbar pr-1">
                {characters.map((char, idx) => (
                  <div
                    key={char.id}
                    className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-950/75 border border-zinc-200 dark:border-zinc-800 space-y-2"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono font-bold text-indigo-500 w-5 shrink-0">
                        #{idx + 1}
                      </span>
                      <input
                        type="text"
                        value={char.name}
                        disabled={isBatchRunning}
                        onChange={(e) => handleUpdateCharacter(char.id, { name: e.target.value })}
                        placeholder="Character Name"
                        className="flex-1 min-w-0 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs font-bold text-zinc-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      {characters.length > 2 && (
                        <button
                          type="button"
                          disabled={isBatchRunning}
                          onClick={() => handleRemoveCharacter(char.id)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-red-500 transition-colors shrink-0"
                          aria-label={`Remove ${char.name}`}
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <select
                        value={char.role}
                        disabled={isBatchRunning}
                        onChange={(e) => handleUpdateCharacter(char.id, { role: e.target.value })}
                        aria-label={`${char.name} role`}
                        className="min-h-[36px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2 text-[11px] font-medium text-zinc-700 dark:text-zinc-200"
                      >
                        {CHARACTER_ROLES.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>

                      <select
                        value={char.voiceName}
                        disabled={isBatchRunning}
                        onChange={(e) =>
                          handleUpdateCharacter(char.id, { voiceName: e.target.value }, true)
                        }
                        aria-label={`Assigned AI voice for ${char.name}`}
                        className="min-h-[36px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2 text-[11px] font-semibold text-indigo-600 dark:text-indigo-300"
                      >
                        {voices.map((v) => (
                          <option key={v.name} value={v.name}>
                            {v.name} ({v.analysis.gender[0]} · {v.pitch}
                            {v.isCustom ? ' · Custom' : ''})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Scene, Language & Audio Mixing Controls */}
            <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                <Sliders size={14} className="text-indigo-500" />
                <span>Conversation &amp; Audio Controls</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Scene Style
                  </label>
                  <select
                    value={sceneType}
                    onChange={(e) => setSceneType(e.target.value as ConversationSceneType)}
                    className="w-full min-h-[40px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-2.5 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {SCENE_TYPES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1 flex items-center gap-1">
                    <Languages size={11} />
                    <span>Language</span>
                  </label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as LanguageMode)}
                    className="w-full min-h-[40px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-2.5 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    <option value="Telugu">తెలుగు (Telugu)</option>
                    <option value="Tanglish">Tanglish (TE+EN)</option>
                    <option value="English">English</option>
                  </select>
                </div>
              </div>

              {language !== 'English' && (
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Telugu Regional Accent
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['Telangana', 'Andhra', 'Standard'] as TeluguAccent[]).map((acc) => (
                      <button
                        key={acc}
                        type="button"
                        onClick={() => setAccent(acc)}
                        className={`min-h-[36px] rounded-xl text-xs font-semibold border transition-colors ${
                          accent === acc
                            ? 'bg-emerald-600 text-white border-emerald-500'
                            : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800'
                        }`}
                      >
                        {acc}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Pacing, Speed, Pitch */}
              <div className="space-y-3 bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3.5">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Pause Between Turns</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {pauseDurationSec.toFixed(2)}s
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={2.0}
                    step={0.05}
                    value={pauseDurationSec}
                    onChange={(e) => {
                      setPauseDurationSec(parseFloat(e.target.value));
                      if (readyCount > 0) setMixNeedsUpdate(true);
                    }}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Speaking Speed</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {speed.toFixed(2)}x
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={speed}
                    onChange={(e) => {
                      setSpeed(parseFloat(e.target.value));
                      if (readyCount > 0) setMixNeedsUpdate(true);
                    }}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Master Pitch Shift</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} st
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={1}
                    value={pitchSemitones}
                    onChange={(e) => {
                      setPitchSemitones(parseInt(e.target.value, 10));
                      if (readyCount > 0) setMixNeedsUpdate(true);
                    }}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Background Music & Sound Effects */}
              <div className="space-y-3 bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3.5">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1 flex items-center gap-1.5">
                    <Music size={12} className="text-indigo-500" />
                    <span>Background Music</span>
                  </label>
                  <select
                    value={bgmPreset}
                    onChange={(e) => {
                      setBgmPreset(e.target.value as ConversationBgmPreset);
                      if (readyCount > 0) setMixNeedsUpdate(true);
                    }}
                    className="w-full min-h-[38px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2.5 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {BGM_OPTIONS.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.label}
                      </option>
                    ))}
                  </select>
                </div>

                {bgmPreset !== 'none' && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-500 dark:text-zinc-400">Music Volume</span>
                      <span className="font-mono tabular-nums font-semibold text-indigo-500">
                        {Math.round((bgmVolume / 0.6) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={0.6}
                      step={0.03}
                      value={bgmVolume}
                      onChange={(e) => {
                        setBgmVolume(parseFloat(e.target.value));
                        if (readyCount > 0) setMixNeedsUpdate(true);
                      }}
                      className="w-full accent-indigo-500 cursor-pointer"
                    />
                  </div>
                )}

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400 flex items-center gap-1">
                      <Volume2 size={12} className="text-indigo-500" />
                      <span>SFX Cue Volume</span>
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {Math.round(sfxVolume * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={sfxVolume}
                    onChange={(e) => {
                      setSfxVolume(parseFloat(e.target.value));
                      if (readyCount > 0) setMixNeedsUpdate(true);
                    }}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column (8 cols): Dialogue Editor, Batch Bar, Master Mix & Stems */}
          <div className="lg:col-span-8 space-y-5">
            {/* Batch Execution Bar */}
            <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
                    Conversation Editor ({lines.length} Lines · {readyCount} Generated)
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Synthesizes all lines reliably in sequence and mixes pauses, music &amp; SFX.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {failedCount > 0 && !isBatchRunning && (
                    <button
                      type="button"
                      onClick={() => handleBatchGenerate(true)}
                      className="min-h-[42px] px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <RefreshCw size={14} />
                      <span>Retry Failed ({failedCount})</span>
                    </button>
                  )}

                  {isBatchRunning ? (
                    <button
                      type="button"
                      onClick={() => {
                        cancelBatchRef.current = true;
                      }}
                      className="min-h-[44px] px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs sm:text-sm font-bold flex items-center gap-2 whitespace-nowrap"
                    >
                      <Square size={14} className="fill-current" />
                      <span>Stop Batch</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleBatchGenerate(false)}
                      disabled={lines.every((l) => !l.text.trim())}
                      className="min-h-[44px] px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-sm whitespace-nowrap"
                    >
                      <Sparkles size={16} />
                      <span>Generate Conversation ({lines.length} Lines)</span>
                    </button>
                  )}
                </div>
              </div>

              {isBatchRunning && batchProgress.total > 0 && (
                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-600 dark:text-zinc-300 font-medium">
                      {batchProgress.currentLabel}
                    </span>
                    <span className="font-mono tabular-nums font-bold text-indigo-500">
                      {batchProgress.done} / {batchProgress.total}
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 transition-all duration-200"
                      style={{
                        width: `${Math.round((batchProgress.done / batchProgress.total) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {studioError && (
                <div className="flex items-start gap-2 px-3.5 py-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs sm:text-sm text-red-600 dark:text-red-300">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{studioError}</span>
                </div>
              )}
            </div>

            {/* Ordered Dialogue Rows */}
            <div className="space-y-3">
              {lines.map((line, index) => {
                const char =
                  characters.find((c) => c.id === line.characterId) || characters[0];
                const isSpeakingNow = activeSegment?.lineId === line.id;
                const isLinePlaying = playingTarget === line.id && playback.isPlaying;

                return (
                  <div
                    key={line.id}
                    className={`bg-white dark:bg-zinc-900/95 border rounded-2xl p-3.5 sm:p-4 space-y-3 transition-colors ${
                      isSpeakingNow || isLinePlaying
                        ? 'border-indigo-500 ring-1 ring-indigo-500/30'
                        : line.status === 'error'
                        ? 'border-red-500/40'
                        : 'border-zinc-200 dark:border-zinc-800'
                    }`}
                  >
                    {/* Top Row: Turn Index, Character Selector, Consistent Voice Badge, Move & Delete */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2 min-w-0">
                        <span className="font-mono text-xs font-bold text-zinc-400">
                          #{index + 1}
                        </span>

                        <select
                          value={char?.id || ''}
                          disabled={isBatchRunning}
                          onChange={(e) =>
                            handleUpdateLine(
                              line.id,
                              { characterId: e.target.value },
                              true
                            )
                          }
                          aria-label={`Character for line ${index + 1}`}
                          className="min-h-[36px] bg-zinc-100 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2.5 text-xs font-bold text-zinc-900 dark:text-white"
                        >
                          {characters.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>

                        <span className="text-[11px] font-medium text-indigo-600 dark:text-indigo-300">
                          Voice: {char?.voiceName}
                        </span>

                        {line.status === 'generating' && (
                          <span className="text-[11px] font-semibold text-indigo-500 flex items-center gap-1">
                            <Loader2 size={12} className="animate-spin" />
                            <span>Synthesizing...</span>
                          </span>
                        )}
                        {line.status === 'ready' && (
                          <span className="text-[11px] font-semibold text-emerald-500 flex items-center gap-1">
                            <CheckCircle2 size={12} />
                            <span>Ready</span>
                          </span>
                        )}
                      </div>

                      {/* Row Reorder / Preview / Delete */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          disabled={isBatchRunning || index === 0}
                          onClick={() => handleMoveLine(index, -1)}
                          className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg bg-zinc-100 dark:bg-zinc-800 disabled:opacity-35 text-zinc-600 dark:text-zinc-300"
                          title="Move line up"
                          aria-label="Move line up"
                        >
                          <ArrowUp size={13} />
                        </button>
                        <button
                          type="button"
                          disabled={isBatchRunning || index === lines.length - 1}
                          onClick={() => handleMoveLine(index, 1)}
                          className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg bg-zinc-100 dark:bg-zinc-800 disabled:opacity-35 text-zinc-600 dark:text-zinc-300"
                          title="Move line down"
                          aria-label="Move line down"
                        >
                          <ArrowDown size={13} />
                        </button>

                        {line.status === 'ready' && line.audioBase64 && (
                          <button
                            type="button"
                            onClick={() => handlePlayToggleAudio(line.id, line.audioBase64)}
                            className={`min-h-[34px] px-2.5 rounded-lg text-xs font-semibold flex items-center gap-1 whitespace-nowrap ${
                              isLinePlaying
                                ? 'bg-indigo-600 text-white'
                                : 'bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 text-white'
                            }`}
                          >
                            {isLinePlaying ? (
                              <Pause size={12} className="fill-current" />
                            ) : (
                              <Play size={12} className="fill-current" />
                            )}
                            <span>{isLinePlaying ? 'Pause' : 'Preview'}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          disabled={isBatchRunning || line.status === 'generating'}
                          onClick={() => handleGenerateSingleLine(line)}
                          className="min-h-[34px] px-2.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 text-xs font-semibold flex items-center gap-1 whitespace-nowrap"
                          title="Generate or regenerate this single dialogue line"
                        >
                          <RefreshCw size={12} />
                          <span className="hidden sm:inline">
                            {line.status === 'ready' ? 'Regen' : 'Gen'}
                          </span>
                        </button>

                        {lines.length > 1 && (
                          <button
                            type="button"
                            disabled={isBatchRunning}
                            onClick={() => handleDeleteLine(line.id)}
                            className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-red-500 transition-colors"
                            aria-label={`Delete line ${index + 1}`}
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Dialogue Textarea */}
                    <textarea
                      rows={2}
                      disabled={isBatchRunning}
                      value={line.text}
                      onChange={(e) =>
                        handleUpdateLine(line.id, { text: e.target.value }, true)
                      }
                      placeholder="Type Telugu, Tanglish, or English dialogue here... (supports <laugh>, <breath>, <gasp>)"
                      className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-y"
                    />

                    {/* Emotion, Style & SFX Row */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-zinc-500 dark:text-zinc-400 shrink-0">
                          Emotion:
                        </span>
                        <select
                          value={line.emotion}
                          disabled={isBatchRunning}
                          onChange={(e) =>
                            handleUpdateLine(line.id, { emotion: e.target.value }, true)
                          }
                          className="flex-1 min-h-[34px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2 text-xs text-zinc-800 dark:text-zinc-200"
                        >
                          {EMOTION_OPTIONS.map((em) => (
                            <option key={em} value={em}>
                              {em}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-zinc-500 dark:text-zinc-400 shrink-0">
                          Style:
                        </span>
                        <select
                          value={line.speakingStyle}
                          disabled={isBatchRunning}
                          onChange={(e) =>
                            handleUpdateLine(line.id, { speakingStyle: e.target.value }, true)
                          }
                          className="flex-1 min-h-[34px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2 text-xs text-zinc-800 dark:text-zinc-200"
                        >
                          {STYLE_OPTIONS.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-zinc-500 dark:text-zinc-400 shrink-0">
                          SFX Cue:
                        </span>
                        <select
                          value={line.sfxCue}
                          disabled={isBatchRunning}
                          onChange={(e) => {
                            handleUpdateLine(
                              line.id,
                              { sfxCue: e.target.value as ConversationSfxCue },
                              false
                            );
                            if (readyCount > 0) setMixNeedsUpdate(true);
                          }}
                          className="flex-1 min-h-[34px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-2 text-xs text-zinc-800 dark:text-zinc-200"
                        >
                          {SFX_OPTIONS.map((sfx) => (
                            <option key={sfx.id} value={sfx.id}>
                              {sfx.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {line.status === 'error' && line.error && (
                      <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-300">
                        <span>{line.error}</span>
                        <button
                          type="button"
                          onClick={() => handleGenerateSingleLine(line)}
                          className="px-2.5 py-1 rounded-lg bg-red-600 text-white text-[11px] font-semibold shrink-0"
                        >
                          Retry Line
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}

              <button
                type="button"
                disabled={isBatchRunning}
                onClick={handleAddLine}
                className="w-full min-h-[46px] rounded-2xl border border-dashed border-zinc-300 dark:border-zinc-700 hover:border-indigo-500 hover:bg-indigo-600/5 text-xs sm:text-sm font-semibold text-zinc-600 dark:text-zinc-300 flex items-center justify-center gap-2 transition-colors"
              >
                <MessageSquarePlus size={16} className="text-indigo-500" />
                <span>Add Dialogue Row</span>
              </button>
            </div>

            {/* Complete Master Mix & Export Suite (Only shown once ready audio exists) */}
            {(masterAudioBase64 || isMixing) && (
              <div className="space-y-4 pt-2">
                {mixNeedsUpdate && (
                  <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 rounded-2xl bg-indigo-600/10 border border-indigo-500/35 text-xs text-indigo-700 dark:text-indigo-200">
                    <span>
                      Pauses, speed, pitch, BGM, or dialogue order changed — apply mix to update the final export.
                    </span>
                    <button
                      type="button"
                      disabled={isMixing}
                      onClick={() => runMixConversation()}
                      className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5"
                    >
                      {isMixing ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
                      <span>Update Conversation Mix</span>
                    </button>
                  </div>
                )}

                {masterAudioBase64 && (
                  <>
                    {/* Live Conversation Visualizer & Timeline Indicator */}
                    <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
                            Complete Conversation Preview
                          </h3>
                          <p className="text-xs text-zinc-500 dark:text-zinc-400">
                            {activeSegment
                              ? `Now speaking: ${activeSegment.characterName}`
                              : `${characters.length} Characters · ${readyCount} Dialogue Turns`}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handlePlayToggleAudio('master', masterAudioBase64)}
                            className="min-h-[40px] px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5"
                          >
                            {playingTarget === 'master' && playback.isPlaying ? (
                              <Pause size={14} className="fill-current" />
                            ) : (
                              <Play size={14} className="fill-current" />
                            )}
                            <span>
                              {playingTarget === 'master' && playback.isPlaying
                                ? 'Pause'
                                : playingTarget === 'master' && playback.isPaused
                                ? 'Resume'
                                : 'Play Full Conversation'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={handleReplayMaster}
                            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300"
                            title="Replay conversation"
                          >
                            <RotateCcw size={14} />
                          </button>
                        </div>
                      </div>

                      <div className="h-20 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                        <AudioVisualizer
                          isPlaying={playingTarget === 'master' && playback.isPlaying}
                          color="#6366f1"
                          analyser={controllerRef.current?.getAnalyser() || null}
                        />
                      </div>
                    </div>

                    {/* Prominent Download to Phone Card */}
                    <GeneratedAudioResultCard
                      audioBase64={masterAudioBase64}
                      voiceName={`${sceneType.replace(/\s+/g, '_')}_Conversation_${characters.length}Chars`}
                      language={language}
                      accent={accent}
                      styleLabel={sceneType}
                      isGamingMode={sceneType === 'Gaming Conversation'}
                      durationSec={playingTarget === 'master' ? playback.duration : 0}
                      currentTimeSec={playingTarget === 'master' ? playback.currentTime : 0}
                      isPlaying={playingTarget === 'master' && playback.isPlaying}
                      isPaused={playingTarget === 'master' && playback.isPaused}
                      onPlayPause={() => handlePlayToggleAudio('master', masterAudioBase64)}
                      onReplay={handleReplayMaster}
                    />

                    {/* Individual Character Dialogue Track Stems */}
                    {characterTracks.length > 0 && (
                      <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
                              Individual Character Dialogue Tracks
                            </h3>
                            <p className="text-xs text-zinc-500 dark:text-zinc-400">
                              Preview or export isolated MP3 / WAV dialogue stems for each speaker.
                            </p>
                          </div>
                          {stemDownloadStatus && (
                            <span className="text-xs font-medium text-emerald-500">
                              {stemDownloadStatus}
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {characterTracks.map((track) => {
                            const stemKey = `stem:${track.characterId}`;
                            const isStemPlaying = playingTarget === stemKey && playback.isPlaying;
                            return (
                              <div
                                key={track.characterId}
                                className="p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-950/75 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3"
                              >
                                <div className="min-w-0">
                                  <p className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate">
                                    {track.characterName}
                                  </p>
                                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
                                    Voice: {track.voiceName} · {track.lineCount} lines ·{' '}
                                    {formatStudioTime(track.durationSec)}
                                  </p>
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handlePlayToggleAudio(stemKey, track.audioBase64)
                                    }
                                    className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-white ${
                                      isStemPlaying ? 'bg-indigo-600' : 'bg-zinc-800 hover:bg-indigo-600'
                                    }`}
                                    aria-label={`Play ${track.characterName} track`}
                                  >
                                    {isStemPlaying ? (
                                      <Pause size={13} className="fill-current" />
                                    ) : (
                                      <Play size={13} className="fill-current" />
                                    )}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDownloadStem(track, 'mp3')}
                                    className="min-h-[36px] px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 whitespace-nowrap"
                                  >
                                    <Download size={12} />
                                    <span>MP3</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDownloadStem(track, 'wav')}
                                    className="min-h-[36px] px-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white text-[11px] font-bold flex items-center gap-1 whitespace-nowrap"
                                  >
                                    <Download size={12} />
                                    <span>WAV</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchConversationStudioView;
