/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, RotateCcw, Loader2, Volume2, AlertCircle, ChevronDown } from 'lucide-react';
import { Voice } from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  StudioAudioController,
  StudioPlaybackState,
  formatStudioTime,
} from '../utils/audioStudioPlayer';

interface AiTtsPreviewProps {
  text: string;
  voices: Voice[];
  styleInstruction?: string;
  language?: string;
}

const AiTtsPreview: React.FC<AiTtsPreviewProps> = ({ text, voices, styleInstruction, language }) => {
  const [selectedVoiceName, setSelectedVoiceName] = useState(voices[0]?.name || '');
  const [playback, setPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cachedAudio, setCachedAudio] = useState<{ voice: string; text: string; base64: string } | null>(null);

  const controllerRef = useRef<StudioAudioController | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    controllerRef.current = new StudioAudioController((next) => {
      if (isMountedRef.current) setPlayback(next);
    });
    return () => {
      isMountedRef.current = false;
      controllerRef.current?.dispose();
      controllerRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (voices.length > 0 && !voices.find((v) => v.name === selectedVoiceName)) {
      setSelectedVoiceName(voices[0].name);
    }
  }, [voices, selectedVoiceName]);

  const isCurrentReady = Boolean(
    cachedAudio && cachedAudio.voice === selectedVoiceName && cachedAudio.text === text
  );

  const handlePlayPause = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (isLoading) return;

    const controller = controllerRef.current;
    if (!controller) return;

    if (playback.isPlaying) {
      controller.pause();
      return;
    }

    if (playback.isPaused && isCurrentReady) {
      await controller.play(false);
      return;
    }

    if (isCurrentReady && controller.hasAudio()) {
      await controller.play(true);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const selectedVoiceObj = voices.find((v) => v.name === selectedVoiceName);
      const baseVoice = selectedVoiceObj?.baseVoice || selectedVoiceName || 'Kore';
      const stylePrompt = selectedVoiceObj?.stylePrompt || styleInstruction || '';

      const res = await fetch('/api/voice-studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          baseVoice,
          stylePrompt: stylePrompt.slice(0, 600),
          language: selectedVoiceObj?.language || language,
          accent: selectedVoiceObj?.accent,
        }),
      });

      const data = await res.json();
      if (!isMountedRef.current) return;

      if (!res.ok || !data.audioBase64) {
        throw new Error(data.error || 'No audio data received from API');
      }

      setCachedAudio({ voice: selectedVoiceName, text, base64: data.audioBase64 });
      await controller.loadBase64(data.audioBase64);
      await controller.play(true);
    } catch (err: any) {
      console.error('TTS Error:', err);
      if (isMountedRef.current) {
        setError(err?.message || 'Failed to generate speech. Please try again.');
      }
    } finally {
      if (isMountedRef.current) setIsLoading(false);
    }
  };

  const handleReplay = async () => {
    if (controllerRef.current?.hasAudio()) {
      await controllerRef.current.replay();
    }
  };

  const selectedVoiceObj = voices.find((v) => v.name === selectedVoiceName);

  return (
    <div className="space-y-3">
      <div className="w-full bg-zinc-50 dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-700 overflow-hidden">
        <div className="p-3 sm:p-4 flex flex-wrap gap-3 items-center justify-between bg-white dark:bg-zinc-800 border-b border-zinc-100 dark:border-zinc-700">
          <div className="relative group flex-1 min-w-[160px]">
            <select
              value={selectedVoiceName}
              onChange={(e) => {
                controllerRef.current?.stop();
                setSelectedVoiceName(e.target.value);
              }}
              className="appearance-none w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 py-2 pl-3 pr-9 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/40 cursor-pointer"
              disabled={isLoading}
            >
              {voices.map((voice) => (
                <option key={voice.name} value={voice.name}>
                  {voice.name} ({voice.analysis.gender})
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-400">
              <ChevronDown size={14} />
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handlePlayPause}
              disabled={isLoading}
              className={`min-h-[40px] flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap shrink-0 ${
                playback.isPlaying
                  ? 'bg-zinc-200 dark:bg-zinc-700 text-zinc-900 dark:text-white'
                  : 'bg-zinc-900 dark:bg-indigo-600 text-white hover:bg-zinc-800 dark:hover:bg-indigo-500 shadow-sm'
              } ${isLoading ? 'cursor-not-allowed opacity-70' : ''}`}
            >
              {isLoading ? (
                <Loader2 size={15} className="animate-spin" />
              ) : playback.isPlaying ? (
                <Pause size={15} className="fill-current" />
              ) : (
                <Play size={15} className="fill-current" />
              )}
              <span>
                {isLoading
                  ? 'Generating...'
                  : playback.isPlaying
                  ? 'Pause'
                  : playback.isPaused && isCurrentReady
                  ? 'Resume'
                  : 'Listen'}
              </span>
            </button>

            {isCurrentReady && (
              <button
                type="button"
                onClick={handleReplay}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white"
                title="Replay from start"
                aria-label="Replay from start"
              >
                <RotateCcw size={15} />
              </button>
            )}
          </div>
        </div>

        <div
          className={`h-24 relative flex items-center justify-center bg-zinc-50 dark:bg-zinc-900 overflow-hidden ${
            isLoading ? 'cursor-not-allowed' : 'cursor-pointer'
          }`}
          onClick={handlePlayPause}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') handlePlayPause();
          }}
          aria-label={playback.isPlaying ? 'Pause audio preview' : 'Play audio preview'}
        >
          <div className="w-full h-full absolute inset-0 flex items-center justify-center pointer-events-none">
            {playback.isPlaying ? (
              <div className="w-full h-full opacity-90">
                <AudioVisualizer
                  isPlaying={true}
                  color={document.documentElement.classList.contains('dark') ? '#a5b4fc' : '#18181b'}
                  analyser={controllerRef.current?.getAnalyser() || null}
                />
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1.5 text-zinc-400 dark:text-zinc-500">
                <Volume2 size={22} />
                <span className="text-xs font-medium tabular-nums">
                  {playback.duration > 0 && isCurrentReady
                    ? `${formatStudioTime(playback.currentTime)} / ${formatStudioTime(playback.duration)}`
                    : 'Click to generate & preview speech'}
                </span>
              </div>
            )}
          </div>

          {error && (
            <div className="absolute inset-0 bg-zinc-50 dark:bg-zinc-900 flex items-center justify-center text-red-500 dark:text-red-400 gap-2 text-sm px-4 text-center z-20">
              <AlertCircle size={16} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>

      {/* Download to Phone Card — shown only after generation succeeds */}
      {isCurrentReady && cachedAudio && (
        <GeneratedAudioResultCard
          audioBase64={cachedAudio.base64}
          voiceName={selectedVoiceName}
          language={selectedVoiceObj?.language || language}
          accent={selectedVoiceObj?.accent}
          isCloned={Boolean(selectedVoiceObj?.isCloned)}
          durationSec={playback.duration}
          currentTimeSec={playback.currentTime}
          isPlaying={playback.isPlaying}
          isPaused={playback.isPaused}
          onPlayPause={() => handlePlayPause()}
          onReplay={handleReplay}
          compact
        />
      )}
    </div>
  );
};

export default AiTtsPreview;