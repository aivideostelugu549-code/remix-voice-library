/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Sparkles,
  Loader2,
  Play,
  Pause,
  RotateCcw,
  Square,
  Plus,
  AudioLines,
  Wand2,
  Check,
  AlertCircle,
  Mic,
  Upload,
  Languages,
  CopyCheck,
  ShieldCheck,
  Trash2,
  FolderOpen,
} from 'lucide-react';
import {
  Voice,
  VoiceDesignSuggestion,
  VoiceCloneAnalysis,
  LanguageMode,
  TeluguAccent,
  ImportedFileRecord,
} from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  StudioAudioController,
  StudioPlaybackState,
  checkClientEthicalVoicePolicy,
  formatStudioTime,
  formatBytes,
} from '../utils/audioStudioPlayer';
import {
  AUDIO_FILE_ACCEPT,
  detectFileFormatLabel,
  normalizeCloneAudioMimeType,
} from '../utils/fileVault';

interface VoiceCreatorModalProps {
  baseVoices: Voice[];
  existingNames: string[];
  onSaveVoice: (newVoice: Voice) => void;
  onClose: () => void;
  initialMode?: 'design' | 'clone';
  initialCloneFile?: ImportedFileRecord | null;
  initialCloneConsent?: boolean;
  vaultAudioFiles?: ImportedFileRecord[];
  onImportAudioFiles?: (
    files: File[],
    requiredKind?: 'audio' | 'script'
  ) => Promise<{ saved: ImportedFileRecord[]; rejected: string[] }>;
  onDeleteVaultFile?: (id: string) => Promise<void>;
}

const PRESETS_BY_LANG: Record<LanguageMode, { label: string; style: string; age: string; description: string }[]> = {
  English: [
    {
      label: 'Young Male Gamer',
      style: 'Gaming Commentary',
      age: 'Young Male Gamer (18-24)',
      description:
        'An energetic young male gaming commentator with fast, witty reactions, crisp hype energy, and genuine laugh-out-loud moments.',
    },
    {
      label: 'Cinematic Trailer',
      style: 'Cinematic',
      age: 'Mature / Elder',
      description:
        'A deep, resonant cinematic narrator with dramatic pauses, commanding presence, and smooth atmospheric gravitas.',
    },
    {
      label: 'Soft Cozy Friend',
      style: 'Soft',
      age: 'Young Adult (20s)',
      description:
        'A gentle, soft-spoken late-night storyteller with warm close-mic intimacy and unhurried friendly cadence.',
    },
  ],
  Telugu: [
    {
      label: 'యంగ్ తెలుగు గేమర్',
      style: 'Gaming Commentary',
      age: 'Young Male Gamer (18-24)',
      description:
        'A funny, energetic young male Telugu gaming commentator with lively Telangana punch, quick reactions, and casual conversational warmth.',
    },
    {
      label: 'ఆంధ్ర కథకుడు',
      style: 'Cinematic',
      age: 'Mid-30s Creator',
      description:
        'An expressive Andhra Telugu dramatic storyteller with melodic vowel clarity, natural sentence pauses, and gripping narration.',
    },
    {
      label: 'ఫన్నీ కామెడీ ఫ్రెండ్',
      style: 'Funny',
      age: 'Young Adult (20s)',
      description:
        'A humorous, playful conversational Telugu friend with witty sarcastic timing and upbeat everyday delivery.',
    },
  ],
  Tanglish: [
    {
      label: 'Tanglish Gamer Bro',
      style: 'Gaming Commentary',
      age: 'Young Male Gamer (18-24)',
      description:
        'A hyped young male Telugu gamer speaking natural Tanglish, seamlessly mixing Telugu reactions with English gaming callouts.',
    },
    {
      label: 'Sarcastic Roaster',
      style: 'Funny',
      age: 'Young Adult (20s)',
      description:
        'A witty, sarcastic urban creator blending Hyderabad Telugu cadence with dry English punchlines and expressive pauses.',
    },
    {
      label: 'Friendly Creator',
      style: 'Friendly',
      age: 'Young Adult (20s)',
      description:
        'A warm, welcoming Telugu-English tech and lifestyle host with crisp pronunciation and conversational energy.',
    },
  ],
};

const DEFAULT_SCRIPTS: Record<LanguageMode, string> = {
  English:
    'Hey everyone! <breath> This custom AI voice is tuned and ready for your stream, story, or studio track.',
  Telugu:
    'నమస్కారం మామా! <breath> ఇది మీ ప్రాజెక్ట్ కోసం ప్రత్యేకంగా రూపొందించిన నా కొత్త తెలుగు స్వరం.',
  Tanglish:
    'హాయ్ గైస్! <breath> ఈ వాయిస్ లో తెలుగు మరియు English మిక్స్ చేసి సూపర్ నాచురల్ గా మాట్లాడొచ్చు.',
};

const DEFAULT_STYLES: Record<LanguageMode, string> = {
  English: 'Warm, natural conversational delivery with steady pacing and clear pauses.',
  Telugu: 'Speak in fluent, natural Telugu (te-IN) with authentic pronunciation and clear pauses.',
  Tanglish: 'Speak in natural Telugu + English code-switched Tanglish with lively conversational rhythm.',
};

const PITCH_OPTIONS = ['Low', 'Medium-Low', 'Medium', 'Medium-High', 'High'];
const GENDER_OPTIONS = ['Male', 'Female', 'Neutral'];
const AGE_OPTIONS = [
  'Young Male Gamer (18-24)',
  'Young Adult (20s)',
  'Mid-30s Creator',
  'Mature / Elder',
];
const STYLE_OPTIONS = [
  'Funny',
  'Energetic',
  'Friendly',
  'Soft',
  'Cinematic',
  'Gaming Commentary',
];
const EMOTION_OPTIONS = ['Playful', 'Excited', 'Sarcastic', 'Warm', 'Soft / Calm', 'Dramatic'];

function estimatePitchHzFromBuffer(buffer: AudioBuffer): number | null {
  try {
    const channel = buffer.getChannelData(0);
    const sampleRate = buffer.sampleRate;
    const maxSamples = Math.min(channel.length, Math.floor(sampleRate * 1.5));
    const offset = Math.max(0, Math.floor((channel.length - maxSamples) / 2));
    const slice = channel.subarray(offset, offset + maxSamples);

    const minLag = Math.floor(sampleRate / 360);
    const maxLag = Math.floor(sampleRate / 75);
    const windowSize = Math.min(2048, slice.length - maxLag - 1);
    if (windowSize <= 256) return null;

    let bestLag = -1;
    let bestCorr = 0;
    for (let lag = minLag; lag <= maxLag; lag++) {
      let corr = 0;
      let normA = 0;
      let normB = 0;
      for (let i = 0; i < windowSize; i++) {
        const a = slice[i];
        const b = slice[i + lag];
        corr += a * b;
        normA += a * a;
        normB += b * b;
      }
      const denom = Math.sqrt(normA * normB);
      const r = denom > 0 ? corr / denom : 0;
      if (r > bestCorr) {
        bestCorr = r;
        bestLag = lag;
      }
    }

    if (bestLag > 0 && bestCorr > 0.35) {
      return Math.round(sampleRate / bestLag);
    }
    return null;
  } catch {
    return null;
  }
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Failed to read audio file.'));
    reader.readAsDataURL(blob);
  });
}

const VoiceCreatorModal: React.FC<VoiceCreatorModalProps> = ({
  baseVoices,
  existingNames,
  onSaveVoice,
  onClose,
  initialMode = 'design',
  initialCloneFile = null,
  initialCloneConsent = false,
  vaultAudioFiles = [],
  onImportAudioFiles,
  onDeleteVaultFile,
}) => {
  const [studioMode, setStudioMode] = useState<'design' | 'clone'>(initialMode);
  const [language, setLanguage] = useState<LanguageMode>('Telugu');
  const [teluguAccent, setTeluguAccent] = useState<TeluguAccent>('Telangana');

  const [concept, setConcept] = useState('');
  const [voiceName, setVoiceName] = useState('');
  const [baseVoice, setBaseVoice] = useState(baseVoices[0]?.name || 'Puck');
  const [gender, setGender] = useState('Male');
  const [pitch, setPitch] = useState('Medium');
  const [ageImpression, setAgeImpression] = useState('Young Male Gamer (18-24)');
  const [styleCategory, setStyleCategory] = useState('Gaming Commentary');
  const [emotion, setEmotion] = useState('Playful');
  const [speed, setSpeed] = useState(1.0);
  const [pitchSemitones, setPitchSemitones] = useState(0);
  const [energy, setEnergy] = useState(75);
  const [tagsInput, setTagsInput] = useState('Telugu, Gaming, Energetic, Custom');
  const [stylePrompt, setStylePrompt] = useState(DEFAULT_STYLES.Telugu);
  const [sampleText, setSampleText] = useState(DEFAULT_SCRIPTS.Telugu);

  // Ethical Voice Cloning state
  const [consentConfirmed, setConsentConfirmed] = useState(initialCloneConsent);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [referenceAudioUrl, setReferenceAudioUrl] = useState<string | null>(null);
  const [referenceAudioBase64, setReferenceAudioBase64] = useState<string | null>(null);
  const [referenceMimeType, setReferenceMimeType] = useState<string>('audio/wav');
  const [referenceStats, setReferenceStats] = useState<{
    durationSec: number;
    estimatedHz: number | null;
    label: string;
    sizeBytes?: number;
    formatLabel?: string;
    vaultId?: string;
  } | null>(null);
  const [cloneSummary, setCloneSummary] = useState<string | null>(null);
  const [isCloning, setIsCloning] = useState(false);

  const [isDesigning, setIsDesigning] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [previewAudioBase64, setPreviewAudioBase64] = useState<string | null>(null);
  const [previewDirty, setPreviewDirty] = useState(true);
  const [playback, setPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });

  const modalRef = useRef<HTMLDivElement>(null);
  const conceptRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const controllerRef = useRef<StudioAudioController | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const recordStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    controllerRef.current = new StudioAudioController((next) => setPlayback(next));
    conceptRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      controllerRef.current?.dispose();
      controllerRef.current = null;
      if (recordTimerRef.current) window.clearInterval(recordTimerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      recordStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, [onClose]);

  useEffect(() => {
    controllerRef.current?.setSpeed(speed);
  }, [speed]);

  useEffect(() => {
    controllerRef.current?.setPitch(pitchSemitones);
  }, [pitchSemitones]);

  useEffect(() => {
    return () => {
      if (referenceAudioUrl) URL.revokeObjectURL(referenceAudioUrl);
    };
  }, [referenceAudioUrl]);

  const stopPlayback = () => {
    controllerRef.current?.stop();
  };

  const handleLanguageSwitch = (nextLang: LanguageMode) => {
    if (nextLang === language) return;
    setLanguage(nextLang);
    if (Object.values(DEFAULT_SCRIPTS).includes(sampleText.trim()) || !sampleText.trim()) {
      setSampleText(DEFAULT_SCRIPTS[nextLang]);
    }
    if (Object.values(DEFAULT_STYLES).includes(stylePrompt.trim()) || !stylePrompt.trim()) {
      setStylePrompt(DEFAULT_STYLES[nextLang]);
    }
    setPreviewDirty(true);
    stopPlayback();
  };

  const loadReferenceBlob = async (
    blob: Blob,
    label: string,
    options?: { vaultId?: string; formatLabel?: string; mimeType?: string }
  ) => {
    setError(null);
    setCloneSummary(null);

    if (blob.size > 15 * 1024 * 1024) {
      setError('Audio file is too large. Please use a clip under 15 MB (3–30 seconds recommended).');
      return;
    }

    try {
      const base64 = await blobToBase64(blob);
      const url = URL.createObjectURL(blob);
      setReferenceAudioUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
      setReferenceAudioBase64(base64);
      const normalizedMime = normalizeCloneAudioMimeType(
        options?.mimeType || blob.type,
        label
      );
      const formatLabel =
        options?.formatLabel || detectFileFormatLabel(label, normalizedMime);
      setReferenceMimeType(normalizedMime);

      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        const arrayBuf = await blob.arrayBuffer();
        const decoded = await ctx.decodeAudioData(arrayBuf);
        const estHz = estimatePitchHzFromBuffer(decoded);
        setReferenceStats({
          durationSec: Number(decoded.duration.toFixed(1)),
          estimatedHz: estHz,
          label,
          sizeBytes: blob.size,
          formatLabel,
          vaultId: options?.vaultId,
        });
        await ctx.close().catch(() => {});
      } catch {
        setReferenceStats({
          durationSec: 0,
          estimatedHz: null,
          label,
          sizeBytes: blob.size,
          formatLabel,
          vaultId: options?.vaultId,
        });
      }
    } catch (err: any) {
      setError(err?.message || 'Could not process reference audio.');
    }
  };

  useEffect(() => {
    if (initialCloneFile && initialCloneFile.kind === 'audio') {
      setStudioMode('clone');
      setConsentConfirmed(Boolean(initialCloneConsent));
      loadReferenceBlob(initialCloneFile.blob, initialCloneFile.name, {
        vaultId: initialCloneFile.id,
        formatLabel: initialCloneFile.formatLabel,
        mimeType: initialCloneFile.mimeType,
      });
    }
  }, [initialCloneFile, initialCloneConsent]);

  const clearReferenceAudio = async (alsoDeleteFromVault = false) => {
    const vaultId = referenceStats?.vaultId;
    setReferenceAudioUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });
    setReferenceAudioBase64(null);
    setReferenceStats(null);
    setCloneSummary(null);
    if (alsoDeleteFromVault && vaultId && onDeleteVaultFile) {
      await onDeleteVaultFile(vaultId).catch(() => {});
    }
  };

  const startRecording = async () => {
    setError(null);
    stopPlayback();

    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Microphone recording is unavailable in this browser. Please upload an audio file instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordStreamRef.current = stream;
      const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : '';
      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      recordChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        if (recordTimerRef.current) {
          window.clearInterval(recordTimerRef.current);
          recordTimerRef.current = null;
        }
        stream.getTracks().forEach((t) => t.stop());
        recordStreamRef.current = null;
        setIsRecording(false);

        const mime = recorder.mimeType || 'audio/webm';
        const blob = new Blob(recordChunksRef.current, { type: mime });
        if (blob.size > 0) {
          await loadReferenceBlob(blob, 'Microphone Recording');
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => {
          if (s >= 29) {
            recorder.stop();
            return 30;
          }
          return s + 1;
        });
      }, 1000);
    } catch (err: any) {
      setError(err?.message || 'Microphone permission denied. Please upload an audio sample instead.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    if (onImportAudioFiles) {
      const { saved, rejected } = await onImportAudioFiles([file], 'audio');
      if (saved.length > 0) {
        const rec = saved[0];
        await loadReferenceBlob(rec.blob, rec.name, {
          vaultId: rec.id,
          formatLabel: rec.formatLabel,
          mimeType: rec.mimeType,
        });
        return;
      }
      if (rejected.length > 0) {
        setError(rejected.join(' '));
        return;
      }
    }

    await loadReferenceBlob(file, file.name);
  };

  const applySuggestedMetadata = (data: VoiceDesignSuggestion) => {
    if (data.suggestedName) {
      let candidateName = data.suggestedName.trim();
      if (existingNames.some((n) => n.toLowerCase() === candidateName.toLowerCase())) {
        candidateName = `${candidateName} ${language === 'English' ? 'Studio' : 'TE'}`;
      }
      setVoiceName(candidateName);
    }

    if (data.baseVoice && baseVoices.some((v) => v.name === data.baseVoice)) {
      setBaseVoice(data.baseVoice);
    }
    if (data.gender) setGender(data.gender);
    if (data.pitch && PITCH_OPTIONS.includes(data.pitch)) setPitch(data.pitch);
    if (data.ageImpression) setAgeImpression(data.ageImpression);
    if (data.styleCategory) setStyleCategory(data.styleCategory);
    if (data.emotion) setEmotion(data.emotion);
    if (Array.isArray(data.characteristics) && data.characteristics.length > 0) {
      setTagsInput(data.characteristics.join(', '));
    }
    if (data.stylePrompt) setStylePrompt(data.stylePrompt);
    if (data.sampleText) setSampleText(data.sampleText);

    setPreviewAudioBase64(null);
    setPreviewDirty(true);
  };

  const handleCloneAnalyze = async () => {
    if (!consentConfirmed) {
      setError('Please confirm ethical consent before analyzing or cloning a voice.');
      return;
    }
    if (!referenceAudioBase64) {
      setError('Please record or upload a reference audio sample first.');
      return;
    }

    const policyErr = checkClientEthicalVoicePolicy(`${voiceName} ${stylePrompt}`);
    if (policyErr) {
      setError(policyErr);
      return;
    }

    setIsCloning(true);
    setError(null);
    stopPlayback();

    try {
      const simplifiedVoices = baseVoices.map((v) => ({
        name: v.name,
        gender: v.analysis.gender,
        pitch: v.analysis.pitch,
        characteristics: v.analysis.characteristics,
      }));

      const res = await fetch('/api/voice-studio/clone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: referenceAudioBase64,
          mimeType: referenceMimeType.split(';')[0] || 'audio/webm',
          targetLanguage: language,
          teluguAccent,
          availableVoices: simplifiedVoices,
          consentConfirmed,
          speakerLabel: voiceName,
        }),
      });

      const data: VoiceCloneAnalysis & { error?: string } = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to analyze reference audio.');
      }

      applySuggestedMetadata(data);
      if (data.detectedTraitsSummary) {
        setCloneSummary(data.detectedTraitsSummary);
      }

      // Immediately synthesize the cloned audition audio so the result card + Download to Phone appears
      if (data.sampleText) {
        await synthesizePreview(
          data.sampleText,
          data.baseVoice && baseVoices.some((v) => v.name === data.baseVoice)
            ? data.baseVoice
            : baseVoice,
          data.stylePrompt || stylePrompt
        );
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to analyze reference audio.');
    } finally {
      setIsCloning(false);
    }
  };

  const handleAutoDesign = async (overrideConcept?: string, overrideStyle?: string, overrideAge?: string) => {
    const query = (overrideConcept ?? concept).trim();
    if (!query) return;

    const policyErr = checkClientEthicalVoicePolicy(query);
    if (policyErr) {
      setError(policyErr);
      return;
    }

    setIsDesigning(true);
    setError(null);
    stopPlayback();

    try {
      const simplifiedVoices = baseVoices.map((v) => ({
        name: v.name,
        gender: v.analysis.gender,
        pitch: v.analysis.pitch,
        characteristics: v.analysis.characteristics,
      }));

      const targetStyle = overrideStyle || styleCategory;
      const targetAge = overrideAge || ageImpression;

      const res = await fetch('/api/voice-studio/design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: query,
          language,
          teluguAccent,
          gender,
          ageImpression: targetAge,
          styleCategory: targetStyle,
          emotion,
          energy,
          speed,
          pitchLevel: pitch,
          gamingMode: targetStyle === 'Gaming Commentary',
          availableVoices: simplifiedVoices,
        }),
      });

      const data: VoiceDesignSuggestion & { error?: string } = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to design voice persona.');
      }

      applySuggestedMetadata(data);
    } catch (err: any) {
      setError(err?.message || 'Failed to design voice persona.');
    } finally {
      setIsDesigning(false);
    }
  };

  const synthesizePreview = async (
    overrideText?: string,
    overrideBase?: string,
    overrideStyle?: string
  ): Promise<string | null> => {
    const textToSpeak = (overrideText ?? sampleText).trim();
    const baseToUse = overrideBase ?? baseVoice;
    const styleToUse = (overrideStyle ?? stylePrompt).trim();

    if (!textToSpeak) {
      setError('Please enter sample text to generate a voice preview.');
      return null;
    }

    const policyErr = checkClientEthicalVoicePolicy(`${voiceName} ${styleToUse} ${textToSpeak}`);
    if (policyErr) {
      setError(policyErr);
      return null;
    }

    setIsGeneratingAudio(true);
    setError(null);
    stopPlayback();

    try {
      const res = await fetch('/api/voice-studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToSpeak,
          baseVoice: baseToUse,
          stylePrompt: styleToUse,
          language,
          accent: language === 'English' ? 'Standard' : teluguAccent,
          ageImpression,
          emotion,
          energy,
          speed,
          pitchSemitones,
          gamingStyle: styleCategory === 'Gaming Commentary' ? 'Gaming Commentary' : undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.audioBase64) {
        throw new Error(data.error || 'Failed to generate audio preview.');
      }

      setPreviewAudioBase64(data.audioBase64);
      setPreviewDirty(false);
      if (controllerRef.current) {
        await controllerRef.current.loadBase64(data.audioBase64);
        controllerRef.current.setSpeed(speed);
        controllerRef.current.setPitch(pitchSemitones);
      }
      return data.audioBase64;
    } catch (err: any) {
      setError(err?.message || 'Failed to generate audio preview.');
      return null;
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  const handlePlayPause = async () => {
    if (isGeneratingAudio) return;
    const controller = controllerRef.current;
    if (!controller) return;

    if (playback.isPlaying) {
      controller.pause();
      return;
    }

    if (previewAudioBase64 && !previewDirty && controller.hasAudio()) {
      await controller.play(false);
      return;
    }

    const b64 = await synthesizePreview();
    if (b64) {
      await controller.play(true);
    }
  };

  const handleReplay = async () => {
    if (controllerRef.current?.hasAudio()) {
      await controllerRef.current.replay();
    }
  };

  const handleSave = async () => {
    const trimmedName = voiceName.trim();
    if (!trimmedName) {
      setError('Please give your voice a name.');
      return;
    }

    if (studioMode === 'clone' && !consentConfirmed) {
      setError('You must confirm ethical speaker consent before saving a cloned voice.');
      return;
    }

    const policyErr = checkClientEthicalVoicePolicy(`${trimmedName} ${stylePrompt}`);
    if (policyErr) {
      setError(policyErr);
      return;
    }

    if (existingNames.some((n) => n.toLowerCase() === trimmedName.toLowerCase())) {
      setError(`A voice named "${trimmedName}" already exists. Please choose a unique name.`);
      return;
    }

    setIsSaving(true);
    setError(null);

    let audioB64 = previewAudioBase64;
    if (!audioB64 || previewDirty) {
      audioB64 = await synthesizePreview();
      if (!audioB64) {
        setIsSaving(false);
        return;
      }
    }

    const parsedTags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const characteristics = parsedTags.length > 0 ? parsedTags : ['Custom', language];

    const selectedBaseObj = baseVoices.find((v) => v.name === baseVoice);

    const newVoice: Voice = {
      name: trimmedName,
      pitch,
      characteristics: characteristics.slice(0, 2),
      audioSampleUrl: `data:audio/wav;base64,${audioB64}`,
      fileUri: '',
      imageUrl: selectedBaseObj?.imageUrl || '',
      isCustom: true,
      isCloned: studioMode === 'clone',
      language,
      accent: language === 'English' ? 'Standard' : teluguAccent,
      ageImpression,
      styleCategory,
      emotion,
      speed,
      pitchSemitones,
      energy,
      isGamingMode: styleCategory === 'Gaming Commentary',
      consentConfirmed: studioMode === 'clone' ? consentConfirmed : undefined,
      baseVoice,
      stylePrompt: stylePrompt.trim(),
      sampleText: sampleText.trim(),
      analysis: {
        gender,
        pitch,
        characteristics,
        visualDescription: stylePrompt.trim(),
      },
    };

    setIsSaving(false);
    stopPlayback();
    onSaveVoice(newVoice);
  };

  const insertBurst = (token: string) => {
    setSampleText((prev) =>
      prev.endsWith(' ') || prev.length === 0 ? `${prev}${token} ` : `${prev} ${token} `
    );
    setPreviewDirty(true);
  };

  const markDirty = () => {
    setPreviewDirty(true);
    if (playback.isPlaying) stopPlayback();
  };

  const activePresets = PRESETS_BY_LANG[language];

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="voice-creator-title"
    >
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      <div
        ref={modalRef}
        className="relative w-full max-w-5xl max-h-[94vh] bg-white dark:bg-zinc-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-slide-up border border-zinc-200 dark:border-zinc-800 flex flex-col"
      >
        {/* Header */}
        <div className="px-5 sm:px-7 pt-5 pb-4 border-b border-zinc-100 dark:border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 mb-0.5">
              <AudioLines size={17} />
              <span className="text-xs font-bold tracking-wider uppercase">
                AI Voice Creator &amp; Ethical Cloning
              </span>
            </div>
            <h2
              id="voice-creator-title"
              className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-white"
            >
              {studioMode === 'clone' ? 'Clone Your Permitted Voice' : 'Create Custom AI Voice'}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Language Toggle */}
            <div className="inline-flex items-center bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl border border-zinc-200 dark:border-zinc-700">
              <Languages size={13} className="text-zinc-400 ml-1.5 mr-1" />
              {(['English', 'Telugu', 'Tanglish'] as LanguageMode[]).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => handleLanguageSwitch(lang)}
                  className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    language === lang
                      ? 'bg-white dark:bg-indigo-600 text-zinc-900 dark:text-white shadow-sm'
                      : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  {lang === 'Telugu' ? 'తెలుగు' : lang}
                </button>
              ))}
            </div>

            <button
              onClick={onClose}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
              aria-label="Close voice creator"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Mode Tabs */}
        <div className="px-5 sm:px-7 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between gap-2 shrink-0 bg-zinc-50/50 dark:bg-zinc-950/40 overflow-x-auto">
          <div className="flex gap-1">
            <button
              type="button"
              onClick={() => setStudioMode('design')}
              className={`min-h-[44px] flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
                studioMode === 'design'
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Wand2 size={15} />
              <span>AI Voice Creator</span>
            </button>
            <button
              type="button"
              onClick={() => setStudioMode('clone')}
              className={`min-h-[44px] flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
                studioMode === 'clone'
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <CopyCheck size={15} />
              <span>Ethical Voice Cloning</span>
            </button>
          </div>

          {language !== 'English' && (
            <div className="flex items-center gap-1.5 py-1.5 shrink-0">
              <span className="text-[11px] font-semibold text-zinc-400 hidden sm:inline">Accent:</span>
              {(['Andhra', 'Telangana', 'Standard'] as TeluguAccent[]).map((acc) => (
                <button
                  key={acc}
                  type="button"
                  onClick={() => {
                    setTeluguAccent(acc);
                    markDirty();
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-colors ${
                    teluguAccent === acc
                      ? 'bg-amber-500/15 border-amber-500/50 text-amber-600 dark:text-amber-300'
                      : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-700 text-zinc-500 dark:text-zinc-400'
                  }`}
                >
                  {acc}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Scrollable Studio Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-7 space-y-5">
          {studioMode === 'design' ? (
            <div className="bg-zinc-50 dark:bg-zinc-800/40 rounded-2xl p-4 sm:p-5 border border-zinc-200/80 dark:border-zinc-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label
                  htmlFor="voice-concept-input"
                  className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5"
                >
                  <Wand2 size={14} className="text-indigo-500" />
                  Describe Original AI Voice ({language}
                  {language !== 'English' ? ` · ${teluguAccent}` : ''})
                </label>
                <span className="text-[11px] text-zinc-400">Original personas only — no celebrity imitation</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <textarea
                  id="voice-concept-input"
                  ref={conceptRef}
                  rows={2}
                  value={concept}
                  onChange={(e) => setConcept(e.target.value)}
                  placeholder={
                    language === 'Telugu'
                      ? 'ఉదా: ఉత్సాహంగా తెలుగు గేమింగ్ కామెంటరీ చెప్పే యువకుడి స్వరం...'
                      : language === 'Tanglish'
                      ? 'e.g. A funny young Telugu gaming streamer mixing Telugu comedy and English callouts...'
                      : 'e.g. A hyped young male gaming commentator with energetic comedic reactions...'
                  }
                  className="flex-1 bg-white dark:bg-zinc-950 rounded-xl px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 border border-zinc-200 dark:border-zinc-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-none"
                  disabled={isDesigning}
                />
                <button
                  type="button"
                  onClick={() => handleAutoDesign()}
                  disabled={isDesigning || !concept.trim()}
                  className="min-h-[44px] sm:w-44 shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold transition-colors"
                >
                  {isDesigning ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                  <span>{isDesigning ? 'Designing...' : 'Auto-Design'}</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wide mr-1">
                  Quick Presets:
                </span>
                {activePresets.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setConcept(preset.description);
                      setStyleCategory(preset.style);
                      setAgeImpression(preset.age);
                      handleAutoDesign(preset.description, preset.style, preset.age);
                    }}
                    disabled={isDesigning}
                    className="min-h-[34px] px-3 py-1 text-xs font-medium rounded-xl bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:border-indigo-500/60 transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-zinc-50 dark:bg-zinc-800/40 rounded-2xl p-4 sm:p-5 border border-zinc-200/80 dark:border-zinc-800 space-y-4">
              {/* Ethical Cloning Policy & Consent */}
              <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-3.5 space-y-2.5">
                <div className="flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-200">
                  <ShieldCheck size={17} className="shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
                  <div className="space-y-1">
                    <p className="font-semibold">
                      Ethical Voice Cloning &amp; Acoustic Timbre Matching
                    </p>
                    <p className="opacity-90 leading-relaxed">
                      Clone only your own voice or voices with explicit speaker permission. Never imitate celebrities or other people without permission. Gemini analyzes your sample’s pitch, cadence, and accent to match the closest base timbre and style direction (biometric speaker cloning is not used).
                    </p>
                  </div>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-zinc-800 dark:text-zinc-200 pt-1">
                  <input
                    type="checkbox"
                    checked={consentConfirmed}
                    onChange={(e) => setConsentConfirmed(e.target.checked)}
                    className="mt-0.5 w-4 h-4 accent-indigo-600 rounded cursor-pointer shrink-0"
                  />
                  <span className="font-medium leading-snug">
                    I confirm this audio is my own voice or I have explicit permission from the speaker, and I will not use it to impersonate celebrities or others.
                  </span>
                </label>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 flex items-center gap-1.5">
                    <Mic size={14} className="text-indigo-500" />
                    Reference Audio Sample (3–30s)
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                    Record via microphone or select MP3, WAV, M4A, AAC, OGG, or WebM from your phone.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={AUDIO_FILE_ACCEPT}
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {!isRecording ? (
                    <button
                      type="button"
                      onClick={startRecording}
                      disabled={isCloning}
                      className="min-h-[44px] flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors"
                    >
                      <Mic size={14} />
                      <span>Record Mic</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopRecording}
                      className="min-h-[44px] flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-xs font-semibold"
                    >
                      <Square size={12} className="fill-current" />
                      <span>Stop ({recordingSeconds}s)</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isRecording || isCloning}
                    className="min-h-[44px] flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 hover:border-indigo-500/60 text-xs font-semibold transition-colors"
                  >
                    <Upload size={14} />
                    <span>Import Audio</span>
                  </button>
                </div>
              </div>

              {vaultAudioFiles.length > 0 && (
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-500 dark:text-zinc-400 shrink-0">
                    <FolderOpen size={14} className="text-indigo-500" />
                    <span>From File Manager:</span>
                  </div>
                  <select
                    value={referenceStats?.vaultId || ''}
                    onChange={(e) => {
                      const picked = vaultAudioFiles.find((f) => f.id === e.target.value);
                      if (picked) {
                        loadReferenceBlob(picked.blob, picked.name, {
                          vaultId: picked.id,
                          formatLabel: picked.formatLabel,
                          mimeType: picked.mimeType,
                        });
                      }
                    }}
                    className="flex-1 min-h-[40px] bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                    aria-label="Choose an audio file from File Manager"
                  >
                    <option value="" disabled>
                      Select imported audio ({vaultAudioFiles.length})...
                    </option>
                    {vaultAudioFiles.map((file) => (
                      <option key={file.id} value={file.id}>
                        {file.name} ({file.formatLabel} · {formatBytes(file.size)})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {referenceAudioUrl && (
                <div className="bg-white dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-600 dark:text-zinc-300 tabular-nums">
                      <span className="font-semibold text-zinc-900 dark:text-white truncate">
                        {referenceStats?.label || 'Reference Clip'}
                      </span>
                      {referenceStats?.formatLabel && (
                        <span className="text-zinc-500 dark:text-zinc-400">
                          · {referenceStats.formatLabel}
                        </span>
                      )}
                      {typeof referenceStats?.sizeBytes === 'number' && (
                        <span className="text-zinc-400">
                          · {formatBytes(referenceStats.sizeBytes)}
                        </span>
                      )}
                      {referenceStats && referenceStats.durationSec > 0 && (
                        <span className="font-mono text-zinc-400">
                          · {referenceStats.durationSec}s
                        </span>
                      )}
                      {referenceStats?.estimatedHz && (
                        <span className="font-mono text-indigo-500 dark:text-indigo-400">
                          · ~{referenceStats.estimatedHz} Hz
                        </span>
                      )}
                    </div>
                    <audio controls src={referenceAudioUrl} className="w-full h-9" />
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => clearReferenceAudio(Boolean(referenceStats?.vaultId))}
                      disabled={isCloning}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-500 hover:text-red-500 transition-colors"
                      title={referenceStats?.vaultId ? 'Delete imported file' : 'Remove clip'}
                      aria-label={referenceStats?.vaultId ? 'Delete imported file' : 'Remove clip'}
                    >
                      <Trash2 size={15} />
                    </button>

                    <button
                      type="button"
                      onClick={handleCloneAnalyze}
                      disabled={isCloning || !consentConfirmed}
                      className="min-h-[44px] shrink-0 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap"
                    >
                      {isCloning ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
                      <span>{isCloning ? 'Analyzing Sample...' : 'Analyze & Clone'}</span>
                    </button>
                  </div>
                </div>
              )}

              {cloneSummary && (
                <div className="px-3.5 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
                  <Check size={14} className="mt-0.5 shrink-0" />
                  <div>
                    <span className="font-semibold">Acoustic Profile Matched: </span>
                    <span>{cloneSummary}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Voice Parameters Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column: Identity & Acoustic Controls */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Voice Name *
                  </label>
                  <input
                    type="text"
                    value={voiceName}
                    onChange={(e) => setVoiceName(e.target.value)}
                    placeholder={language === 'English' ? 'e.g. Blaze Gamer' : 'e.g. హైదరాబాద్ రాజు'}
                    maxLength={32}
                    className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Voice Style
                  </label>
                  <select
                    value={styleCategory}
                    onChange={(e) => {
                      setStyleCategory(e.target.value);
                      markDirty();
                    }}
                    className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2 text-sm text-zinc-900 dark:text-white"
                  >
                    {STYLE_OPTIONS.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Base Timbre
                  </label>
                  <select
                    value={baseVoice}
                    onChange={(e) => {
                      const nextBase = e.target.value;
                      setBaseVoice(nextBase);
                      const found = baseVoices.find((v) => v.name === nextBase);
                      if (found) setGender(found.analysis.gender);
                      markDirty();
                    }}
                    className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2 text-sm text-zinc-900 dark:text-white"
                  >
                    {baseVoices.map((v) => (
                      <option key={v.name} value={v.name}>
                        {v.name} ({v.analysis.gender}, {v.pitch})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Age Impression
                  </label>
                  <select
                    value={ageImpression}
                    onChange={(e) => {
                      setAgeImpression(e.target.value);
                      markDirty();
                    }}
                    className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2 text-sm text-zinc-900 dark:text-white"
                  >
                    {AGE_OPTIONS.map((age) => (
                      <option key={age} value={age}>
                        {age}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Gender
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-2.5 text-xs sm:text-sm text-zinc-900 dark:text-white"
                  >
                    {GENDER_OPTIONS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Pitch Profile
                  </label>
                  <select
                    value={pitch}
                    onChange={(e) => setPitch(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-2.5 text-xs sm:text-sm text-zinc-900 dark:text-white"
                  >
                    {PITCH_OPTIONS.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Emotion
                  </label>
                  <select
                    value={emotion}
                    onChange={(e) => {
                      setEmotion(e.target.value);
                      markDirty();
                    }}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-2.5 text-xs sm:text-sm text-zinc-900 dark:text-white"
                  >
                    {EMOTION_OPTIONS.map((em) => (
                      <option key={em} value={em}>
                        {em}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Speed, Pitch & Energy Sliders */}
              <div className="grid grid-cols-3 gap-3 bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3">
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500 dark:text-zinc-400">Speed</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">{speed.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500 dark:text-zinc-400">Pitch</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} st
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={1}
                    value={pitchSemitones}
                    onChange={(e) => setPitchSemitones(parseInt(e.target.value, 10))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-zinc-500 dark:text-zinc-400">Energy</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">{energy}%</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={energy}
                    onChange={(e) => {
                      setEnergy(parseInt(e.target.value, 10));
                      markDirty();
                    }}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                  Trait Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="Energetic, Telugu, Funny, Gamer"
                  className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2 text-sm text-zinc-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">
                  Style &amp; Delivery Direction
                </label>
                <textarea
                  rows={2}
                  value={stylePrompt}
                  onChange={(e) => {
                    setStylePrompt(e.target.value);
                    markDirty();
                  }}
                  placeholder="Describe tone, regional accent, pauses, and emotion..."
                  className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white resize-none"
                />
              </div>
            </div>

            {/* Right Column: Script & Live Audition */}
            <div className="space-y-4 flex flex-col">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                    Audition Script ({language})
                  </label>
                  <div className="flex items-center gap-1">
                    {['<breath>', '<laugh>', '<gasp>', '...'].map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => insertBurst(tag)}
                        className="px-2 py-1 text-[11px] font-mono rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:text-indigo-500 transition-colors"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  rows={4}
                  value={sampleText}
                  onChange={(e) => {
                    setSampleText(e.target.value);
                    markDirty();
                  }}
                  placeholder={
                    language === 'Telugu'
                      ? 'తెలుగులో టెక్స్ట్ రాయండి...'
                      : 'Write a line for your new voice to speak...'
                  }
                  className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white resize-none"
                />
              </div>

              {/* Audition Player */}
              <div className="min-h-[148px] bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden flex flex-col">
                <div className="px-4 py-3 bg-white dark:bg-zinc-900 border-b border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handlePlayPause}
                      disabled={isGeneratingAudio || !sampleText.trim()}
                      className="min-h-[40px] flex items-center gap-2 px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold transition-colors"
                    >
                      {isGeneratingAudio ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : playback.isPlaying ? (
                        <Pause size={14} className="fill-current" />
                      ) : (
                        <Play size={14} className="fill-current" />
                      )}
                      <span>
                        {isGeneratingAudio
                          ? 'Synthesizing...'
                          : playback.isPlaying
                          ? 'Pause'
                          : playback.isPaused
                          ? 'Resume'
                          : previewAudioBase64 && !previewDirty
                          ? 'Play Preview'
                          : studioMode === 'clone'
                          ? 'Generate Cloned Preview'
                          : 'Generate Preview'}
                      </span>
                    </button>

                    {previewAudioBase64 && !previewDirty && (
                      <button
                        type="button"
                        onClick={handleReplay}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white"
                        title="Replay"
                        aria-label="Replay"
                      >
                        <RotateCcw size={14} />
                      </button>
                    )}
                  </div>

                  {previewAudioBase64 && !previewDirty && (
                    <span className="text-[11px] font-mono tabular-nums text-zinc-400">
                      {formatStudioTime(playback.currentTime)} / {formatStudioTime(playback.duration)}
                    </span>
                  )}
                </div>

                <div className="flex-1 relative flex items-center justify-center p-4">
                  {playback.isPlaying ? (
                    <div className="w-full h-20">
                      <AudioVisualizer
                        isPlaying={true}
                        color="#6366f1"
                        analyser={controllerRef.current?.getAnalyser() || null}
                      />
                    </div>
                  ) : (
                    <div className="text-center text-xs text-zinc-500 dark:text-zinc-400 space-y-1">
                      <p className="font-medium">
                        {previewAudioBase64 && !previewDirty
                          ? 'Voice generation succeeded. Preview or download to phone below.'
                          : `Click Generate ${studioMode === 'clone' ? 'Cloned ' : ''}Preview to audition in ${language}.`}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Prominent Download to Phone Card — only shown after voice generation/cloning succeeds */}
              {previewAudioBase64 && !previewDirty && (
                <GeneratedAudioResultCard
                  audioBase64={previewAudioBase64}
                  voiceName={voiceName.trim() || baseVoice}
                  language={language}
                  accent={teluguAccent}
                  styleLabel={styleCategory}
                  isGamingMode={styleCategory === 'Gaming Commentary'}
                  isCloned={studioMode === 'clone'}
                  speed={speed}
                  pitchSemitones={pitchSemitones}
                  durationSec={playback.duration}
                  currentTimeSec={playback.currentTime}
                  isPlaying={playback.isPlaying}
                  isPaused={playback.isPaused}
                  onPlayPause={handlePlayPause}
                  onReplay={handleReplay}
                  compact
                />
              )}
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-300 text-xs sm:text-sm">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 sm:px-7 py-4 border-t border-zinc-100 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-950/60 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200/60 dark:hover:bg-zinc-800 transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={
              isSaving ||
              isGeneratingAudio ||
              !voiceName.trim() ||
              (studioMode === 'clone' && !consentConfirmed)
            }
            className="min-h-[44px] flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold shadow-sm transition-colors whitespace-nowrap"
          >
            {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
            <span>
              {isSaving
                ? 'Saving Voice...'
                : studioMode === 'clone'
                ? 'Save Cloned Voice'
                : 'Save to Library'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default VoiceCreatorModal;
