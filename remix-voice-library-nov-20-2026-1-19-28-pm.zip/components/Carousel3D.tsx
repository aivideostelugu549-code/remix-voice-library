/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Voice } from '../types';
import {
  Play,
  Pause,
  Activity,
  ChevronLeft,
  ChevronRight,
  Trash2,
  GitCompare,
  Check,
  Heart,
  Sliders,
} from 'lucide-react';
import AudioVisualizer from './AudioVisualizer';
import {
  playVoiceSample,
  stopVoiceSample,
  unlockAudioContext,
  getVoiceAnalyser,
} from '../utils/webAudioVoicePreview';

interface Carousel3DProps {
  voices: Voice[];
  activeIndex: number;
  onChange: (index: number) => void;
  playingVoice: string | null;
  favoriteNames: string[];
  onPlayToggle: (voiceName: string) => void;
  onToggleFavorite: (voiceName: string) => void;
  onOpenInStudio: (voiceName: string) => void;
  onDeleteCustomVoice?: (voiceName: string) => void;
  compareSelection?: string[];
  onToggleCompare?: (voiceName: string) => void;
  disabled?: boolean;
}

const SLOT_LABELS = ['A', 'B', 'C', 'D'];

const Carousel3D: React.FC<Carousel3DProps> = ({
  voices,
  activeIndex,
  onChange,
  playingVoice,
  favoriteNames,
  onPlayToggle,
  onToggleFavorite,
  onOpenInStudio,
  onDeleteCustomVoice,
  compareSelection = [],
  onToggleCompare,
  disabled = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const onPlayToggleRef = useRef(onPlayToggle);
  onPlayToggleRef.current = onPlayToggle;
  const [windowWidth, setWindowWidth] = useState(
    typeof window !== 'undefined' ? window.innerWidth : 1200
  );

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (playingVoice) {
      const voice = voices.find((v) => v.name === playingVoice);
      if (voice) {
        playVoiceSample(voice, () => {
          onPlayToggleRef.current(voice.name);
        });
      }
    } else {
      stopVoiceSample();
    }
  }, [playingVoice, voices]);

  useEffect(() => {
    return () => {
      stopVoiceSample();
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (disabled) return;
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA' ||
        document.activeElement?.tagName === 'SELECT'
      ) {
        return;
      }

      if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if ((e.key === 'Enter' || e.key === ' ') && voices[activeIndex]) {
        onPlayToggle(voices[activeIndex].name);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, voices, disabled]);

  const handleDragEnd = (_event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (disabled) return;
    const threshold = 50;
    if (info.offset.x > threshold && activeIndex > 0) {
      onChange(activeIndex - 1);
    } else if (info.offset.x < -threshold && activeIndex < voices.length - 1) {
      onChange(activeIndex + 1);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) onChange(activeIndex - 1);
  };

  const handleNext = () => {
    if (activeIndex < voices.length - 1) onChange(activeIndex + 1);
  };

  const visibleRange = 3;

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Navigation Arrows */}
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-3 sm:px-10 z-50 pointer-events-none">
        <button
          onClick={handlePrev}
          disabled={activeIndex === 0 || disabled}
          className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md shadow-lg border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 transition-all pointer-events-auto ${
            activeIndex === 0 ? 'opacity-0 cursor-default' : 'opacity-100 hover:border-indigo-500'
          }`}
          aria-label="Previous voice"
        >
          <ChevronLeft size={22} />
        </button>
        <button
          onClick={handleNext}
          disabled={activeIndex === voices.length - 1 || disabled}
          className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md shadow-lg border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 transition-all pointer-events-auto ${
            activeIndex === voices.length - 1
              ? 'opacity-0 cursor-default'
              : 'opacity-100 hover:border-indigo-500'
          }`}
          aria-label="Next voice"
        >
          <ChevronRight size={22} />
        </button>
      </div>

      <div
        ref={containerRef}
        className="relative w-full h-[66vh] sm:h-[68vh] flex items-center justify-center"
        style={{ perspective: '1200px' }}
      >
        <div className="relative w-full h-full flex items-center justify-center transform-style-3d">
          <AnimatePresence initial={false}>
            {voices.map((voice, index) => {
              if (Math.abs(index - activeIndex) > visibleRange) return null;

              const isActive = index === activeIndex;
              const offset = index - activeIndex;
              const isPlaying = playingVoice === voice.name;
              const isFav = favoriteNames.includes(voice.name);
              const slotIdx = compareSelection.indexOf(voice.name);
              const slotLabel = slotIdx >= 0 ? SLOT_LABELS[slotIdx] || String(slotIdx + 1) : null;

              const zIndex = 100 - Math.abs(offset);
              const isMobile = windowWidth < 640;

              let x = 0;
              if (isMobile) {
                x = offset * (windowWidth * 0.78);
              } else {
                const baseGap = 280;
                const stackStep = 45;
                if (offset !== 0) {
                  x = Math.sign(offset) * (baseGap + (Math.abs(offset) - 1) * stackStep);
                }
              }

              return (
                <motion.div
                  key={voice.name}
                  className={`absolute w-[290px] sm:w-[356px] h-[410px] sm:h-[445px] bg-white dark:bg-zinc-900 rounded-3xl border overflow-hidden cursor-pointer ${
                    isActive
                      ? 'border-zinc-300 dark:border-zinc-700 shadow-2xl'
                      : 'border-zinc-200 dark:border-zinc-800 shadow-lg'
                  }`}
                  style={{ zIndex }}
                  initial={{ scale: 0.8, opacity: 0, x: offset * 200 }}
                  animate={{
                    scale: isActive ? 1 : 0.85,
                    opacity: 1,
                    x,
                    z: isActive ? 0 : -100 - Math.abs(offset) * 30,
                    rotateY: offset * -14,
                    filter: isActive ? 'blur(0px)' : 'blur(0.5px)',
                  }}
                  exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2 } }}
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  onClick={() => {
                    if (disabled) return;
                    if (isActive) {
                      unlockAudioContext();
                      onPlayToggle(voice.name);
                    } else {
                      onChange(index);
                    }
                  }}
                  drag={isActive && !disabled ? 'x' : false}
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.2}
                  onDragEnd={handleDragEnd}
                  role="button"
                  tabIndex={isActive && !disabled ? 0 : -1}
                  aria-label={`Voice card for ${voice.name}`}
                >
                  <motion.div
                    animate={{ opacity: isActive ? 0 : 0.55 }}
                    className="absolute inset-0 bg-white dark:bg-zinc-950 z-40 pointer-events-none"
                  />

                  <div className="h-full flex flex-col relative">
                    {/* Top Waveform Area */}
                    <div className="flex-1 relative bg-zinc-50 dark:bg-zinc-950 flex items-center justify-center overflow-hidden border-b border-zinc-100 dark:border-zinc-800">
                      <div
                        className={`absolute inset-0 z-10 transition-opacity duration-300 ${
                          isPlaying ? 'opacity-100' : 'opacity-0'
                        }`}
                      >
                        <AudioVisualizer
                          isPlaying={isPlaying}
                          color="#6366f1"
                          analyser={isPlaying ? getVoiceAnalyser() : null}
                        />
                      </div>

                      <div
                        className={`relative z-20 flex flex-col items-center gap-3 transition-opacity duration-200 ${
                          isPlaying ? 'opacity-0 group-hover:opacity-100' : 'opacity-100'
                        }`}
                      >
                        <div className="w-16 h-16 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 flex items-center justify-center shadow-sm">
                          {isPlaying ? (
                            <Pause size={24} className="text-indigo-500 fill-current" />
                          ) : (
                            <Play size={24} className="text-zinc-700 dark:text-zinc-200 fill-current ml-0.5" />
                          )}
                        </div>
                        {!isPlaying && (
                          <span className="text-[11px] font-medium text-zinc-400 flex items-center gap-1">
                            <Activity size={12} /> Tap to preview
                          </span>
                        )}
                      </div>

                      {/* Top Left: Custom/Language Badge + Delete */}
                      <div className="absolute top-4 left-4 z-30 flex items-center gap-1.5">
                        {voice.isCustom && (
                          <span className="px-2 py-0.5 rounded-lg bg-indigo-600 text-white text-[10px] font-bold tracking-wider uppercase">
                            {voice.isCloned ? 'Cloned' : 'Custom'}
                          </span>
                        )}
                        {voice.isCustom && onDeleteCustomVoice && isActive && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteCustomVoice(voice.name);
                            }}
                            className="p-1.5 rounded-lg bg-white/90 dark:bg-zinc-900/90 text-zinc-500 hover:text-red-500 border border-zinc-200 dark:border-zinc-700"
                            title={`Delete ${voice.name}`}
                            aria-label={`Delete ${voice.name}`}
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>

                      {/* Top Right: Favorite + Compare */}
                      {isActive && (
                        <div className="absolute top-4 right-4 z-30 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleFavorite(voice.name);
                            }}
                            className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl border transition-colors ${
                              isFav
                                ? 'bg-rose-500/20 border-rose-500/50 text-rose-500'
                                : 'bg-white/90 dark:bg-zinc-900/90 border-zinc-200 dark:border-zinc-700 text-zinc-400 hover:text-rose-400'
                            }`}
                            title={isFav ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
                            aria-label={isFav ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
                          >
                            <Heart size={15} className={isFav ? 'fill-current' : ''} />
                          </button>

                          {onToggleCompare && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleCompare(voice.name);
                              }}
                              className={`min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold border transition-colors ${
                                slotLabel
                                  ? 'bg-indigo-600 text-white border-indigo-500'
                                  : 'bg-white/90 dark:bg-zinc-900/90 text-zinc-700 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700 hover:border-indigo-500'
                              }`}
                            >
                              {slotLabel ? <Check size={12} /> : <GitCompare size={12} />}
                              <span>{slotLabel ? slotLabel : 'Compare'}</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Bottom Card Info */}
                    <div className="p-5 sm:p-6 flex flex-col justify-between gap-3 bg-white dark:bg-zinc-900 relative z-30">
                      <div>
                        <h2 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight truncate">
                          {voice.name}
                        </h2>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                          {voice.analysis.gender} · {voice.pitch} Pitch
                          {voice.language ? ` · ${voice.language === 'Telugu' ? 'తెలుగు' : voice.language}` : ''}
                        </p>
                      </div>

                      <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed line-clamp-2">
                        {voice.stylePrompt || voice.analysis.characteristics.join(' · ')}
                      </p>

                      {isActive && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenInStudio(voice.name);
                          }}
                          className="w-full min-h-[42px] rounded-xl bg-zinc-900 dark:bg-indigo-600 hover:bg-indigo-600 dark:hover:bg-indigo-500 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                        >
                          <Sliders size={14} />
                          <span>Open in Audio Studio</span>
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Carousel3D;