/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Square,
  GitCompare,
  Sparkles,
  Loader2,
  Volume2,
  Check,
  AlertCircle,
  Plus,
  Trash2,
} from 'lucide-react';
import { Voice, LanguageMode, TeluguAccent } from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  playVoiceSample,
  stopVoiceSample,
  unlockAudioContext,
  getVoiceAnalyser,
  getVoiceTechnicalProfile,
} from '../utils/webAudioVoicePreview';
import {
  StudioAudioController,
  StudioPlaybackState,
  checkClientEthicalVoicePolicy,
} from '../utils/audioStudioPlayer';

interface CompareVoicesModalProps {
  allVoices: Voice[];
  initialVoiceNames: string[];
  initialScript?: string;
  initialLanguage?: LanguageMode;
  initialAccent?: TeluguAccent;
  onUpdateSelection: (voiceNames: string[]) => void;
  onClose: () => void;
}

const SLOT_COLORS = [
  { label: 'A', badge: 'bg-indigo-600 text-white', bar: 'bg-indigo-500', viz: '#6366f1' },
  { label: 'B', badge: 'bg-teal-600 text-white', bar: 'bg-teal-500', viz: '#14b8a6' },
  { label: 'C', badge: 'bg-amber-600 text-white', bar: 'bg-amber-500', viz: '#f59e0b' },
  { label: 'D', badge: 'bg-rose-600 text-white', bar: 'bg-rose-500', viz: '#f43f5e' },
];

const DEFAULT_COMPARE_SCRIPTS: Record<LanguageMode, string> = {
  English:
    'Welcome to the studio. Listen closely to the tone, pacing, and clarity of this voice.',
  Telugu:
    'నమస్కారం! స్టూడియోకి స్వాగతం. ఈ స్వరం యొక్క స్పష్టత మరియు శైలిని వినండి.',
  Tanglish:
    'హలో గైస్! ఈ వాయిస్ లో తెలుగు మరియు English మిక్స్ ఎలా సౌండ్ అవుతుందో చెక్ చేద్దాం.',
};

const CompareVoicesModal: React.FC<CompareVoicesModalProps> = ({
  allVoices,
  initialVoiceNames,
  initialScript,
  initialLanguage,
  initialAccent,
  onUpdateSelection,
  onClose,
}) => {
  const [slotNames, setSlotNames] = useState<string[]>(() => {
    const valid = initialVoiceNames.filter((n) => allVoices.some((v) => v.name === n));
    if (valid.length >= 2) return valid.slice(0, 4);
    const fallback = allVoices.slice(0, 2).map((v) => v.name);
    return valid.length === 1
      ? [valid[0], allVoices.find((v) => v.name !== valid[0])?.name || fallback[1] || valid[0]]
      : fallback;
  });

  const [activeSampleSlot, setActiveSampleSlot] = useState<number | null>(null);
  const [isSequencePlaying, setIsSequencePlaying] = useState(false);

  const [ttsLanguage, setTtsLanguage] = useState<LanguageMode>(() => {
    if (initialLanguage) return initialLanguage;
    const first = allVoices.find((v) => v.name === initialVoiceNames[0]);
    if (first?.language === 'Telugu' || first?.language === 'Tanglish') return first.language;
    return 'English';
  });
  const [ttsAccent, setTtsAccent] = useState<TeluguAccent>(initialAccent || 'Standard');
  const [ttsScript, setTtsScript] = useState<string>(() => {
    if (initialScript && initialScript.trim()) return initialScript;
    return DEFAULT_COMPARE_SCRIPTS[initialLanguage || 'English'];
  });
  const [speed, setSpeed] = useState(1.0);
  const [pitchSemitones, setPitchSemitones] = useState(0);

  const [ttsLoadingSlot, setTtsLoadingSlot] = useState<number | null>(null);
  const [ttsPlayingSlot, setTtsPlayingSlot] = useState<number | null>(null);
  const [ttsPlayback, setTtsPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });
  const [ttsCache, setTtsCache] = useState<Record<string, string>>({});
  const [ttsError, setTtsError] = useState<string | null>(null);

  const modalRef = useRef<HTMLDivElement>(null);
  const controllerRef = useRef<StudioAudioController | null>(null);
  const sequenceRef = useRef(false);
  const isMountedRef = useRef(true);

  const slotVoices = useMemo(
    () => slotNames.map((name) => allVoices.find((v) => v.name === name) || allVoices[0]).filter(Boolean),
    [slotNames, allVoices]
  );

  const stopAllAudio = () => {
    sequenceRef.current = false;
    setIsSequencePlaying(false);
    stopVoiceSample();
    setActiveSampleSlot(null);
    controllerRef.current?.stop();
    setTtsPlayingSlot(null);
  };

  useEffect(() => {
    isMountedRef.current = true;
    controllerRef.current = new StudioAudioController((next) => {
      if (!isMountedRef.current) return;
      setTtsPlayback(next);
      if (!next.isPlaying && !next.isPaused) {
        setTtsPlayingSlot(null);
      }
    });
    modalRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      isMountedRef.current = false;
      window.removeEventListener('keydown', handleKeyDown);
      stopAllAudio();
      controllerRef.current?.dispose();
      controllerRef.current = null;
    };
  }, [onClose]);

  useEffect(() => {
    controllerRef.current?.setSpeed(speed);
  }, [speed]);

  useEffect(() => {
    controllerRef.current?.setPitch(pitchSemitones);
  }, [pitchSemitones]);

  const handlePlaySampleSlot = (idx: number) => {
    unlockAudioContext();
    setTtsError(null);
    controllerRef.current?.stop();
    setTtsPlayingSlot(null);

    if (activeSampleSlot === idx && !isSequencePlaying) {
      stopAllAudio();
      return;
    }

    sequenceRef.current = false;
    setIsSequencePlaying(false);
    setActiveSampleSlot(idx);

    const target = slotVoices[idx];
    if (!target) return;
    playVoiceSample(target, () => {
      if (isMountedRef.current) setActiveSampleSlot(null);
    });
  };

  const handlePlaySequence = () => {
    unlockAudioContext();
    setTtsError(null);
    controllerRef.current?.stop();
    setTtsPlayingSlot(null);

    if (isSequencePlaying) {
      stopAllAudio();
      return;
    }

    sequenceRef.current = true;
    setIsSequencePlaying(true);

    const playStep = (stepIdx: number) => {
      if (!isMountedRef.current || !sequenceRef.current || stepIdx >= slotVoices.length) {
        if (isMountedRef.current) {
          sequenceRef.current = false;
          setIsSequencePlaying(false);
          setActiveSampleSlot(null);
        }
        return;
      }
      setActiveSampleSlot(stepIdx);
      playVoiceSample(slotVoices[stepIdx], () => playStep(stepIdx + 1));
    };

    playStep(0);
  };

  const getCacheKey = (voiceName: string) =>
    `${voiceName}::${ttsLanguage}::${ttsAccent}::${ttsScript.trim()}`;

  const handleSpeakScriptSlot = async (idx: number) => {
    const targetVoice = slotVoices[idx];
    if (!targetVoice || ttsLoadingSlot !== null || !ttsScript.trim()) return;

    const controller = controllerRef.current;
    if (!controller) return;

    if (ttsPlayingSlot === idx) {
      if (ttsPlayback.isPlaying) {
        controller.pause();
      } else if (ttsPlayback.isPaused) {
        await controller.play(false);
      }
      return;
    }

    const policyErr = checkClientEthicalVoicePolicy(ttsScript);
    if (policyErr) {
      setTtsError(policyErr);
      return;
    }

    stopAllAudio();
    setTtsError(null);

    const key = getCacheKey(targetVoice.name);
    if (ttsCache[key]) {
      await controller.loadBase64(ttsCache[key]);
      controller.setSpeed(speed);
      controller.setPitch(pitchSemitones);
      setTtsPlayingSlot(idx);
      await controller.play(true);
      return;
    }

    setTtsLoadingSlot(idx);
    try {
      const baseVoice = targetVoice.baseVoice || targetVoice.name;
      const stylePrompt =
        targetVoice.stylePrompt ||
        `${targetVoice.analysis.gender} voice, ${targetVoice.analysis.pitch} pitch, ${targetVoice.analysis.characteristics.join(', ')}`;

      const res = await fetch('/api/voice-studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: ttsScript.trim(),
          baseVoice,
          stylePrompt: stylePrompt.slice(0, 500),
          language: ttsLanguage,
          accent: ttsLanguage === 'English' ? 'Standard' : ttsAccent,
          speed,
          pitchSemitones,
        }),
      });

      const data = await res.json();
      if (!isMountedRef.current) return;
      if (!res.ok || !data.audioBase64) {
        throw new Error(data.error || 'Failed to synthesize comparison speech.');
      }

      setTtsCache((prev) => ({ ...prev, [key]: data.audioBase64 }));
      await controller.loadBase64(data.audioBase64);
      controller.setSpeed(speed);
      controller.setPitch(pitchSemitones);
      setTtsPlayingSlot(idx);
      await controller.play(true);
    } catch (err: any) {
      if (isMountedRef.current) {
        setTtsError(err?.message || 'Failed to synthesize TTS preview.');
      }
    } finally {
      if (isMountedRef.current) setTtsLoadingSlot(null);
    }
  };

  const handleReplaySlot = async (idx: number) => {
    const targetVoice = slotVoices[idx];
    const controller = controllerRef.current;
    if (!targetVoice || !controller) return;
    const cached = ttsCache[getCacheKey(targetVoice.name)];
    if (!cached) return;
    stopAllAudio();
    await controller.loadBase64(cached);
    controller.setSpeed(speed);
    controller.setPitch(pitchSemitones);
    setTtsPlayingSlot(idx);
    await controller.play(true);
  };

  const handleChangeSlot = (idx: number, nextName: string) => {
    stopAllAudio();
    const updated = [...slotNames];
    updated[idx] = nextName;
    setSlotNames(updated);
    onUpdateSelection(updated);
  };

  const handleAddSlot = () => {
    if (slotNames.length >= 4) return;
    const nextVoice = allVoices.find((v) => !slotNames.includes(v.name)) || allVoices[0];
    if (!nextVoice) return;
    const updated = [...slotNames, nextVoice.name];
    setSlotNames(updated);
    onUpdateSelection(updated);
  };

  const handleRemoveSlot = (idx: number) => {
    if (slotNames.length <= 2) return;
    stopAllAudio();
    const updated = slotNames.filter((_, i) => i !== idx);
    setSlotNames(updated);
    onUpdateSelection(updated);
  };

  const sharedTraits = useMemo(() => {
    if (slotVoices.length < 2) return [];
    const firstTraits = slotVoices[0].analysis.characteristics;
    return firstTraits.filter((trait) =>
      slotVoices.slice(1).every((v) =>
        v.analysis.characteristics.some((c) => c.toLowerCase() === trait.toLowerCase())
      )
    );
  }, [slotVoices]);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="compare-voices-title"
    >
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      <div
        ref={modalRef}
        tabIndex={-1}
        className="relative w-full max-w-7xl max-h-[94vh] bg-white dark:bg-zinc-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-slide-up border border-zinc-200 dark:border-zinc-800 flex flex-col outline-none"
      >
        {/* Header */}
        <div className="px-5 sm:px-7 py-4 border-b border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 mb-0.5">
              <GitCompare size={16} />
              <span className="text-xs font-bold tracking-wider uppercase">
                Multi-Voice Comparison ({slotVoices.length} Voices)
              </span>
            </div>
            <h2
              id="compare-voices-title"
              className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-white"
            >
              {slotVoices.map((v) => v.name).join(' vs ')}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {slotNames.length < 4 && (
              <button
                type="button"
                onClick={handleAddSlot}
                className="min-h-[40px] flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-semibold transition-colors whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Add Voice ({slotNames.length}/4)</span>
              </button>
            )}

            <button
              type="button"
              onClick={handlePlaySequence}
              className={`min-h-[40px] flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                isSequencePlaying
                  ? 'bg-zinc-200 dark:bg-zinc-700 text-zinc-900 dark:text-white'
                  : 'bg-indigo-600 text-white hover:bg-indigo-500'
              }`}
            >
              {isSequencePlaying ? <Square size={13} className="fill-current" /> : <Play size={13} className="fill-current" />}
              <span>
                {isSequencePlaying && activeSampleSlot !== null
                  ? `Playing ${SLOT_COLORS[activeSampleSlot]?.label}...`
                  : 'Audition Sequence'}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
              aria-label="Close comparison"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-7 space-y-5">
          {/* Shared Script Controls */}
          <div className="bg-zinc-50 dark:bg-zinc-950/60 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <label
                htmlFor="compare-tts-script"
                className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5"
              >
                <Sparkles size={14} className="text-indigo-500" />
                Compare All Voices Using the Same Script
              </label>

              <div className="flex flex-wrap items-center gap-2">
                <div className="inline-flex bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-0.5">
                  {(['English', 'Telugu', 'Tanglish'] as LanguageMode[]).map((lang) => (
                    <button
                      key={lang}
                      type="button"
                      onClick={() => {
                        setTtsLanguage(lang);
                        if (Object.values(DEFAULT_COMPARE_SCRIPTS).includes(ttsScript.trim())) {
                          setTtsScript(DEFAULT_COMPARE_SCRIPTS[lang]);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                        ttsLanguage === lang
                          ? 'bg-indigo-600 text-white'
                          : 'text-zinc-500 dark:text-zinc-400'
                      }`}
                    >
                      {lang === 'Telugu' ? 'తెలుగు' : lang}
                    </button>
                  ))}
                </div>

                {ttsLanguage !== 'English' && (
                  <select
                    value={ttsAccent}
                    onChange={(e) => setTtsAccent(e.target.value as TeluguAccent)}
                    className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-2.5 py-1 text-[11px] font-semibold text-zinc-700 dark:text-zinc-300"
                    aria-label="Telugu Accent"
                  >
                    <option value="Standard">Standard Accent</option>
                    <option value="Andhra">Andhra Accent</option>
                    <option value="Telangana">Telangana Accent</option>
                  </select>
                )}
              </div>
            </div>

            <input
              id="compare-tts-script"
              type="text"
              value={ttsScript}
              onChange={(e) => setTtsScript(e.target.value)}
              placeholder="Enter any English, Telugu, or Tanglish phrase to compare across all selected voices..."
              className="w-full min-h-[44px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
            />

            <div className="flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex flex-wrap items-center gap-4">
                <label className="flex items-center gap-2 text-zinc-600 dark:text-zinc-300">
                  <span>Speed:</span>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-24 accent-indigo-500"
                  />
                  <span className="font-mono tabular-nums text-indigo-500 font-semibold">
                    {speed.toFixed(2)}x
                  </span>
                </label>

                <label className="flex items-center gap-2 text-zinc-600 dark:text-zinc-300">
                  <span>Pitch:</span>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={1}
                    value={pitchSemitones}
                    onChange={(e) => setPitchSemitones(parseInt(e.target.value, 10))}
                    className="w-24 accent-indigo-500"
                  />
                  <span className="font-mono tabular-nums text-indigo-500 font-semibold">
                    {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} st
                  </span>
                </label>
              </div>

              <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
                <Check size={14} />
                <span>
                  {sharedTraits.length > 0
                    ? `Shared traits: ${sharedTraits.join(', ')}`
                    : 'Distinct vocal profiles'}
                </span>
              </div>
            </div>

            {ttsError && (
              <div className="flex items-center gap-2 text-xs text-red-600 dark:text-red-400">
                <AlertCircle size={14} className="shrink-0" />
                <span>{ttsError}</span>
              </div>
            )}
          </div>

          {/* Multi-Column Voice Cards */}
          <div
            className={`grid grid-cols-1 ${
              slotVoices.length === 2
                ? 'lg:grid-cols-2'
                : slotVoices.length === 3
                ? 'lg:grid-cols-3'
                : 'md:grid-cols-2 xl:grid-cols-4'
            } gap-4`}
          >
            {slotVoices.map((voice, idx) => {
              const color = SLOT_COLORS[idx] || SLOT_COLORS[0];
              const profile = getVoiceTechnicalProfile(voice);
              const isSampleActive = activeSampleSlot === idx;
              const isTtsActive = ttsPlayingSlot === idx;
              const isTtsPlayingNow = isTtsActive && ttsPlayback.isPlaying;
              const isTtsPausedNow = isTtsActive && ttsPlayback.isPaused;
              const isSlotLoading = ttsLoadingSlot === idx;
              const cachedAudio = ttsCache[getCacheKey(voice.name)] || null;
              const hasCachedAudio = Boolean(cachedAudio);

              return (
                <div
                  key={`${color.label}-${idx}`}
                  className={`bg-zinc-50 dark:bg-zinc-950/60 rounded-2xl border p-4 flex flex-col gap-3.5 transition-all ${
                    isSampleActive || isTtsPlayingNow
                      ? 'border-indigo-500 ring-1 ring-indigo-500/40'
                      : 'border-zinc-200 dark:border-zinc-800'
                  }`}
                >
                  {/* Slot Header */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold uppercase shrink-0 ${color.badge}`}
                      >
                        {color.label}
                      </span>
                      <select
                        value={voice.name}
                        onChange={(e) => handleChangeSlot(idx, e.target.value)}
                        aria-label={`Select Voice ${color.label}`}
                        className="flex-1 min-w-0 min-h-[38px] bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl px-2.5 text-xs sm:text-sm font-semibold text-zinc-900 dark:text-white truncate"
                      >
                        {allVoices.map((v) => (
                          <option key={v.name} value={v.name}>
                            {v.name} ({v.analysis.gender}, {v.pitch})
                          </option>
                        ))}
                      </select>
                    </div>

                    {slotVoices.length > 2 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveSlot(idx)}
                        className="p-2 rounded-lg text-zinc-400 hover:text-red-500 transition-colors shrink-0"
                        title={`Remove Voice ${color.label}`}
                        aria-label={`Remove Voice ${color.label}`}
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>

                  {/* Waveform & Playback */}
                  <div className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
                    <div className="h-20 relative flex items-center justify-center px-3">
                      {isSampleActive || isTtsPlayingNow ? (
                        <div className="w-full h-full">
                          <AudioVisualizer
                            isPlaying={true}
                            color={color.viz}
                            analyser={
                              isSampleActive
                                ? getVoiceAnalyser()
                                : controllerRef.current?.getAnalyser() || null
                            }
                          />
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-1 text-zinc-400 dark:text-zinc-500">
                          <Volume2 size={18} />
                          <span className="text-[11px]">
                            {hasCachedAudio ? 'Script audio ready' : 'Ready to audition'}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="px-3 py-2 bg-zinc-50 dark:bg-zinc-950/80 border-t border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => handlePlaySampleSlot(idx)}
                        className="min-h-[36px] flex items-center gap-1.5 px-3 py-1 rounded-lg bg-zinc-900 dark:bg-zinc-800 hover:bg-zinc-800 dark:hover:bg-zinc-700 text-white text-xs font-medium"
                      >
                        {isSampleActive ? <Square size={11} className="fill-current" /> : <Play size={11} className="fill-current" />}
                        <span>{isSampleActive ? 'Stop' : 'Timbre'}</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleSpeakScriptSlot(idx)}
                          disabled={ttsLoadingSlot !== null || !ttsScript.trim()}
                          className="min-h-[36px] flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold"
                        >
                          {isSlotLoading ? (
                            <Loader2 size={12} className="animate-spin" />
                          ) : isTtsPlayingNow ? (
                            <Pause size={12} className="fill-current" />
                          ) : (
                            <Sparkles size={12} />
                          )}
                          <span>
                            {isSlotLoading
                              ? 'Generating...'
                              : isTtsPlayingNow
                              ? 'Pause'
                              : isTtsPausedNow
                              ? 'Resume'
                              : 'Speak Script'}
                          </span>
                        </button>

                        {isTtsActive && (
                          <button
                            type="button"
                            onClick={() => handleReplaySlot(idx)}
                            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
                            title="Replay"
                          >
                            <RotateCcw size={12} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Generated Voice Result & Download to Phone Card (only rendered after generation succeeds) */}
                  {cachedAudio && (
                    <GeneratedAudioResultCard
                      audioBase64={cachedAudio}
                      voiceName={voice.name}
                      language={ttsLanguage}
                      accent={ttsLanguage === 'English' ? 'Standard' : ttsAccent}
                      styleLabel={voice.styleCategory || voice.analysis.characteristics[0]}
                      isGamingMode={
                        Boolean(voice.isGamingMode) ||
                        Boolean(voice.styleCategory?.toLowerCase().includes('gaming')) ||
                        voice.analysis.characteristics.some((c) => c.toLowerCase().includes('gaming'))
                      }
                      isCloned={Boolean(voice.isCloned)}
                      speed={speed}
                      pitchSemitones={pitchSemitones}
                      durationSec={isTtsActive ? ttsPlayback.duration : 0}
                      currentTimeSec={isTtsActive ? ttsPlayback.currentTime : 0}
                      isPlaying={isTtsPlayingNow}
                      isPaused={isTtsPausedNow}
                      onPlayPause={() => handleSpeakScriptSlot(idx)}
                      onReplay={() => handleReplaySlot(idx)}
                      compact={true}
                    />
                  )}

                  {/* Acoustic Bars */}
                  <div className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-3.5 space-y-2.5">
                    {[
                      { label: 'Brightness', value: profile.brightnessScore },
                      { label: 'Warmth', value: profile.warmthScore },
                      { label: 'Energy', value: profile.energyScore },
                    ].map((metric) => (
                      <div key={metric.label} className="space-y-1">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-zinc-500 dark:text-zinc-400">{metric.label}</span>
                          <span className="font-mono tabular-nums text-zinc-900 dark:text-zinc-200">
                            {metric.value}/100
                          </span>
                        </div>
                        <div className="h-1.5 w-full rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${color.bar}`}
                            style={{ width: `${metric.value}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Clean Technical Specs (unboxed metadata) */}
                  <div className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-3.5 text-xs space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Profile</span>
                      <span className="font-medium text-zinc-900 dark:text-zinc-100">
                        {voice.analysis.gender} · {voice.analysis.pitch}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Fundamental</span>
                      <span className="font-mono tabular-nums text-zinc-900 dark:text-zinc-100">
                        ~{profile.fundamentalHz} Hz
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Formants</span>
                      <span className="font-mono tabular-nums text-zinc-900 dark:text-zinc-100">
                        {profile.formant1Hz} / {profile.formant2Hz} Hz
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Language</span>
                      <span className="font-medium text-zinc-900 dark:text-zinc-100">
                        {voice.language || 'EN / TE / Tanglish'}
                      </span>
                    </div>
                    <div className="pt-1.5 border-t border-zinc-100 dark:border-zinc-800 text-[11px] text-zinc-500 dark:text-zinc-400">
                      {voice.analysis.characteristics.join(' · ')}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompareVoicesModal;
