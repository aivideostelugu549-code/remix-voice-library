/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Smartphone,
  FolderOpen,
  Share2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FileAudio,
} from 'lucide-react';
import {
  AudioExportFormat,
  Mp3QualityKbps,
  WavSampleRateHz,
  buildMeaningfulAudioFilename,
  sanitizeUserFilename,
  encodeAudioForExport,
  saveBlobToPhoneOrDevice,
  shareAudioBlobViaSystemSheet,
  isSystemFilePickerSupported,
  canShareAudioFiles,
  formatBytes,
  formatStudioTime,
} from '../utils/audioStudioPlayer';

interface GeneratedAudioResultCardProps {
  audioBase64: string;
  voiceName: string;
  language?: string;
  accent?: string;
  styleLabel?: string;
  isGamingMode?: boolean;
  isCloned?: boolean;
  speed?: number;
  pitchSemitones?: number;
  durationSec?: number;
  currentTimeSec?: number;
  isPlaying: boolean;
  isPaused?: boolean;
  onPlayPause: () => void;
  onReplay?: () => void;
  compact?: boolean;
}

const GeneratedAudioResultCard: React.FC<GeneratedAudioResultCardProps> = ({
  audioBase64,
  voiceName,
  language,
  accent,
  styleLabel,
  isGamingMode = false,
  isCloned = false,
  speed = 1.0,
  pitchSemitones = 0,
  durationSec = 0,
  currentTimeSec = 0,
  isPlaying,
  isPaused = false,
  onPlayPause,
  onReplay,
  compact = false,
}) => {
  const [format, setFormat] = useState<AudioExportFormat>('mp3');
  const [mp3Kbps, setMp3Kbps] = useState<Mp3QualityKbps>(192);
  const [wavRate, setWavRate] = useState<WavSampleRateHz>(44100);

  const defaultFilename = useMemo(
    () =>
      buildMeaningfulAudioFilename({
        voiceName,
        language,
        accent,
        style: styleLabel,
        isGamingMode,
        isCloned,
        format,
      }),
    [voiceName, language, accent, styleLabel, isGamingMode, isCloned, format]
  );

  const [customStem, setCustomStem] = useState<string>(() =>
    defaultFilename.replace(/\.(mp3|wav)$/i, '')
  );
  const [userEditedName, setUserEditedName] = useState(false);

  useEffect(() => {
    if (!userEditedName) {
      setCustomStem(defaultFilename.replace(/\.(mp3|wav)$/i, ''));
    }
  }, [defaultFilename, userEditedName]);

  const effectiveFilename = useMemo(
    () => sanitizeUserFilename(customStem || defaultFilename, format),
    [customStem, defaultFilename, format]
  );

  const [isExporting, setIsExporting] = useState(false);
  const [progressPct, setProgressPct] = useState(0);
  const [progressStage, setProgressStage] = useState('');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const supportsPicker = useMemo(() => isSystemFilePickerSupported(), []);
  const supportsShare = useMemo(() => canShareAudioFiles(), []);

  const handleDownload = async (useSystemPicker: boolean) => {
    if (isExporting || !audioBase64) return;
    setIsExporting(true);
    setProgressPct(5);
    setProgressStage('Preparing audio...');
    setStatusMessage(null);

    try {
      const blob = await encodeAudioForExport({
        base64Audio: audioBase64,
        format,
        mp3Kbps,
        wavSampleRate: wavRate,
        speed,
        pitchSemitones,
        onProgress: (pct, stage) => {
          setProgressPct(pct);
          setProgressStage(stage);
        },
      });

      setProgressPct(99);
      setProgressStage(useSystemPicker ? 'Opening system file picker...' : 'Saving to device...');

      const result = await saveBlobToPhoneOrDevice(blob, effectiveFilename, useSystemPicker);
      if (result.status === 'cancelled') {
        setStatusMessage({
          type: 'info',
          text: 'Save cancelled before choosing a location.',
        });
      } else {
        setProgressPct(100);
        setStatusMessage({
          type: 'success',
          text: `Downloaded ${result.filename} (${formatBytes(blob.size)})`,
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err?.message || 'Download failed. Please try again.',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleShareToPhone = async () => {
    if (isExporting || !audioBase64) return;
    setIsExporting(true);
    setProgressPct(5);
    setProgressStage('Preparing audio for Android share...');
    setStatusMessage(null);

    try {
      const blob = await encodeAudioForExport({
        base64Audio: audioBase64,
        format,
        mp3Kbps,
        wavSampleRate: wavRate,
        speed,
        pitchSemitones,
        onProgress: (pct, stage) => {
          setProgressPct(pct);
          setProgressStage(stage);
        },
      });

      const outcome = await shareAudioBlobViaSystemSheet(blob, effectiveFilename);
      if (outcome === 'cancelled') {
        setStatusMessage({ type: 'info', text: 'Share cancelled.' });
      } else {
        setProgressPct(100);
        setStatusMessage({
          type: 'success',
          text: `Shared ${effectiveFilename} (${formatBytes(blob.size)})`,
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err?.message || 'Could not share audio file on this device.',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div
      className={`bg-white dark:bg-zinc-900 border border-emerald-500/35 dark:border-emerald-500/30 rounded-2xl ${
        compact ? 'p-3.5 space-y-3' : 'p-4 sm:p-5 space-y-4'
      }`}
    >
      {/* Result Header + Preview Play Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-500 flex items-center justify-center shrink-0">
            <FileAudio size={18} />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white truncate">
              {isCloned ? 'Cloned Voice Audio Ready' : 'Generated Voice Result'}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
              {voiceName}
              {language ? ` · ${language === 'Telugu' ? 'తెలుగు' : language}` : ''}
              {durationSec > 0 ? ` · ${formatStudioTime(currentTimeSec)} / ${formatStudioTime(durationSec)}` : ''}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onPlayPause}
            className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 dark:hover:bg-indigo-600 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            {isPlaying ? <Pause size={14} className="fill-current" /> : <Play size={14} className="fill-current" />}
            <span>{isPlaying ? 'Pause' : isPaused ? 'Resume' : 'Play'}</span>
          </button>

          {onReplay && (
            <button
              type="button"
              onClick={onReplay}
              className="min-h-[42px] min-w-[42px] flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white"
              title="Replay generated voice"
              aria-label="Replay generated voice"
            >
              <RotateCcw size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Format, Quality & Filename Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
        <div className="sm:col-span-3">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1">
            Format
          </label>
          <div className="grid grid-cols-2 gap-1 bg-zinc-100 dark:bg-zinc-950 p-1 rounded-xl border border-zinc-200 dark:border-zinc-800">
            {(['mp3', 'wav'] as AudioExportFormat[]).map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => {
                  setFormat(fmt);
                  setStatusMessage(null);
                }}
                disabled={isExporting}
                className={`min-h-[36px] rounded-lg text-xs font-bold uppercase transition-colors ${
                  format === fmt
                    ? 'bg-indigo-600 text-white'
                    : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>

        <div className="sm:col-span-4">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1">
            Audio Quality
          </label>
          {format === 'mp3' ? (
            <select
              value={mp3Kbps}
              onChange={(e) => setMp3Kbps(Number(e.target.value) as Mp3QualityKbps)}
              disabled={isExporting}
              className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-semibold text-zinc-900 dark:text-white"
              aria-label="MP3 audio quality"
            >
              <option value={128}>128 kbps · Standard MP3</option>
              <option value={192}>192 kbps · High MP3</option>
              <option value={320}>320 kbps · Studio MP3</option>
            </select>
          ) : (
            <select
              value={wavRate}
              onChange={(e) => setWavRate(Number(e.target.value) as WavSampleRateHz)}
              disabled={isExporting}
              className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-semibold text-zinc-900 dark:text-white"
              aria-label="WAV sample rate"
            >
              <option value={24000}>24 kHz · 16-bit Native</option>
              <option value={44100}>44.1 kHz · 16-bit CD</option>
              <option value={48000}>48 kHz · 16-bit Studio</option>
            </select>
          )}
        </div>

        <div className="sm:col-span-5">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1">
            File Name (.{format})
          </label>
          <input
            type="text"
            value={customStem}
            onChange={(e) => {
              setUserEditedName(true);
              setCustomStem(e.target.value);
            }}
            disabled={isExporting}
            placeholder="Telugu_Funny_Gaming_Voice"
            className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-mono text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
          />
        </div>
      </div>

      {/* Prominent Download to Phone CTA Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
        <button
          type="button"
          onClick={() => handleDownload(false)}
          disabled={isExporting}
          className="flex-1 min-h-[48px] px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
        >
          {isExporting ? <Loader2 size={18} className="animate-spin" /> : <Smartphone size={18} />}
          <span>{isExporting ? progressStage || 'Preparing Download...' : `Download to Phone (${format.toUpperCase()})`}</span>
        </button>

        {supportsPicker && (
          <button
            type="button"
            onClick={() => handleDownload(true)}
            disabled={isExporting}
            className="min-h-[48px] px-4 py-3 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 disabled:opacity-50 text-zinc-800 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            title="Choose save folder with system file picker"
          >
            <FolderOpen size={16} />
            <span>Save As</span>
          </button>
        )}

        {supportsShare && (
          <button
            type="button"
            onClick={handleShareToPhone}
            disabled={isExporting}
            className="min-h-[48px] px-4 py-3 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 disabled:opacity-50 text-indigo-600 dark:text-indigo-300 border border-indigo-500/30 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Share2 size={16} />
            <span>Android Share</span>
          </button>
        )}
      </div>

      <p className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 truncate">
        Output file: {effectiveFilename}
      </p>

      {/* Progress Bar */}
      {isExporting && (
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-zinc-600 dark:text-zinc-300 font-medium">{progressStage}</span>
            <span className="font-mono tabular-nums text-emerald-500 font-semibold">
              {progressPct}%
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-150"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      )}

      {/* Success / Error / Info Message */}
      {statusMessage && (
        <div
          className={`flex items-start gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
              : statusMessage.type === 'error'
              ? 'bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-300'
              : 'bg-zinc-100 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
          ) : (
            <AlertCircle size={16} className="shrink-0 mt-0.5" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}
    </div>
  );
};

export default GeneratedAudioResultCard;
