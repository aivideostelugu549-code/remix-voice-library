/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Loader2,
  Heart,
  Gamepad2,
  GitCompare,
  AlertCircle,
  Sliders,
  Languages,
  Wand2,
  AudioLines,
  FileText,
  FolderOpen,
} from 'lucide-react';
import { Voice, LanguageMode, TeluguAccent, ImportedFileRecord } from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  StudioAudioController,
  StudioPlaybackState,
  formatStudioTime,
  checkClientEthicalVoicePolicy,
} from '../utils/audioStudioPlayer';
import { SCRIPT_FILE_ACCEPT } from '../utils/fileVault';

interface AudioStudioViewProps {
  voices: Voice[];
  favoriteNames: string[];
  selectedVoiceName: string;
  onSelectVoice: (voiceName: string) => void;
  onToggleFavorite: (voiceName: string) => void;
  gamingModeDefault?: boolean;
  onOpenCompareWithScript: (script: string, language: LanguageMode, accent: TeluguAccent) => void;
  importedScript?: { id: string; name: string; content: string; version: number } | null;
  vaultScripts?: ImportedFileRecord[];
  onImportScriptFiles?: (
    files: File[],
    requiredKind?: 'audio' | 'script'
  ) => Promise<{ saved: ImportedFileRecord[]; rejected: string[] }>;
  onOpenFileManager?: () => void;
}

interface GamingPreset {
  id: string;
  label: string;
  modeName: string;
  language: LanguageMode;
  accent: TeluguAccent;
  emotion: string;
  energy: number;
  speed: number;
  styleDirection: string;
  script: string;
}

const GAMING_PRESETS: GamingPreset[] = [
  {
    id: 'funny-telugu',
    label: 'Funny Telugu Commentary',
    modeName: 'Funny Telugu Gaming Commentary',
    language: 'Telugu',
    accent: 'Telangana',
    emotion: 'Playful & Funny',
    energy: 86,
    speed: 1.08,
    styleDirection:
      'Young male Telugu gaming commentator, witty conversational Telangana cadence, playful comic timing with natural pauses and genuine laughter.',
    script:
      'అరేయ్ మామా! ఎనిమీ ముందు నిలబడితే గన్ రీలోడ్ చేయడం మర్చిపోయాడు... <laugh> ఛీ ఛీ, ఇంత మంచి క్లచ్ మిస్ అయ్యాడు పాపం!',
  },
  {
    id: 'excited-reactions',
    label: 'Excited Reactions',
    modeName: 'Excited Gaming Reactions',
    language: 'Tanglish',
    accent: 'Andhra',
    emotion: 'Hyped & Excited',
    energy: 95,
    speed: 1.15,
    styleDirection:
      'High-energy young gaming streamer reacting live to an insane squad wipe, bright hyped delivery switching effortlessly between Andhra Telugu and English.',
    script:
      'ఒరేయ్ భయ్యా, వన్ హెచ్‌పీ లో ఉన్నాడు! <gasp> కొట్టు కొట్టు... YES! వాట్ ఏ క్లచ్ రా బాబు, పూర్తిగా OP ఆడేశావ్!',
  },
  {
    id: 'sarcastic-comedy',
    label: 'Sarcastic Comedy',
    modeName: 'Sarcastic Comedy',
    language: 'Tanglish',
    accent: 'Telangana',
    emotion: 'Sarcastic',
    energy: 65,
    speed: 1.0,
    styleDirection:
      'Dry, witty, sarcastic Telugu-English friend roasting a terrible gaming play with amused eyebrow-raised pacing and natural pauses.',
    script:
      'వావ్, ఏం స్ట్రాటజీ రా నీది... ఓపెన్ లో నిలబడి స్నైపర్ కోసం వెయిట్ చేస్తున్నావా? <breath> నిజంగా ప్రో ప్లేయర్ లెవల్ కాన్ఫిడెన్స్!',
  },
  {
    id: 'dramatic-story',
    label: 'Dramatic Storytelling',
    modeName: 'Dramatic Storytelling',
    language: 'Telugu',
    accent: 'Andhra',
    emotion: 'Dramatic & Cinematic',
    energy: 78,
    speed: 0.94,
    styleDirection:
      'Deep, cinematic Telugu narrator telling an intense final-zone battle story with deliberate pauses, rising tension, and crisp Andhra pronunciation.',
    script:
      'చివరి జోన్ దగ్గర పడుతోంది... చుట్టూ నిశ్శబ్దం. <breath> ఒక్క బుల్లెట్ మిగిలింది, కానీ ధైర్యం మాత్రం తగ్గలేదు — ఇప్పుడు అసలైన ఆట మొదలైంది.',
  },
  {
    id: 'tanglish-switch',
    label: 'Tanglish Code-Switching',
    modeName: 'Natural Telugu-English Code Switching',
    language: 'Tanglish',
    accent: 'Standard',
    emotion: 'Casual & Conversational',
    energy: 74,
    speed: 1.04,
    styleDirection:
      'Natural urban Telugu speaker effortlessly blending conversational Telugu with modern English gaming and creator phrases.',
    script:
      'హలో గైస్! ఈ రోజు లైవ్ స్ట్రీమ్ లో ఫుల్ ఫన్ ఉండబోతోంది... <breath> స్క్వాడ్ అంతా రెడీ గా ఉంది, లెట్స్ డ్రాప్ ఇన్ ద లాబీ!',
  },
];

const DEFAULT_SCRIPTS_BY_LANG: Record<LanguageMode, string> = {
  English:
    'Welcome to the AI Voice Studio! <breath> Adjust my speed, pitch, or delivery style and hear the difference immediately.',
  Telugu:
    'నమస్కారం! AI వాయిస్ స్టూడియోకి స్వాగతం. <breath> సహజమైన తెలుగు ఉచ్చారణతో మీ స్క్రిప్ట్‌ను ఇక్కడ పరీక్షించుకోవచ్చు.',
  Tanglish:
    'హలో ఫ్రెండ్స్! ఈ స్టూడియో లో మనం తెలుగు మరియు English మిక్స్ చేసి <breath> సూపర్ నాచురల్ గా మాట్లాడొచ్చు!',
};

const EMOTIONS = [
  'Natural & Conversational',
  'Playful & Funny',
  'Hyped & Excited',
  'Sarcastic',
  'Warm & Friendly',
  'Soft & Calm',
  'Dramatic & Cinematic',
];

const AGE_IMPRESSIONS = [
  'Auto / Voice Default',
  'Young Male Gamer (18-24)',
  'Young Adult (20s)',
  'Mid-30s Creator',
  'Mature / Authoritative',
];

const AudioStudioView: React.FC<AudioStudioViewProps> = ({
  voices,
  favoriteNames,
  selectedVoiceName,
  onSelectVoice,
  onToggleFavorite,
  gamingModeDefault = false,
  onOpenCompareWithScript,
  importedScript,
  vaultScripts = [],
  onImportScriptFiles,
  onOpenFileManager,
}) => {
  const activeVoice = useMemo(
    () => voices.find((v) => v.name === selectedVoiceName) || voices[0],
    [voices, selectedVoiceName]
  );

  const [isGamingMode, setIsGamingMode] = useState(gamingModeDefault);
  const [activePresetId, setActivePresetId] = useState<string>(
    gamingModeDefault ? 'funny-telugu' : ''
  );
  const [language, setLanguage] = useState<LanguageMode>(() => {
    if (gamingModeDefault) return 'Telugu';
    const vLang = activeVoice?.language;
    return vLang === 'Telugu' || vLang === 'Tanglish' ? vLang : 'English';
  });
  const [accent, setAccent] = useState<TeluguAccent>('Telangana');
  const [emotion, setEmotion] = useState<string>(
    gamingModeDefault ? 'Playful & Funny' : 'Natural & Conversational'
  );
  const [ageImpression, setAgeImpression] = useState<string>(
    gamingModeDefault ? 'Young Male Gamer (18-24)' : 'Auto / Voice Default'
  );
  const [speed, setSpeed] = useState<number>(gamingModeDefault ? 1.08 : 1.0);
  const [pitchSemitones, setPitchSemitones] = useState<number>(0);
  const [energy, setEnergy] = useState<number>(gamingModeDefault ? 85 : 65);

  const [styleDirection, setStyleDirection] = useState<string>(() =>
    gamingModeDefault
      ? GAMING_PRESETS[0].styleDirection
      : activeVoice?.stylePrompt || 'Warm, natural conversational delivery with clear sentence pauses.'
  );
  const [scriptText, setScriptText] = useState<string>(() =>
    gamingModeDefault ? GAMING_PRESETS[0].script : DEFAULT_SCRIPTS_BY_LANG.English
  );

  const [isGenerating, setIsGenerating] = useState(false);
  const [isWritingScript, setIsWritingScript] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedBase64, setGeneratedBase64] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(true);

  const [playback, setPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });

  const [activeImportedScriptName, setActiveImportedScriptName] = useState<string | null>(null);
  const controllerRef = useRef<StudioAudioController | null>(null);
  const scriptFileInputRef = useRef<HTMLInputElement>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    controllerRef.current = new StudioAudioController((state) => {
      if (isMountedRef.current) setPlayback(state);
    });
    return () => {
      isMountedRef.current = false;
      controllerRef.current?.dispose();
      controllerRef.current = null;
    };
  }, []);

  useEffect(() => {
    setIsGamingMode(gamingModeDefault);
    if (gamingModeDefault) {
      applyGamingPreset(GAMING_PRESETS[0]);
    }
  }, [gamingModeDefault]);

  useEffect(() => {
    if (importedScript && importedScript.content) {
      setScriptText(importedScript.content);
      setActiveImportedScriptName(importedScript.name);
      setIsDirty(true);
      setError(null);
    }
  }, [importedScript]);

  useEffect(() => {
    controllerRef.current?.setSpeed(speed);
  }, [speed]);

  useEffect(() => {
    controllerRef.current?.setPitch(pitchSemitones);
  }, [pitchSemitones]);

  const applyGamingPreset = (preset: GamingPreset) => {
    controllerRef.current?.stop();
    setActivePresetId(preset.id);
    setIsGamingMode(true);
    setLanguage(preset.language);
    setAccent(preset.accent);
    setEmotion(preset.emotion);
    setEnergy(preset.energy);
    setSpeed(preset.speed);
    setStyleDirection(preset.styleDirection);
    setScriptText(preset.script);
    setIsDirty(true);
    setError(null);
  };

  const handleVoicePick = (name: string) => {
    controllerRef.current?.stop();
    onSelectVoice(name);
    const picked = voices.find((v) => v.name === name);
    if (picked) {
      if (picked.stylePrompt && !isGamingMode) {
        setStyleDirection(picked.stylePrompt);
      }
      if (picked.language === 'Telugu' || picked.language === 'Tanglish' || picked.language === 'English') {
        setLanguage(picked.language);
      }
      if (picked.accent === 'Andhra' || picked.accent === 'Telangana' || picked.accent === 'Standard') {
        setAccent(picked.accent);
      }
      if (typeof picked.speed === 'number') setSpeed(picked.speed);
      if (typeof picked.pitchSemitones === 'number') setPitchSemitones(picked.pitchSemitones);
      if (typeof picked.energy === 'number') setEnergy(picked.energy);
    }
    setIsDirty(true);
  };

  const handleLanguageChange = (nextLang: LanguageMode) => {
    setLanguage(nextLang);
    if (
      Object.values(DEFAULT_SCRIPTS_BY_LANG).includes(scriptText.trim()) ||
      !scriptText.trim()
    ) {
      setScriptText(DEFAULT_SCRIPTS_BY_LANG[nextLang]);
    }
    setIsDirty(true);
  };

  const handleGenerateGamingScript = async () => {
    if (isWritingScript) return;
    setIsWritingScript(true);
    setError(null);

    try {
      const selectedPreset = GAMING_PRESETS.find((p) => p.id === activePresetId);
      const res = await fetch('/api/voice-studio/gaming-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: selectedPreset?.modeName || 'Funny Telugu Gaming Commentary',
          language,
          accent,
        }),
      });
      const data = await res.json();
      if (!isMountedRef.current) return;
      if (!res.ok || !data.script) {
        throw new Error(data.error || 'Could not generate script.');
      }
      setScriptText(data.script);
      if (data.styleTip) setStyleDirection(data.styleTip);
      setIsDirty(true);
    } catch (err: any) {
      if (isMountedRef.current) {
        setError(err?.message || 'Failed to generate gaming script.');
      }
    } finally {
      if (isMountedRef.current) setIsWritingScript(false);
    }
  };

  const handleSynthesize = async () => {
    if (!scriptText.trim() || !activeVoice) {
      setError('Enter a script first to generate speech.');
      return;
    }

    const policyError = checkClientEthicalVoicePolicy(`${styleDirection} ${scriptText}`);
    if (policyError) {
      setError(policyError);
      return;
    }

    setIsGenerating(true);
    setError(null);
    controllerRef.current?.stop();

    try {
      const res = await fetch('/api/voice-studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: scriptText.trim(),
          baseVoice: activeVoice.baseVoice || activeVoice.name,
          stylePrompt: styleDirection.trim(),
          language,
          accent: language === 'English' ? 'Standard' : accent,
          ageImpression: ageImpression === 'Auto / Voice Default' ? activeVoice.ageImpression : ageImpression,
          emotion,
          energy,
          speed,
          pitchSemitones,
          gamingStyle: isGamingMode
            ? GAMING_PRESETS.find((p) => p.id === activePresetId)?.modeName || 'Gaming Commentary'
            : undefined,
        }),
      });

      const data = await res.json();
      if (!isMountedRef.current) return;
      if (!res.ok || !data.audioBase64) {
        throw new Error(data.error || 'Failed to synthesize audio.');
      }

      setGeneratedBase64(data.audioBase64);
      setIsDirty(false);
      if (controllerRef.current) {
        await controllerRef.current.loadBase64(data.audioBase64);
        controllerRef.current.setSpeed(speed);
        controllerRef.current.setPitch(pitchSemitones);
        await controllerRef.current.play(true);
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        setError(err?.message || 'Speech synthesis failed. Please try again.');
      }
    } finally {
      if (isMountedRef.current) setIsGenerating(false);
    }
  };

  const handlePlayPause = async () => {
    const controller = controllerRef.current;
    if (!controller) return;
    if (playback.isPlaying) {
      controller.pause();
      return;
    }
    if (generatedBase64 && !isDirty && controller.hasAudio()) {
      await controller.play(false);
      return;
    }
    await handleSynthesize();
  };

  const handleReplay = async () => {
    if (controllerRef.current?.hasAudio()) {
      await controllerRef.current.replay();
    }
  };

  const insertToken = (token: string) => {
    setScriptText((prev) =>
      prev.endsWith(' ') || prev.length === 0 ? `${prev}${token} ` : `${prev} ${token} `
    );
    setIsDirty(true);
  };

  const isFavorite = activeVoice ? favoriteNames.includes(activeVoice.name) : false;

  const favoriteVoicesList = useMemo(
    () => voices.filter((v) => favoriteNames.includes(v.name)),
    [voices, favoriteNames]
  );
  const customVoicesList = useMemo(
    () => voices.filter((v) => v.isCustom && !favoriteNames.includes(v.name)),
    [voices, favoriteNames]
  );
  const builtInVoicesList = useMemo(
    () => voices.filter((v) => !v.isCustom && !favoriteNames.includes(v.name)),
    [voices, favoriteNames]
  );

  return (
    <div className="w-full h-full overflow-y-auto custom-scrollbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6 pb-28 sm:pb-10 space-y-5">
        {/* Top Studio Banner */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5">
          <div className="flex items-start sm:items-center gap-3.5 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-indigo-600/15 border border-indigo-500/30 text-indigo-500 dark:text-indigo-400 flex items-center justify-center shrink-0">
              {isGamingMode ? <Gamepad2 size={22} /> : <AudioLines size={22} />}
            </div>
            <div className="min-w-0">
              <h2 className="text-lg sm:text-xl font-bold tracking-tight text-zinc-900 dark:text-white truncate">
                {isGamingMode ? 'Gaming Voice Mode & Telugu Studio' : 'AI Audio Studio'}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
                Real-time Gemini 3.8 Flash TTS with Telugu / Tanglish accents, speed &amp; pitch tuning, and WAV export.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                const next = !isGamingMode;
                setIsGamingMode(next);
                if (next && !activePresetId) {
                  applyGamingPreset(GAMING_PRESETS[0]);
                }
              }}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold border flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
                isGamingMode
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-600 dark:text-emerald-300'
                  : 'bg-zinc-100 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 hover:border-indigo-500/50'
              }`}
            >
              <Gamepad2 size={16} />
              <span>Gaming Mode: {isGamingMode ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenCompareWithScript(scriptText, language, accent)}
              className="min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-zinc-900 dark:bg-zinc-800 hover:bg-indigo-600 dark:hover:bg-indigo-600 text-white border border-zinc-800 dark:border-zinc-700 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <GitCompare size={15} />
              <span>Compare Voices on Script</span>
            </button>
          </div>
        </div>

        {/* Gaming Voice Mode Presets Strip */}
        {isGamingMode && (
          <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                <Gamepad2 size={15} />
                <span>Gaming &amp; Comedy Delivery Modes</span>
              </div>
              <button
                type="button"
                onClick={handleGenerateGamingScript}
                disabled={isWritingScript}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                {isWritingScript ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />}
                <span>{isWritingScript ? 'Writing Script...' : 'AI Write Fresh Script'}</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {GAMING_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => applyGamingPreset(preset)}
                  className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                    activePresetId === preset.id
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                      : 'bg-zinc-50 dark:bg-zinc-950/60 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-indigo-500/50'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Main Studio 2-Column Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: Voice & Acoustic Controls */}
          <div className="lg:col-span-5 space-y-4 bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5">
            {/* Voice Selector + Favorite */}
            <div className="space-y-1.5">
              <label
                htmlFor="studio-voice-select"
                className="block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400"
              >
                Active Voice Performer
              </label>
              <div className="flex items-center gap-2">
                <select
                  id="studio-voice-select"
                  value={activeVoice?.name || ''}
                  onChange={(e) => handleVoicePick(e.target.value)}
                  className="flex-1 min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                >
                  {favoriteVoicesList.length > 0 && (
                    <optgroup label="My Voice Library (Favorites)">
                      {favoriteVoicesList.map((v) => (
                        <option key={`fav-${v.name}`} value={v.name}>
                          ★ {v.name} ({v.analysis.gender}, {v.pitch})
                        </option>
                      ))}
                    </optgroup>
                  )}
                  {customVoicesList.length > 0 && (
                    <optgroup label="Custom & Cloned Voices">
                      {customVoicesList.map((v) => (
                        <option key={`cust-${v.name}`} value={v.name}>
                          {v.name} ({v.isCloned ? 'Cloned' : 'Custom'} · {v.analysis.gender})
                        </option>
                      ))}
                    </optgroup>
                  )}
                  <optgroup label="Studio Base Voices">
                    {builtInVoicesList.map((v) => (
                      <option key={v.name} value={v.name}>
                        {v.name} ({v.analysis.gender}, {v.pitch})
                      </option>
                    ))}
                  </optgroup>
                </select>

                {activeVoice && (
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(activeVoice.name)}
                    className={`min-h-[44px] min-w-[44px] rounded-xl border flex items-center justify-center transition-colors shrink-0 ${
                      isFavorite
                        ? 'bg-rose-500/15 border-rose-500/40 text-rose-500'
                        : 'bg-zinc-50 dark:bg-zinc-950 border-zinc-200 dark:border-zinc-700 text-zinc-400 hover:text-rose-400'
                    }`}
                    title={isFavorite ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
                    aria-label={isFavorite ? 'Remove from My Voice Library' : 'Save to My Voice Library'}
                  >
                    <Heart size={18} className={isFavorite ? 'fill-current' : ''} />
                  </button>
                )}
              </div>
              {activeVoice && (
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {activeVoice.analysis.gender} · {activeVoice.pitch} Pitch ·{' '}
                  {activeVoice.baseVoice ? `Timbre: ${activeVoice.baseVoice}` : activeVoice.characteristics.join(', ')}
                </p>
              )}
            </div>

            {/* Language & Telugu Accent */}
            <div className="space-y-3 pt-2 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                <Languages size={14} className="text-indigo-500" />
                <span>Language &amp; Accent</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {(['English', 'Telugu', 'Tanglish'] as LanguageMode[]).map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => handleLanguageChange(lang)}
                    className={`min-h-[44px] px-2.5 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                      language === lang
                        ? 'bg-indigo-600 text-white border-indigo-500'
                        : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-indigo-500/50'
                    }`}
                  >
                    {lang === 'Telugu' ? 'తెలుగు' : lang === 'Tanglish' ? 'Tanglish' : 'English'}
                  </button>
                ))}
              </div>

              {language !== 'English' && (
                <div>
                  <span className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
                    Telugu Regional Accent
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Andhra', 'Telangana', 'Standard'] as TeluguAccent[]).map((region) => (
                      <button
                        key={region}
                        type="button"
                        onClick={() => {
                          setAccent(region);
                          setIsDirty(true);
                        }}
                        className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                          accent === region
                            ? 'bg-amber-500/15 border-amber-500/50 text-amber-600 dark:text-amber-300'
                            : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-800'
                        }`}
                      >
                        {region}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Vocal Expression & Sliders */}
            <div className="space-y-3.5 pt-2 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                <Sliders size={14} className="text-indigo-500" />
                <span>Vocal Tuning</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Emotion
                  </label>
                  <select
                    value={emotion}
                    onChange={(e) => {
                      setEmotion(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {EMOTIONS.map((em) => (
                      <option key={em} value={em}>
                        {em}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Age Impression
                  </label>
                  <select
                    value={ageImpression}
                    onChange={(e) => {
                      setAgeImpression(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {AGE_IMPRESSIONS.map((age) => (
                      <option key={age} value={age}>
                        {age}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Speed */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-600 dark:text-zinc-300 font-medium">Speaking Speed</span>
                  <span className="font-mono tabular-nums text-indigo-600 dark:text-indigo-400 font-semibold">
                    {speed.toFixed(2)}x
                  </span>
                </div>
                <input
                  type="range"
                  min={0.75}
                  max={1.45}
                  step={0.05}
                  value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                  aria-label="Speaking speed"
                />
              </div>

              {/* Pitch */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-600 dark:text-zinc-300 font-medium">Pitch Shift</span>
                  <span className="font-mono tabular-nums text-indigo-600 dark:text-indigo-400 font-semibold">
                    {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} st
                  </span>
                </div>
                <input
                  type="range"
                  min={-6}
                  max={6}
                  step={1}
                  value={pitchSemitones}
                  onChange={(e) => setPitchSemitones(parseInt(e.target.value, 10))}
                  className="w-full accent-indigo-500 cursor-pointer"
                  aria-label="Pitch shift in semitones"
                />
              </div>

              {/* Energy */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-600 dark:text-zinc-300 font-medium">Vocal Energy</span>
                  <span className="font-mono tabular-nums text-indigo-600 dark:text-indigo-400 font-semibold">
                    {energy}%
                  </span>
                </div>
                <input
                  type="range"
                  min={20}
                  max={100}
                  step={5}
                  value={energy}
                  onChange={(e) => {
                    setEnergy(parseInt(e.target.value, 10));
                    setIsDirty(true);
                  }}
                  className="w-full accent-indigo-500 cursor-pointer"
                  aria-label="Vocal energy"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Script Editor, Transport & Export */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-4">
              <div>
                <label
                  htmlFor="studio-style-direction"
                  className="block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5"
                >
                  Delivery &amp; Accent Direction
                </label>
                <input
                  id="studio-style-direction"
                  type="text"
                  value={styleDirection}
                  onChange={(e) => {
                    setStyleDirection(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="Describe tone, accent, comedic timing, or dramatic pauses..."
                  className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                />
              </div>

              <div>
                <input
                  ref={scriptFileInputRef}
                  type="file"
                  accept={SCRIPT_FILE_ACCEPT}
                  onChange={async (e) => {
                    const picked = Array.from(e.target.files || []);
                    e.target.value = '';
                    if (picked.length === 0) return;
                    setError(null);
                    try {
                      if (onImportScriptFiles) {
                        const { saved, rejected } = await onImportScriptFiles(picked, 'script');
                        if (saved.length > 0 && saved[0].textContent) {
                          setScriptText(saved[0].textContent);
                          setActiveImportedScriptName(saved[0].name);
                          setIsDirty(true);
                        } else if (rejected.length > 0) {
                          setError(rejected.join(' '));
                        }
                      } else {
                        const text = (await picked[0].text()).replace(/^\uFEFF/, '').trim();
                        if (text) {
                          setScriptText(text);
                          setActiveImportedScriptName(picked[0].name);
                          setIsDirty(true);
                        }
                      }
                    } catch (err: any) {
                      setError(err?.message || 'Failed to read text file.');
                    }
                  }}
                  className="hidden"
                  aria-hidden="true"
                />

                <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <label
                      htmlFor="studio-script-textarea"
                      className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400"
                    >
                      Script ({language}
                      {language !== 'English' ? ` · ${accent}` : ''})
                    </label>
                    {activeImportedScriptName && (
                      <span className="text-[11px] font-medium text-teal-600 dark:text-teal-400 truncate max-w-[200px]">
                        · Imported: {activeImportedScriptName}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => scriptFileInputRef.current?.click()}
                      className="px-2.5 py-1 rounded-lg bg-teal-600/15 hover:bg-teal-600/25 text-teal-600 dark:text-teal-300 border border-teal-500/30 text-[11px] font-semibold flex items-center gap-1 transition-colors whitespace-nowrap"
                    >
                      <FileText size={11} />
                      <span>Import .txt / .srt</span>
                    </button>
                    {onOpenFileManager && (
                      <button
                        type="button"
                        onClick={onOpenFileManager}
                        className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 text-[11px] font-medium flex items-center gap-1 transition-colors whitespace-nowrap"
                      >
                        <FolderOpen size={11} />
                        <span>Files{vaultScripts.length > 0 ? ` (${vaultScripts.length})` : ''}</span>
                      </button>
                    )}
                    {[
                      { label: '<breath>', token: '<breath>' },
                      { label: '<laugh>', token: '<laugh>' },
                      { label: '<gasp>', token: '<gasp>' },
                      { label: 'Pause (...)', token: '...' },
                    ].map((item) => (
                      <button
                        key={item.label}
                        type="button"
                        onClick={() => insertToken(item.token)}
                        className="px-2 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-indigo-500/20 text-zinc-600 dark:text-zinc-300 font-mono text-[11px] transition-colors"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {vaultScripts.length > 0 && (
                  <div className="mb-2 flex items-center gap-2">
                    <select
                      value=""
                      onChange={(e) => {
                        const found = vaultScripts.find((s) => s.id === e.target.value);
                        if (found?.textContent) {
                          setScriptText(found.textContent);
                          setActiveImportedScriptName(found.name);
                          setIsDirty(true);
                          setError(null);
                        }
                      }}
                      aria-label="Load an imported script from File Manager"
                      className="w-full sm:w-auto min-h-[38px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      <option value="" disabled>
                        Load saved script from File Manager ({vaultScripts.length})...
                      </option>
                      {vaultScripts.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({s.formatLabel})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <textarea
                  id="studio-script-textarea"
                  rows={5}
                  value={scriptText}
                  onChange={(e) => {
                    setScriptText(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="Write your English, Telugu (తెలుగు), or Tanglish script here..."
                  className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-4 py-3 text-sm sm:text-base text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-y leading-relaxed"
                />
              </div>

              {error && (
                <div className="flex items-start gap-2.5 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-300 text-xs sm:text-sm">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleSynthesize}
                  disabled={isGenerating || !scriptText.trim()}
                  className="min-h-[46px] px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold flex items-center gap-2 shadow-sm transition-colors whitespace-nowrap"
                >
                  {isGenerating ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                  <span>
                    {isGenerating
                      ? 'Synthesizing Speech...'
                      : generatedBase64 && !isDirty
                      ? 'Regenerate Speech'
                      : 'Generate Speech'}
                  </span>
                </button>

                <span className="text-xs text-zinc-500 dark:text-zinc-400">
                  Real-time synthesis via Gemini 3.8 Flash TTS
                </span>
              </div>
            </div>

            {/* Playback & Export Deck */}
            <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden">
              <div className="h-28 relative bg-zinc-50 dark:bg-zinc-950 flex items-center justify-center px-4 border-b border-zinc-100 dark:border-zinc-800">
                {playback.isPlaying ? (
                  <div className="w-full h-full">
                    <AudioVisualizer
                      isPlaying={true}
                      color="#6366f1"
                      analyser={controllerRef.current?.getAnalyser() || null}
                    />
                  </div>
                ) : (
                  <div className="text-center space-y-1">
                    <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                      {generatedBase64
                        ? isDirty
                          ? 'Parameters changed — click Regenerate Speech or play last take'
                          : 'Audio ready. Use Play, Pause, Replay, Speed, or Pitch controls below.'
                        : 'Generate speech above to unlock studio playback and WAV export.'}
                    </p>
                  </div>
                )}
              </div>

              <div className="p-4 space-y-3">
                {/* Timeline Scrubber */}
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono tabular-nums text-zinc-500 dark:text-zinc-400 w-10">
                    {formatStudioTime(playback.currentTime)}
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(0.1, playback.duration || 0.1)}
                    step={0.05}
                    value={Math.min(playback.currentTime, playback.duration || 0)}
                    disabled={!generatedBase64 || playback.duration === 0}
                    onChange={(e) => controllerRef.current?.seek(parseFloat(e.target.value))}
                    className="flex-1 accent-indigo-500 cursor-pointer disabled:opacity-40"
                    aria-label="Audio playback progress"
                  />
                  <span className="text-xs font-mono tabular-nums text-zinc-500 dark:text-zinc-400 w-10 text-right">
                    {formatStudioTime(playback.duration)}
                  </span>
                </div>

                {/* Transport Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handlePlayPause}
                      disabled={isGenerating || (!generatedBase64 && !scriptText.trim())}
                      className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:opacity-90 disabled:opacity-40 text-xs sm:text-sm font-semibold flex items-center gap-2 transition-opacity whitespace-nowrap"
                    >
                      {playback.isPlaying ? (
                        <>
                          <Pause size={15} className="fill-current" />
                          <span>Pause</span>
                        </>
                      ) : (
                        <>
                          <Play size={15} className="fill-current" />
                          <span>{playback.isPaused ? 'Resume' : 'Play'}</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleReplay}
                      disabled={!generatedBase64 || isGenerating}
                      className="min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 disabled:opacity-40 text-zinc-700 dark:text-zinc-200 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap"
                    >
                      <RotateCcw size={14} />
                      <span>Replay</span>
                    </button>
                  </div>

                  {!generatedBase64 && (
                    <span className="text-xs text-zinc-400">
                      Generate speech to unlock Download to Phone
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Generated Audio Result Card — only shown after successful generation */}
            {generatedBase64 && !isDirty && (
              <GeneratedAudioResultCard
                audioBase64={generatedBase64}
                voiceName={activeVoice?.name || 'Studio'}
                language={language}
                accent={accent}
                styleLabel={emotion}
                isGamingMode={isGamingMode}
                isCloned={Boolean(activeVoice?.isCloned)}
                speed={speed}
                pitchSemitones={pitchSemitones}
                durationSec={playback.duration}
                currentTimeSec={playback.currentTime}
                isPlaying={playback.isPlaying}
                isPaused={playback.isPaused}
                onPlayPause={handlePlayPause}
                onReplay={handleReplay}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioStudioView;
