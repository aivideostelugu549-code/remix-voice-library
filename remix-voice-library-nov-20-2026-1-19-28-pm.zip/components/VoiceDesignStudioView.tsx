/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Wand2,
  Sparkles,
  Loader2,
  Play,
  Pause,
  RotateCcw,
  Heart,
  RefreshCw,
  AlertCircle,
  Check,
  Sliders,
  Languages,
  AudioLines,
  Info,
} from 'lucide-react';
import {
  Voice,
  VoiceDesignVariation,
  LanguageMode,
  TeluguAccent,
} from '../types';
import AudioVisualizer from './AudioVisualizer';
import GeneratedAudioResultCard from './GeneratedAudioResultCard';
import {
  StudioAudioController,
  StudioPlaybackState,
  checkClientEthicalVoicePolicy,
  formatStudioTime,
} from '../utils/audioStudioPlayer';

interface VoiceDesignStudioViewProps {
  baseVoices: Voice[];
  allVoices: Voice[];
  favoriteNames: string[];
  existingNames: string[];
  onSaveToMyLibrary: (voice: Voice) => void;
  onToggleFavorite: (voiceName: string) => void;
  onOpenInAudioStudio: (voiceName: string) => void;
}

interface PromptIdea {
  label: string;
  description: string;
  language: LanguageMode;
  accent: string;
  gender: string;
  ageImpression: string;
  pitchLevel: string;
  speed: number;
  energy: number;
  emotion: string;
  personality: string;
  sampleScript: string;
}

const VOICE_PROMPT_IDEAS: PromptIdea[] = [
  {
    label: 'Funny Telugu Gamer',
    description:
      'Funny young Telugu male gaming commentator with energetic comedic timing, playful Telangana reactions, and crisp Tanglish callouts.',
    language: 'Tanglish',
    accent: 'Telangana',
    gender: 'Male',
    ageImpression: '18–22 Young Gamer',
    pitchLevel: 'Medium',
    speed: 1.08,
    energy: 88,
    emotion: 'Funny & Playful',
    personality: 'Witty Commentator',
    sampleScript:
      'అరేయ్ మామా! ఎనిమీ ముందు నిలబడితే గన్ రీలోడ్ చేయడం మర్చిపోయాడు... <laugh> ఛీ ఛీ, ఇంత మంచి క్లచ్ మిస్ అయ్యాడు పాపం!',
  },
  {
    label: 'Energetic Indian Male (20–23)',
    description:
      'Energetic Indian male voice, age impression 20–23, upbeat youth creator tone with crisp modern pronunciation and confident warmth.',
    language: 'English',
    accent: 'Indian English',
    gender: 'Male',
    ageImpression: '20–23 Young Adult',
    pitchLevel: 'Medium',
    speed: 1.05,
    energy: 82,
    emotion: 'Excited & Hyped',
    personality: 'Approachable Best Friend',
    sampleScript:
      'Hey everyone! <breath> Welcome back to the channel — today we are testing something seriously next-level!',
  },
  {
    label: 'Soft & Friendly Male',
    description:
      'Soft, smooth and friendly male voice with calm close-mic warmth, gentle conversational pauses, and reassuring clarity.',
    language: 'English',
    accent: 'Neutral',
    gender: 'Male',
    ageImpression: '25–35 Creator',
    pitchLevel: 'Medium-Low',
    speed: 0.96,
    energy: 42,
    emotion: 'Soft & Friendly',
    personality: 'Calm Storyteller',
    sampleScript:
      'Hey there, take a deep breath and settle in. <breath> Let me walk you through everything step by step, nice and easy.',
  },
  {
    label: 'Deep Cinematic Horror Narrator',
    description:
      'Deep cinematic horror narrator with dark resonant bass, spine-chilling deliberate pauses, and eerie atmospheric tension.',
    language: 'English',
    accent: 'Neutral',
    gender: 'Male',
    ageImpression: '35–50 Warm Mature',
    pitchLevel: 'Low',
    speed: 0.86,
    energy: 64,
    emotion: 'Dramatic & Horror',
    personality: 'Commanding Narrator',
    sampleScript:
      'At three in the morning, the hallway lights flickered out... <gasp> and something whispered my name from behind the locked door.',
  },
  {
    label: 'Cute Cartoon Character',
    description:
      'Cute cartoon character voice, bouncy high-pitched animated energy, cheerful mischief, and playful expressive reactions.',
    language: 'English',
    accent: 'Neutral',
    gender: 'Auto',
    ageImpression: 'Youthful Cartoon',
    pitchLevel: 'High',
    speed: 1.12,
    energy: 92,
    emotion: 'Cheerful & Animated',
    personality: 'Animated Mascot',
    sampleScript:
      'Whoa-oa! Did you see that giant floating donut?! <laugh> Wait for me, I am totally grabbing the sprinkles!',
  },
  {
    label: 'Andhra Telugu Storyteller',
    description:
      'Professional Telugu storyteller with authentic Coastal Andhra intonation, expressive dramatic pauses, and rich cinematic narrative poise.',
    language: 'Telugu',
    accent: 'Andhra',
    gender: 'Male',
    ageImpression: '35–50 Warm Mature',
    pitchLevel: 'Medium-Low',
    speed: 0.94,
    energy: 70,
    emotion: 'Warm Storyteller',
    personality: 'Commanding Narrator',
    sampleScript:
      'ఆ రాత్రి గోదావరి తీరంలో చీకటి కమ్ముకుంది... <breath> దూరంగా వినిపించిన ఆ అడుగుల చప్పుడు కథ మొత్తాన్ని మార్చేసింది.',
  },
];

const GENDER_CHOICES = ['Auto', 'Male', 'Female', 'Neutral'];
const AGE_CHOICES = [
  '18–22 Young Gamer',
  '20–23 Young Adult',
  '25–35 Creator',
  '35–50 Warm Mature',
  '50+ Deep Elder',
  'Youthful Cartoon',
];
const PITCH_CHOICES = ['Low', 'Medium-Low', 'Medium', 'Medium-High', 'High'];
const EMOTION_CHOICES = [
  'Funny & Playful',
  'Excited & Hyped',
  'Soft & Friendly',
  'Dramatic & Horror',
  'Cheerful & Animated',
  'Warm Storyteller',
  'Sarcastic',
  'Natural & Conversational',
];
const PERSONALITY_CHOICES = [
  'Witty Commentator',
  'Approachable Best Friend',
  'Commanding Narrator',
  'Animated Mascot',
  'Calm Storyteller',
  'Sarcastic Roaster',
];

const REFINEMENT_CHIPS = [
  { label: '+ More Energetic', suffix: 'Boost vocal energy, excitement, and punchy reactions.' },
  { label: '+ Deeper & Slower', suffix: 'Make the voice deeper, calmer, and slightly slower with longer pauses.' },
  { label: '+ More Funny Telugu', suffix: 'Add witty conversational Telugu comedy inflection and natural laughter.' },
  { label: '+ Softer & Warmer', suffix: 'Smooth out sharp edges for a softer, friendlier close-mic feel.' },
];

const VoiceDesignStudioView: React.FC<VoiceDesignStudioViewProps> = ({
  baseVoices,
  allVoices,
  favoriteNames,
  existingNames,
  onSaveToMyLibrary,
  onToggleFavorite,
  onOpenInAudioStudio,
}) => {
  const [description, setDescription] = useState(VOICE_PROMPT_IDEAS[0].description);
  const [customScript, setCustomScript] = useState(VOICE_PROMPT_IDEAS[0].sampleScript);
  const [language, setLanguage] = useState<LanguageMode>('Tanglish');
  const [accent, setAccent] = useState<string>('Telangana');
  const [gender, setGender] = useState<string>('Male');
  const [ageImpression, setAgeImpression] = useState<string>('18–22 Young Gamer');
  const [pitchLevel, setPitchLevel] = useState<string>('Medium');
  const [speed, setSpeed] = useState<number>(1.08);
  const [pitchSemitones, setPitchSemitones] = useState<number>(0);
  const [energy, setEnergy] = useState<number>(88);
  const [emotion, setEmotion] = useState<string>('Funny & Playful');
  const [personality, setPersonality] = useState<string>('Witty Commentator');
  const [variationCount, setVariationCount] = useState<number>(3);

  const [isGenerating, setIsGenerating] = useState(false);
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [variations, setVariations] = useState<VoiceDesignVariation[]>([]);
  const [savedIds, setSavedIds] = useState<Record<string, string>>({});

  // Single audio controller shared across variation preview cards
  const [activeVariationId, setActiveVariationId] = useState<string | null>(null);
  const [playback, setPlayback] = useState<StudioPlaybackState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
  });

  const controllerRef = useRef<StudioAudioController | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    controllerRef.current = new StudioAudioController((next) => {
      if (isMountedRef.current) setPlayback(next);
    });
    return () => {
      isMountedRef.current = false;
      controllerRef.current?.dispose();
      controllerRef.current = null;
    };
  }, []);

  useEffect(() => {
    controllerRef.current?.setSpeed(speed);
  }, [speed]);

  useEffect(() => {
    controllerRef.current?.setPitch(pitchSemitones);
  }, [pitchSemitones]);

  const accentOptions = useMemo(() => {
    if (language === 'English') {
      return ['Neutral', 'Indian English', 'American', 'British'];
    }
    return ['Andhra', 'Telangana', 'Standard'];
  }, [language]);

  const mySavedLibraryVoices = useMemo(
    () =>
      allVoices.filter(
        (v) => v.isCustom || favoriteNames.includes(v.name)
      ),
    [allVoices, favoriteNames]
  );

  const applyIdea = (idea: PromptIdea) => {
    controllerRef.current?.stop();
    setActiveVariationId(null);
    setDescription(idea.description);
    setCustomScript(idea.sampleScript);
    setLanguage(idea.language);
    setAccent(idea.accent);
    setGender(idea.gender);
    setAgeImpression(idea.ageImpression);
    setPitchLevel(idea.pitchLevel);
    setSpeed(idea.speed);
    setEnergy(idea.energy);
    setEmotion(idea.emotion);
    setPersonality(idea.personality);
    setError(null);
  };

  const applyTeluguPreset = (preset: 'andhra' | 'telangana' | 'tanglish' | 'gaming') => {
    if (preset === 'andhra') {
      setLanguage('Telugu');
      setAccent('Andhra');
      setEmotion('Warm Storyteller');
      setCustomScript(
        'నమస్కారం అండీ! మన ఆంధ్ర తెలుగు యాసలో కథ చెప్తుంటే ఆ ఫీల్ వేరే లెవెల్‌లో ఉంటుంది.'
      );
    } else if (preset === 'telangana') {
      setLanguage('Telugu');
      setAccent('Telangana');
      setEmotion('Funny & Playful');
      setCustomScript(
        'ఏం మామా, ఎట్లున్నావ్? మన తెలంగాణ యాసలో డైలాగ్ కొడితే అదుర్స్ అంతే!'
      );
    } else if (preset === 'tanglish') {
      setLanguage('Tanglish');
      setAccent('Standard');
      setEmotion('Natural & Conversational');
      setCustomScript(
        'హలో ఫ్రెండ్స్! తెలుగు మరియు English మిక్స్ చేసి <breath> సూపర్ నాచురల్ గా మాట్లాడొచ్చు.'
      );
    } else {
      setLanguage('Tanglish');
      setAccent('Telangana');
      setGender('Male');
      setAgeImpression('18–22 Young Gamer');
      setEnergy(90);
      setSpeed(1.08);
      setEmotion('Funny & Playful');
      setPersonality('Witty Commentator');
      setDescription(
        'Funny young Telugu male gaming commentator reacting with hilarious Telangana timing and hype Tanglish gaming callouts.'
      );
      setCustomScript(
        'ఒరేయ్ భయ్యా, వన్ హెచ్‌పీ లో ఉన్నాడు! <gasp> కొట్టు కొట్టు... YES! పూర్తిగా OP ఆడేశావ్ రా బాబు!'
      );
    }
  };

  const handleGenerateVoices = async (overrideDesc?: string) => {
    const promptText = (overrideDesc ?? description).trim();
    if (!promptText) {
      setError('Please describe the voice you want to create.');
      return;
    }

    const policyErr = checkClientEthicalVoicePolicy(`${promptText} ${customScript}`);
    if (policyErr) {
      setError(policyErr);
      return;
    }

    controllerRef.current?.stop();
    setActiveVariationId(null);
    setIsGenerating(true);
    setError(null);

    try {
      const simplifiedVoices = baseVoices.map((v) => ({
        name: v.name,
        gender: v.analysis.gender,
        pitch: v.analysis.pitch,
        characteristics: v.analysis.characteristics,
      }));

      const res = await fetch('/api/voice-studio/design-variations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: promptText,
          language,
          accent,
          gender,
          ageImpression,
          pitchLevel,
          speed,
          pitchSemitones,
          energy,
          emotion,
          personality,
          customScript: customScript.trim() || undefined,
          variationCount,
          availableVoices: simplifiedVoices,
        }),
      });

      const data = await res.json();
      if (!isMountedRef.current) return;

      if (!res.ok) {
        throw new Error(data.error || 'Voice generation failed.');
      }

      const list: VoiceDesignVariation[] = Array.isArray(data.variations) ? data.variations : [];
      if (list.length === 0) {
        throw new Error('No voice variations returned. Please refine your prompt and retry.');
      }

      setVariations(list);
      setSavedIds({});

      const firstPlayable = list.find((v) => Boolean(v.audioBase64));
      if (firstPlayable?.audioBase64 && controllerRef.current) {
        await controllerRef.current.loadBase64(firstPlayable.audioBase64);
        controllerRef.current.setSpeed(speed);
        controllerRef.current.setPitch(pitchSemitones);
        setActiveVariationId(firstPlayable.id);
        await controllerRef.current.play(true);
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        setError(err?.message || 'Failed to generate voices. Please check API configuration and try again.');
      }
    } finally {
      if (isMountedRef.current) setIsGenerating(false);
    }
  };

  const handleRegenerateVariation = async (variation: VoiceDesignVariation) => {
    if (!variation.sampleText.trim()) return;
    const policyErr = checkClientEthicalVoicePolicy(
      `${variation.suggestedName} ${variation.stylePrompt} ${variation.sampleText}`
    );
    if (policyErr) {
      setError(policyErr);
      return;
    }

    setRegeneratingId(variation.id);
    setError(null);

    try {
      const res = await fetch('/api/voice-studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: variation.sampleText.trim(),
          baseVoice: variation.baseVoice,
          stylePrompt: variation.stylePrompt,
          language,
          accent,
          ageImpression: variation.ageImpression || ageImpression,
          emotion: variation.emotion || emotion,
          energy,
          speed,
          pitchSemitones,
          gamingStyle:
            variation.styleCategory?.toLowerCase().includes('gaming') ? 'Gaming Commentary' : undefined,
        }),
      });

      const data = await res.json();
      if (!isMountedRef.current) return;

      if (!res.ok || !data.audioBase64) {
        throw new Error(data.error || 'Failed to regenerate voice audio.');
      }

      setVariations((prev) =>
        prev.map((item) =>
          item.id === variation.id
            ? { ...item, audioBase64: data.audioBase64, audioError: null }
            : item
        )
      );

      if (controllerRef.current) {
        await controllerRef.current.loadBase64(data.audioBase64);
        controllerRef.current.setSpeed(speed);
        controllerRef.current.setPitch(pitchSemitones);
        setActiveVariationId(variation.id);
        await controllerRef.current.play(true);
      }
    } catch (err: any) {
      if (isMountedRef.current) {
        setError(err?.message || 'Failed to regenerate variation.');
      }
    } finally {
      if (isMountedRef.current) setRegeneratingId(null);
    }
  };

  const handlePlayPauseVariation = async (variation: VoiceDesignVariation) => {
    const controller = controllerRef.current;
    if (!controller || !variation.audioBase64) return;

    if (activeVariationId === variation.id) {
      if (playback.isPlaying) {
        controller.pause();
      } else if (playback.isPaused) {
        await controller.play(false);
      } else {
        await controller.play(true);
      }
      return;
    }

    controller.stop();
    await controller.loadBase64(variation.audioBase64);
    controller.setSpeed(speed);
    controller.setPitch(pitchSemitones);
    setActiveVariationId(variation.id);
    await controller.play(true);
  };

  const handleReplayVariation = async (variation: VoiceDesignVariation) => {
    const controller = controllerRef.current;
    if (!controller || !variation.audioBase64) return;
    if (activeVariationId !== variation.id) {
      await controller.loadBase64(variation.audioBase64);
      controller.setSpeed(speed);
      controller.setPitch(pitchSemitones);
      setActiveVariationId(variation.id);
    }
    await controller.play(true);
  };

  const handleSaveVariation = (variation: VoiceDesignVariation) => {
    let finalName = variation.suggestedName.trim() || 'Designed Voice';
    if (existingNames.some((n) => n.toLowerCase() === finalName.toLowerCase())) {
      finalName = `${finalName} ${Math.floor(10 + Math.random() * 89)}`;
    }

    const baseObj = baseVoices.find((v) => v.name === variation.baseVoice) || baseVoices[0];
    const newVoice: Voice = {
      name: finalName,
      pitch: variation.pitch || pitchLevel,
      characteristics:
        variation.characteristics.length > 0
          ? variation.characteristics
          : [emotion, personality, language],
      audioSampleUrl: baseObj?.audioSampleUrl || '',
      fileUri: baseObj?.fileUri || '',
      imageUrl: baseObj?.imageUrl || '',
      isCustom: true,
      language,
      accent: language === 'English' ? 'Standard' : (accent as TeluguAccent),
      ageImpression: variation.ageImpression || ageImpression,
      styleCategory: variation.styleCategory || 'Voice Design',
      emotion: variation.emotion || emotion,
      personality: variation.personality || personality,
      speed,
      pitchSemitones,
      energy,
      isGamingMode:
        Boolean(variation.styleCategory?.toLowerCase().includes('gaming')) ||
        description.toLowerCase().includes('gaming'),
      baseVoice: variation.baseVoice,
      stylePrompt: variation.stylePrompt,
      sampleText: variation.sampleText,
      analysis: {
        gender: variation.gender || (gender === 'Auto' ? 'Male' : gender),
        pitch: variation.pitch || pitchLevel,
        characteristics:
          variation.characteristics.length > 0
            ? variation.characteristics
            : [emotion, personality, language],
        visualDescription: `Designed via Voice Design Studio (${variation.variationLabel})`,
      },
    };

    onSaveToMyLibrary(newVoice);
    setSavedIds((prev) => ({ ...prev, [variation.id]: finalName }));
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar pb-24 md:pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Studio Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Wand2 size={17} />
              <span className="text-xs font-bold uppercase tracking-wider">
                Text-to-Voice Design Studio
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
              Design Original AI Voices From Any Prompt
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 max-w-2xl">
              Describe age, personality, Telugu Andhra/Telangana accents, Tanglish comedy, horror narration, or cartoon tones — and audition multiple synthesized voice variations before saving or downloading.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400 bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2.5 shrink-0">
            <Info size={15} className="text-indigo-500 shrink-0" />
            <span>
              Powered by Gemini 3.8 Flash TTS via secure backend API key (Settings &gt; Secrets).
            </span>
          </div>
        </div>

        {/* Main 12-Column Studio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column (5 cols): Prompt + Customization Controls */}
          <div className="lg:col-span-5 bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-5">
            {/* Voice Description Box */}
            <div className="space-y-2">
              <label
                htmlFor="voice-design-description"
                className="block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400"
              >
                Voice Description Prompt
              </label>
              <textarea
                id="voice-design-description"
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the voice you want (e.g., Funny young Telugu male gaming commentator, energetic 20–23 Indian male, soft friendly male, or deep cinematic horror narrator)..."
                className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-4 py-3 text-sm sm:text-base text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-y leading-relaxed"
              />

              {/* Prompt Ideas */}
              <div className="space-y-1.5 pt-1">
                <span className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                  Try an Example Voice Prompt
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {VOICE_PROMPT_IDEAS.map((idea) => (
                    <button
                      key={idea.label}
                      type="button"
                      onClick={() => applyIdea(idea)}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-950 hover:bg-indigo-600/15 hover:text-indigo-600 dark:hover:text-indigo-300 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 transition-colors whitespace-nowrap"
                    >
                      {idea.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Telugu & Language Preset Strip */}
            <div className="space-y-2.5 pt-3 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
                  <Languages size={14} className="text-indigo-500" />
                  Language &amp; Regional Accent
                </span>
                <div className="flex items-center gap-1">
                  {[
                    { id: 'andhra' as const, label: 'Andhra' },
                    { id: 'telangana' as const, label: 'Telangana' },
                    { id: 'tanglish' as const, label: 'Tanglish' },
                    { id: 'gaming' as const, label: 'TE Gaming' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => applyTeluguPreset(p.id)}
                      className="px-2 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 text-[11px] font-semibold transition-colors whitespace-nowrap"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {(['English', 'Telugu', 'Tanglish'] as LanguageMode[]).map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => {
                      setLanguage(lang);
                      if (lang === 'English') setAccent('Indian English');
                      else if (accent !== 'Andhra' && accent !== 'Telangana') setAccent('Telangana');
                    }}
                    className={`min-h-[42px] px-2.5 py-2 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                      language === lang
                        ? 'bg-indigo-600 text-white border-indigo-500'
                        : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800'
                    }`}
                  >
                    {lang === 'Telugu' ? 'తెలుగు' : lang}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Accent
                  </label>
                  <select
                    value={accentOptions.includes(accent) ? accent : accentOptions[0]}
                    onChange={(e) => setAccent(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {accentOptions.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Gender Presentation
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {GENDER_CHOICES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Persona & Acoustic Controls */}
            <div className="space-y-3 pt-3 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                <Sliders size={14} className="text-indigo-500" />
                <span>Custom Voice Controls</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Perceived Age
                  </label>
                  <select
                    value={ageImpression}
                    onChange={(e) => setAgeImpression(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {AGE_CHOICES.map((age) => (
                      <option key={age} value={age}>
                        {age}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Pitch Profile
                  </label>
                  <select
                    value={pitchLevel}
                    onChange={(e) => setPitchLevel(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {PITCH_CHOICES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Emotion
                  </label>
                  <select
                    value={emotion}
                    onChange={(e) => setEmotion(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {EMOTION_CHOICES.map((em) => (
                      <option key={em} value={em}>
                        {em}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    Voice Personality
                  </label>
                  <select
                    value={personality}
                    onChange={(e) => setPersonality(e.target.value)}
                    className="w-full min-h-[42px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs font-medium text-zinc-900 dark:text-white"
                  >
                    {PERSONALITY_CHOICES.map((pers) => (
                      <option key={pers} value={pers}>
                        {pers}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Speed, Fine Pitch, Energy Sliders */}
              <div className="space-y-3 bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3.5">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Speaking Speed</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {speed.toFixed(2)}x
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.75}
                    max={1.45}
                    step={0.05}
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Pitch Offset</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} st
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={1}
                    value={pitchSemitones}
                    onChange={(e) => setPitchSemitones(parseInt(e.target.value, 10))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">Energy</span>
                    <span className="font-mono tabular-nums font-semibold text-indigo-500">
                      {energy}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    step={5}
                    value={energy}
                    onChange={(e) => setEnergy(parseInt(e.target.value, 10))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Optional Custom Audition Script + Variation Count */}
            <div className="space-y-2.5 pt-3 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="voice-design-script"
                  className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400"
                >
                  Audition Script (Optional)
                </label>
                <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-950 p-0.5 rounded-lg border border-zinc-200 dark:border-zinc-800">
                  {[2, 3].map((cnt) => (
                    <button
                      key={cnt}
                      type="button"
                      onClick={() => setVariationCount(cnt)}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors whitespace-nowrap ${
                        variationCount === cnt
                          ? 'bg-indigo-600 text-white'
                          : 'text-zinc-500 dark:text-zinc-400'
                      }`}
                    >
                      {cnt} Variations
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                id="voice-design-script"
                rows={2}
                value={customScript}
                onChange={(e) => setCustomScript(e.target.value)}
                placeholder="Leave blank to let AI write an in-character script, or paste English / Telugu / Tanglish lines here..."
                className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 resize-none"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2.5 px-3.5 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-300 text-xs sm:text-sm">
                <AlertCircle size={16} className="shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* Primary Generate Voice CTA */}
            <button
              type="button"
              onClick={() => handleGenerateVoices()}
              disabled={isGenerating || !description.trim()}
              className="w-full min-h-[50px] px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm sm:text-base font-bold flex items-center justify-center gap-2.5 shadow-sm transition-colors whitespace-nowrap"
            >
              {isGenerating ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  <span>Designing &amp; Synthesizing {variationCount} Voices...</span>
                </>
              ) : (
                <>
                  <Sparkles size={18} />
                  <span>
                    {variations.length > 0
                      ? `Regenerate ${variationCount} Voice Variations`
                      : `Generate Voice (${variationCount} Variations)`}
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Right Column (7 cols): Voice Preview Cards + Refinement + My Voice Library */}
          <div className="lg:col-span-7 space-y-5">
            {variations.length === 0 ? (
              <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-8 sm:p-12 text-center space-y-4">
                <div className="inline-flex w-14 h-14 rounded-2xl bg-indigo-600/15 border border-indigo-500/30 text-indigo-500 items-center justify-center">
                  <Wand2 size={26} />
                </div>
                <div className="max-w-md mx-auto space-y-1.5">
                  <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                    Ready to Design Your Custom AI Voice
                  </h3>
                  <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">
                    Describe your ideal voice on the left, tune age, pitch, emotion, or Telugu accent, and click <strong>Generate Voice</strong> to synthesize real playable variations ready to save and download.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Refinement Toolbar */}
                <div className="bg-white dark:bg-zinc-900/90 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-2.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                    Refine &amp; Regenerate All:
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {REFINEMENT_CHIPS.map((chip) => (
                      <button
                        key={chip.label}
                        type="button"
                        disabled={isGenerating}
                        onClick={() => {
                          const refined = `${description.trim()} ${chip.suffix}`;
                          setDescription(refined);
                          handleGenerateVoices(refined);
                        }}
                        className="min-h-[34px] px-3 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-950 hover:bg-indigo-600/15 text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 text-xs font-medium transition-colors whitespace-nowrap"
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Generated Variation Preview Cards */}
                {variations.map((variation) => {
                  const isThisActive = activeVariationId === variation.id;
                  const isThisPlaying = isThisActive && playback.isPlaying;
                  const isThisPaused = isThisActive && playback.isPaused;
                  const isThisRegen = regeneratingId === variation.id;
                  const savedAsName = savedIds[variation.id];

                  return (
                    <div
                      key={variation.id}
                      className={`bg-white dark:bg-zinc-900/95 border rounded-2xl p-4 sm:p-5 space-y-4 transition-colors ${
                        isThisPlaying
                          ? 'border-indigo-500'
                          : 'border-zinc-200 dark:border-zinc-800'
                      }`}
                    >
                      {/* Variation Header & Save to Library */}
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0 flex-1">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block">
                            {variation.variationLabel}
                          </span>
                          <input
                            type="text"
                            value={variation.suggestedName}
                            onChange={(e) =>
                              setVariations((prev) =>
                                prev.map((item) =>
                                  item.id === variation.id
                                    ? { ...item, suggestedName: e.target.value }
                                    : item
                                )
                              )
                            }
                            aria-label="Edit voice name"
                            className="w-full max-w-xs bg-transparent border-b border-transparent hover:border-zinc-300 dark:hover:border-zinc-700 focus:border-indigo-500 text-lg font-bold text-zinc-900 dark:text-white focus:outline-none pb-0.5"
                          />
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                            <span>{variation.gender}</span>
                            <span aria-hidden="true">·</span>
                            <span>{variation.pitch} Pitch</span>
                            <span aria-hidden="true">·</span>
                            <span>{variation.ageImpression}</span>
                            <span aria-hidden="true">·</span>
                            <span>{variation.emotion}</span>
                            <span aria-hidden="true">·</span>
                            <span>Timbre: {variation.baseVoice}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {savedAsName ? (
                            <button
                              type="button"
                              onClick={() => onOpenInAudioStudio(savedAsName)}
                              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-emerald-600/15 text-emerald-600 dark:text-emerald-300 border border-emerald-500/35 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Check size={14} />
                              <span>Saved · Open in Studio</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleSaveVariation(variation)}
                              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-800 hover:bg-rose-600 dark:hover:bg-rose-600 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
                            >
                              <Heart size={14} />
                              <span>Save to My Library</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Style Direction & Editable Audition Line */}
                      <div className="space-y-2">
                        <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                          {variation.stylePrompt}
                        </p>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            type="text"
                            value={variation.sampleText}
                            onChange={(e) =>
                              setVariations((prev) =>
                                prev.map((item) =>
                                  item.id === variation.id
                                    ? { ...item, sampleText: e.target.value }
                                    : item
                                )
                              )
                            }
                            aria-label="Edit variation script line"
                            className="flex-1 min-h-[40px] bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 text-xs sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                          />
                          <button
                            type="button"
                            onClick={() => handleRegenerateVariation(variation)}
                            disabled={isThisRegen || isGenerating || !variation.sampleText.trim()}
                            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 disabled:opacity-50 text-zinc-800 dark:text-zinc-200 text-xs font-semibold flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap"
                          >
                            {isThisRegen ? (
                              <Loader2 size={13} className="animate-spin" />
                            ) : (
                              <RefreshCw size={13} />
                            )}
                            <span>{isThisRegen ? 'Regenerating...' : 'Regenerate Take'}</span>
                          </button>
                        </div>
                      </div>

                      {/* Waveform Preview Bar */}
                      {variation.audioBase64 ? (
                        <>
                          <div className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
                            <div className="h-20 relative flex items-center justify-center px-3">
                              {isThisPlaying ? (
                                <div className="w-full h-full relative">
                                  <AudioVisualizer
                                    isPlaying={true}
                                    color="#6366f1"
                                    analyser={controllerRef.current?.getAnalyser() || null}
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handlePlayPauseVariation(variation)}
                                    className="absolute right-1.5 top-1/2 -translate-y-1/2 min-h-[36px] px-3 py-1 rounded-lg bg-zinc-900/90 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                                  >
                                    <Pause size={12} className="fill-current" />
                                    <span>Pause</span>
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                                  <button
                                    type="button"
                                    onClick={() => handlePlayPauseVariation(variation)}
                                    className="min-h-[40px] px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
                                  >
                                    <Play size={13} className="fill-current" />
                                    <span>{isThisPaused ? 'Resume Preview' : 'Play Variation'}</span>
                                  </button>
                                  {isThisActive && (
                                    <button
                                      type="button"
                                      onClick={() => handleReplayVariation(variation)}
                                      className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300"
                                      title="Replay"
                                    >
                                      <RotateCcw size={13} />
                                    </button>
                                  )}
                                  {isThisActive && playback.duration > 0 && (
                                    <span className="font-mono tabular-nums text-[11px]">
                                      {formatStudioTime(playback.currentTime)} / {formatStudioTime(playback.duration)}
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Download to Phone Card — shown only when audio generation succeeded */}
                          <GeneratedAudioResultCard
                            audioBase64={variation.audioBase64}
                            voiceName={variation.suggestedName}
                            language={language}
                            accent={accent}
                            styleLabel={variation.styleCategory || emotion}
                            isGamingMode={
                              Boolean(variation.styleCategory?.toLowerCase().includes('gaming')) ||
                              description.toLowerCase().includes('gaming')
                            }
                            speed={speed}
                            pitchSemitones={pitchSemitones}
                            durationSec={isThisActive ? playback.duration : 0}
                            currentTimeSec={isThisActive ? playback.currentTime : 0}
                            isPlaying={isThisPlaying}
                            isPaused={isThisPaused}
                            onPlayPause={() => handlePlayPauseVariation(variation)}
                            onReplay={() => handleReplayVariation(variation)}
                            compact
                          />
                        </>
                      ) : (
                        <div className="flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-600 dark:text-red-300">
                          <span>{variation.audioError || 'Audio generation unavailable for this take.'}</span>
                          <button
                            type="button"
                            onClick={() => handleRegenerateVariation(variation)}
                            className="px-2.5 py-1 rounded-lg bg-red-600 text-white text-xs font-semibold whitespace-nowrap"
                          >
                            Retry
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* My Voice Library Quick Access Panel */}
            <div className="bg-white dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Heart size={16} className="text-rose-500 fill-rose-500" />
                  <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
                    My Voice Library ({mySavedLibraryVoices.length})
                  </h3>
                </div>
                <span className="text-xs text-zinc-500 dark:text-zinc-400">
                  Saved custom &amp; favorite voices
                </span>
              </div>

              {mySavedLibraryVoices.length === 0 ? (
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Save any generated voice variation above to build your personal voice library.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {mySavedLibraryVoices.slice(0, 6).map((v) => {
                    const isFav = favoriteNames.includes(v.name);
                    return (
                      <div
                        key={v.name}
                        className="flex items-center justify-between gap-2 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800"
                      >
                        <div className="min-w-0">
                          <p className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate">
                            {v.name}
                          </p>
                          <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                            {v.analysis.gender} · {v.pitch}
                            {v.language ? ` · ${v.language}` : ''}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onToggleFavorite(v.name)}
                            className={`min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg border transition-colors ${
                              isFav
                                ? 'bg-rose-500/10 border-rose-500/30 text-rose-500'
                                : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-400'
                            }`}
                            aria-label={`Toggle favorite for ${v.name}`}
                          >
                            <Heart size={13} className={isFav ? 'fill-current' : ''} />
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenInAudioStudio(v.name)}
                            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1 whitespace-nowrap"
                          >
                            <AudioLines size={12} />
                            <span>Studio</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoiceDesignStudioView;
