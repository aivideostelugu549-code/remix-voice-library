/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Mp3Encoder } from '@breezystack/lamejs';

export interface StudioPlaybackState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTime: number;
  duration: number;
}

export type AudioExportFormat = 'mp3' | 'wav';

export type Mp3QualityKbps = 128 | 192 | 320;
export type WavSampleRateHz = 24000 | 44100 | 48000;

export interface AudioExportOptions {
  base64Audio: string;
  format: AudioExportFormat;
  mp3Kbps?: Mp3QualityKbps;
  wavSampleRate?: WavSampleRateHz;
  speed?: number;
  pitchSemitones?: number;
  onProgress?: (percent: number, stage: string) => void;
}

export interface MeaningfulFilenameParams {
  voiceName?: string;
  language?: string;
  accent?: string;
  style?: string;
  isGamingMode?: boolean;
  isCloned?: boolean;
  format: AudioExportFormat;
}

const CLIENT_IMPERSONATION_PATTERNS: RegExp[] = [
  /\b(celebrity|celebrities|famous actor|politician|president|prime minister)\b/i,
  /\b(impersonate|imitate|mimic|sound\s+just\s+like|deepfake|without\s+permission|unauthorized)\b/i,
  /\b(mahesh babu|allu arjun|prabhas|pawan kalyan|chiranjeevi|jr ntr|ram charan|nani|vijay deverakonda|narendra modi|donald trump|joe biden|elon musk|taylor swift|virat kohli|amitabh bachchan|rajinikanth|shah rukh khan|salman khan)\b/i,
];

export function checkClientEthicalVoicePolicy(text: string): string | null {
  if (!text) return null;
  for (const pattern of CLIENT_IMPERSONATION_PATTERNS) {
    if (pattern.test(text)) {
      return "Ethical Voice Policy: Imitating celebrities, public figures, or cloning someone else's voice without permission is prohibited.";
    }
  }
  return null;
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

function sanitizeSegment(raw: string): string {
  return raw
    .replace(/[^a-zA-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

export function buildMeaningfulAudioFilename({
  voiceName,
  language,
  accent,
  style,
  isGamingMode,
  isCloned,
  format,
}: MeaningfulFilenameParams): string {
  const parts: string[] = [];

  if (language && language !== 'English') {
    const cleanLang = sanitizeSegment(language);
    if (cleanLang) parts.push(cleanLang);
  }

  if (accent && accent !== 'Standard') {
    const cleanAccent = sanitizeSegment(accent);
    if (cleanAccent && !parts.includes(cleanAccent)) parts.push(cleanAccent);
  }

  if (style) {
    const lowerStyle = style.toLowerCase();
    if (lowerStyle.includes('funny')) parts.push('Funny');
    else if (lowerStyle.includes('sarcastic')) parts.push('Sarcastic');
    else if (lowerStyle.includes('excited') || lowerStyle.includes('hyped')) parts.push('Excited');
    else if (lowerStyle.includes('dramatic') || lowerStyle.includes('cinematic')) parts.push('Cinematic');
    else if (lowerStyle.includes('soft')) parts.push('Soft');
    else if (lowerStyle.includes('friendly')) parts.push('Friendly');
    else if (lowerStyle.includes('energetic')) parts.push('Energetic');
    else {
      const cleanStyle = sanitizeSegment(style.split(' ')[0]);
      if (cleanStyle) parts.push(cleanStyle);
    }
  }

  if (isGamingMode) {
    parts.push('Gaming');
  }

  if (isCloned) {
    parts.push('Cloned');
  }

  if (voiceName) {
    const cleanName = sanitizeSegment(voiceName);
    if (cleanName && !parts.some((p) => p.toLowerCase() === cleanName.toLowerCase())) {
      parts.push(cleanName);
    }
  }

  if (parts.length === 0) {
    parts.push('AI_Studio');
  }

  parts.push('Voice');
  const stem = parts.join('_').slice(0, 64).replace(/_+$/g, '');
  return `${stem}.${format}`;
}

export function sanitizeUserFilename(input: string, format: AudioExportFormat): string {
  const withoutExt = input.replace(/\.(mp3|wav)$/i, '').trim();
  const safe = sanitizeSegment(withoutExt) || 'AI_Studio_Voice';
  return `${safe}.${format}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function encodeAudioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const length = buffer.length;
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = length * blockAlign;
  const arrayBuffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(arrayBuffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  const channels: Float32Array[] = [];
  for (let ch = 0; ch < numChannels; ch++) {
    channels.push(buffer.getChannelData(ch));
  }

  let offset = 44;
  for (let i = 0; i < length; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, channels[ch][i]));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

async function renderBufferWithDsp(
  base64Audio: string,
  targetSampleRate: number,
  speed: number,
  pitchSemitones: number
): Promise<AudioBuffer> {
  const clampedSpeed = Math.max(0.5, Math.min(2.0, speed));
  const clampedPitch = Math.max(-12, Math.min(12, pitchSemitones));

  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const decodeCtx = new AudioCtx();
  try {
    const rawBuffer = base64ToArrayBuffer(base64Audio);
    const decoded = await decodeCtx.decodeAudioData(rawBuffer.slice(0));

    const pitchRatio = Math.pow(2, clampedPitch / 12);
    const effectiveRate = clampedSpeed * pitchRatio;
    const durationSec = decoded.duration / effectiveRate;
    const outputLength = Math.max(1, Math.ceil(durationSec * targetSampleRate));

    const offlineCtx = new OfflineAudioContext(
      decoded.numberOfChannels,
      outputLength,
      targetSampleRate
    );
    const source = offlineCtx.createBufferSource();
    source.buffer = decoded;
    source.playbackRate.value = clampedSpeed;
    if ('detune' in source) {
      source.detune.value = clampedPitch * 100;
    }
    source.connect(offlineCtx.destination);
    source.start(0);

    return await offlineCtx.startRendering();
  } finally {
    await decodeCtx.close().catch(() => {});
  }
}

function float32ToInt16(float32: Float32Array): Int16Array {
  const int16 = new Int16Array(float32.length);
  for (let i = 0; i < float32.length; i++) {
    const s = Math.max(-1, Math.min(1, float32[i]));
    int16[i] = s < 0 ? Math.round(s * 0x8000) : Math.round(s * 0x7fff);
  }
  return int16;
}

async function encodeAudioBufferToMp3Blob(
  buffer: AudioBuffer,
  kbps: Mp3QualityKbps,
  onProgress?: (percent: number, stage: string) => void
): Promise<Blob> {
  const channels = Math.min(2, buffer.numberOfChannels);
  const sampleRate = buffer.sampleRate;
  const encoder = new Mp3Encoder(channels, sampleRate, kbps);

  const leftInt16 = float32ToInt16(buffer.getChannelData(0));
  const rightInt16 = channels > 1 ? float32ToInt16(buffer.getChannelData(1)) : undefined;

  const blockSize = 1152;
  const mp3Data: BlobPart[] = [];
  const total = leftInt16.length;

  for (let i = 0; i < total; i += blockSize) {
    const leftChunk = leftInt16.subarray(i, i + blockSize);
    const encoded = rightInt16
      ? encoder.encodeBuffer(leftChunk, rightInt16.subarray(i, i + blockSize))
      : encoder.encodeBuffer(leftChunk);

    if (encoded.length > 0) {
      mp3Data.push(new Uint8Array(encoded));
    }

    if ((i / blockSize) % 24 === 0) {
      const pct = Math.min(94, 30 + Math.round((i / total) * 64));
      onProgress?.(pct, `Encoding MP3 (${kbps} kbps)...`);
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }

  const flushed = encoder.flush();
  if (flushed.length > 0) {
    mp3Data.push(new Uint8Array(flushed));
  }

  onProgress?.(98, 'Finalizing MP3 file...');
  return new Blob(mp3Data, { type: 'audio/mpeg' });
}

export async function renderProcessedWavBlob(
  base64Audio: string,
  speed: number,
  pitchSemitones: number,
  wavSampleRate: WavSampleRateHz = 24000
): Promise<Blob> {
  const rendered = await renderBufferWithDsp(base64Audio, wavSampleRate, speed, pitchSemitones);
  return encodeAudioBufferToWavBlob(rendered);
}

export async function encodeAudioForExport({
  base64Audio,
  format,
  mp3Kbps = 192,
  wavSampleRate = 44100,
  speed = 1.0,
  pitchSemitones = 0,
  onProgress,
}: AudioExportOptions): Promise<Blob> {
  onProgress?.(12, 'Decoding & mastering audio...');
  const targetRate = format === 'mp3' ? 44100 : wavSampleRate;
  const rendered = await renderBufferWithDsp(base64Audio, targetRate, speed, pitchSemitones);

  if (format === 'mp3') {
    onProgress?.(30, `Encoding MP3 (${mp3Kbps} kbps)...`);
    return encodeAudioBufferToMp3Blob(rendered, mp3Kbps, onProgress);
  }

  onProgress?.(75, `Writing WAV (${(wavSampleRate / 1000).toFixed(1)} kHz)...`);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const wavBlob = encodeAudioBufferToWavBlob(rendered);
  onProgress?.(98, 'Finalizing WAV file...');
  return wavBlob;
}

export function isSystemFilePickerSupported(): boolean {
  return typeof window !== 'undefined' && 'showSaveFilePicker' in window;
}

export function isAndroidDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /Android/i.test(navigator.userAgent);
}

export function canShareAudioFiles(): boolean {
  if (typeof navigator === 'undefined' || typeof navigator.canShare !== 'function') return false;
  try {
    const probe = new File([new Uint8Array([0])], 'probe.mp3', { type: 'audio/mpeg' });
    return navigator.canShare({ files: [probe] });
  } catch {
    return false;
  }
}

export async function saveBlobToPhoneOrDevice(
  blob: Blob,
  filename: string,
  useSystemPicker = false
): Promise<{ status: 'saved' | 'cancelled'; method: 'picker' | 'download'; filename: string }> {
  const mimeType = blob.type || (filename.endsWith('.mp3') ? 'audio/mpeg' : 'audio/wav');

  if (useSystemPicker && isSystemFilePickerSupported()) {
    try {
      const picker = (window as unknown as {
        showSaveFilePicker: (opts: any) => Promise<any>;
      }).showSaveFilePicker;
      const ext = filename.endsWith('.mp3') ? '.mp3' : '.wav';
      const handle = await picker({
        suggestedName: filename,
        types: [
          {
            description: ext === '.mp3' ? 'MP3 Audio' : 'WAV Audio',
            accept: { [mimeType]: [ext] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return { status: 'saved', method: 'picker', filename: handle.name || filename };
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return { status: 'cancelled', method: 'picker', filename };
      }
      // SecurityError in cross-origin iframes or unsupported mobile WebView -> fall back to browser download
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Keep blob URL alive for 60s so Android DownloadManager can finish copying the file
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 60000);

  return { status: 'saved', method: 'download', filename };
}

export async function shareAudioBlobViaSystemSheet(
  blob: Blob,
  filename: string
): Promise<'shared' | 'cancelled'> {
  const file = new File([blob], filename, {
    type: blob.type || (filename.endsWith('.mp3') ? 'audio/mpeg' : 'audio/wav'),
  });
  try {
    await navigator.share({
      title: filename,
      files: [file],
    });
    return 'shared';
  } catch (err: any) {
    if (err?.name === 'AbortError') return 'cancelled';
    throw err;
  }
}

export class StudioAudioController {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private source: AudioBufferSourceNode | null = null;
  private buffer: AudioBuffer | null = null;

  private speed = 1.0;
  private pitchSemitones = 0;

  private isPlaying = false;
  private isPaused = false;
  private offsetSec = 0;
  private startedAtCtxTime = 0;
  private rafId: number | null = null;
  private onStateChange: (state: StudioPlaybackState) => void;

  constructor(onStateChange: (state: StudioPlaybackState) => void) {
    this.onStateChange = onStateChange;
  }

  private ensureContext(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.78;
      this.analyser.connect(this.ctx.destination);
    }
    return this.ctx;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  public async loadBase64(base64Audio: string): Promise<number> {
    this.stop();
    const ctx = this.ensureContext();
    const raw = base64ToArrayBuffer(base64Audio);
    this.buffer = await ctx.decodeAudioData(raw.slice(0));
    this.offsetSec = 0;
    this.isPaused = false;
    this.isPlaying = false;
    this.emit();
    return this.buffer.duration;
  }

  public hasAudio(): boolean {
    return this.buffer !== null;
  }

  public setSpeed(nextSpeed: number): void {
    const clamped = Math.max(0.6, Math.min(1.6, nextSpeed));
    if (this.isPlaying) {
      this.offsetSec = this.computeCurrentBufferPos();
      this.startedAtCtxTime = this.ctx ? this.ctx.currentTime : 0;
      if (this.source) {
        this.source.playbackRate.value = clamped;
      }
    }
    this.speed = clamped;
  }

  public setPitch(semitones: number): void {
    const clamped = Math.max(-6, Math.min(6, semitones));
    if (this.isPlaying) {
      this.offsetSec = this.computeCurrentBufferPos();
      this.startedAtCtxTime = this.ctx ? this.ctx.currentTime : 0;
      if (this.source && 'detune' in this.source) {
        this.source.detune.value = clamped * 100;
      }
    }
    this.pitchSemitones = clamped;
  }

  private getEffectiveRate(): number {
    return this.speed * Math.pow(2, this.pitchSemitones / 12);
  }

  private computeCurrentBufferPos(): number {
    if (!this.buffer) return 0;
    if (!this.isPlaying || !this.ctx) return this.offsetSec;
    const elapsedReal = Math.max(0, this.ctx.currentTime - this.startedAtCtxTime);
    return Math.min(this.buffer.duration, this.offsetSec + elapsedReal * this.getEffectiveRate());
  }

  private clearSource(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.source) {
      this.source.onended = null;
      try {
        this.source.stop();
        this.source.disconnect();
      } catch {
        // Ignore already stopped
      }
      this.source = null;
    }
  }

  public async play(fromStart = false): Promise<void> {
    if (!this.buffer) return;
    const ctx = this.ensureContext();
    if (ctx.state === 'suspended') {
      await ctx.resume().catch(() => {});
    }

    if (fromStart || this.offsetSec >= this.buffer.duration - 0.02) {
      this.offsetSec = 0;
    }

    this.clearSource();

    const source = ctx.createBufferSource();
    source.buffer = this.buffer;
    source.playbackRate.value = this.speed;
    if ('detune' in source) {
      source.detune.value = this.pitchSemitones * 100;
    }

    if (this.analyser) {
      source.connect(this.analyser);
    } else {
      source.connect(ctx.destination);
    }

    this.source = source;
    this.startedAtCtxTime = ctx.currentTime;
    this.isPlaying = true;
    this.isPaused = false;

    source.onended = () => {
      if (this.source !== source) return;
      this.clearSource();
      this.isPlaying = false;
      this.isPaused = false;
      this.offsetSec = 0;
      this.emit();
    };

    source.start(0, this.offsetSec);
    this.startProgressLoop();
    this.emit();
  }

  public pause(): void {
    if (!this.isPlaying) return;
    this.offsetSec = this.computeCurrentBufferPos();
    this.clearSource();
    this.isPlaying = false;
    this.isPaused = true;
    this.emit();
  }

  public async replay(): Promise<void> {
    await this.play(true);
  }

  public stop(): void {
    this.clearSource();
    this.isPlaying = false;
    this.isPaused = false;
    this.offsetSec = 0;
    this.emit();
  }

  public async seek(targetTimeSec: number): Promise<void> {
    if (!this.buffer) return;
    const clamped = Math.max(0, Math.min(this.buffer.duration - 0.02, targetTimeSec));
    const wasPlaying = this.isPlaying;
    this.clearSource();
    this.offsetSec = clamped;
    if (wasPlaying) {
      await this.play(false);
    } else {
      this.isPaused = clamped > 0;
      this.emit();
    }
  }

  private startProgressLoop(): void {
    const tick = () => {
      if (!this.isPlaying) return;
      this.emit();
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  private emit(): void {
    const duration = this.buffer ? this.buffer.duration : 0;
    const currentTime = this.isPlaying ? this.computeCurrentBufferPos() : this.offsetSec;
    this.onStateChange({
      isPlaying: this.isPlaying,
      isPaused: this.isPaused,
      currentTime,
      duration,
    });
  }

  public dispose(): void {
    this.clearSource();
    this.buffer = null;
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
      this.analyser = null;
    }
  }
}

export function formatStudioTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const totalSec = Math.floor(seconds);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
