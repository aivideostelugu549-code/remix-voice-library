/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ImportedFileKind, ImportedFileRecord } from '../types';

const DB_NAME = 'remix_voice_file_vault_v1';
const DB_VERSION = 1;
const STORE_NAME = 'files';

const MAX_AUDIO_BYTES = 15 * 1024 * 1024; // 15 MB
const MAX_SCRIPT_BYTES = 1024 * 1024; // 1 MB

export const ACCEPTED_AUDIO_EXTENSIONS = [
  '.mp3',
  '.wav',
  '.m4a',
  '.aac',
  '.ogg',
  '.opus',
  '.webm',
  '.flac',
  '.3gp',
];

export const ACCEPTED_SCRIPT_EXTENSIONS = ['.txt', '.md', '.srt', '.vtt', '.csv'];

export const AUDIO_FILE_ACCEPT = [
  ...ACCEPTED_AUDIO_EXTENSIONS,
  'audio/*',
  'audio/mpeg',
  'audio/wav',
  'audio/mp4',
  'audio/x-m4a',
  'audio/aac',
  'audio/ogg',
  'audio/webm',
  'audio/flac',
].join(',');

export const SCRIPT_FILE_ACCEPT = [
  ...ACCEPTED_SCRIPT_EXTENSIONS,
  'text/plain',
  'text/markdown',
  'text/csv',
].join(',');

export const ALL_SUPPORTED_FILE_ACCEPT = `${AUDIO_FILE_ACCEPT},${SCRIPT_FILE_ACCEPT}`;

// In-memory fallback if IndexedDB is blocked in strict private browsing
const memoryFallbackStore = new Map<string, ImportedFileRecord>();

function openVaultDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
      request.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export function detectFileKind(fileName: string, mimeType: string): ImportedFileKind | null {
  const lowerName = fileName.toLowerCase();
  const lowerMime = (mimeType || '').toLowerCase();

  if (
    lowerMime.startsWith('audio/') ||
    ACCEPTED_AUDIO_EXTENSIONS.some((ext) => lowerName.endsWith(ext))
  ) {
    return 'audio';
  }

  if (
    lowerMime.startsWith('text/') ||
    ACCEPTED_SCRIPT_EXTENSIONS.some((ext) => lowerName.endsWith(ext))
  ) {
    return 'script';
  }

  return null;
}

export function detectFileFormatLabel(fileName: string, mimeType: string): string {
  const extMatch = fileName.toLowerCase().match(/\.([a-z0-9]+)$/);
  if (extMatch && extMatch[1]) {
    const ext = extMatch[1].toUpperCase();
    return ext === 'WEBM' ? 'WebM' : ext;
  }
  const mime = (mimeType || '').toLowerCase();
  if (mime.includes('mpeg') || mime.includes('mp3')) return 'MP3';
  if (mime.includes('wav')) return 'WAV';
  if (mime.includes('m4a') || mime.includes('mp4')) return 'M4A';
  if (mime.includes('aac')) return 'AAC';
  if (mime.includes('ogg')) return 'OGG';
  if (mime.includes('webm')) return 'WebM';
  if (mime.includes('flac')) return 'FLAC';
  if (mime.includes('plain')) return 'TXT';
  if (mime.includes('markdown')) return 'MD';
  return 'FILE';
}

export function normalizeCloneAudioMimeType(mimeType: string, fileName: string): string {
  const clean = (mimeType || '').split(';')[0].trim().toLowerCase();
  const lowerName = fileName.toLowerCase();

  if (clean === 'audio/x-m4a' || clean === 'audio/m4a' || lowerName.endsWith('.m4a')) {
    return 'audio/mp4';
  }
  if (clean === 'audio/mp3' || lowerName.endsWith('.mp3')) {
    return 'audio/mpeg';
  }
  if (lowerName.endsWith('.wav')) return 'audio/wav';
  if (lowerName.endsWith('.aac')) return 'audio/aac';
  if (lowerName.endsWith('.ogg') || lowerName.endsWith('.opus')) return 'audio/ogg';
  if (lowerName.endsWith('.flac')) return 'audio/flac';
  if (lowerName.endsWith('.webm')) return 'audio/webm';
  if (clean.startsWith('audio/')) return clean;
  return 'audio/wav';
}

function estimateFundamentalHz(buffer: AudioBuffer): number | null {
  try {
    const data = buffer.getChannelData(0);
    const sampleRate = buffer.sampleRate;
    const size = Math.min(data.length, sampleRate * 2);
    if (size < 1024) return null;

    let rms = 0;
    for (let i = 0; i < size; i++) rms += data[i] * data[i];
    rms = Math.sqrt(rms / size);
    if (rms < 0.008) return null;

    const minLag = Math.floor(sampleRate / 340);
    const maxLag = Math.floor(sampleRate / 65);
    let bestLag = -1;
    let bestCorr = 0;

    for (let lag = minLag; lag <= maxLag; lag++) {
      let corr = 0;
      const limit = Math.min(size - lag, 4096);
      for (let i = 0; i < limit; i++) {
        corr += data[i] * data[i + lag];
      }
      if (corr > bestCorr) {
        bestCorr = corr;
        bestLag = lag;
      }
    }

    if (bestLag <= 0) return null;
    const hz = Math.round(sampleRate / bestLag);
    return hz >= 65 && hz <= 340 ? hz : null;
  } catch {
    return null;
  }
}

export async function inspectAudioBlobMetadata(
  blob: Blob
): Promise<{ durationSec?: number; estimatedHz?: number | null }> {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    try {
      const arrayBuf = await blob.arrayBuffer();
      const decoded = await ctx.decodeAudioData(arrayBuf.slice(0));
      return {
        durationSec: Number(decoded.duration.toFixed(1)),
        estimatedHz: estimateFundamentalHz(decoded),
      };
    } finally {
      await ctx.close().catch(() => {});
    }
  } catch {
    // Fallback to HTMLAudioElement duration metadata if WebAudio codec decode is unsupported
    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const audio = new Audio();
      const cleanup = () => {
        audio.src = '';
        URL.revokeObjectURL(url);
      };
      audio.onloadedmetadata = () => {
        const dur = Number.isFinite(audio.duration) ? Number(audio.duration.toFixed(1)) : undefined;
        cleanup();
        resolve({ durationSec: dur, estimatedHz: null });
      };
      audio.onerror = () => {
        cleanup();
        resolve({});
      };
      audio.src = url;
    });
  }
}

export function blobToBase64String(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      if (commaIdx === -1) {
        reject(new Error('Failed to encode audio file for processing.'));
        return;
      }
      resolve(result.slice(commaIdx + 1));
    };
    reader.onerror = () => reject(new Error('Failed to read selected audio file.'));
    reader.readAsDataURL(blob);
  });
}

export async function listVaultFiles(): Promise<ImportedFileRecord[]> {
  const db = await openVaultDb();
  if (!db) {
    return Array.from(memoryFallbackStore.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const rows = (Array.isArray(req.result) ? req.result : []) as ImportedFileRecord[];
        rows.sort((a, b) => b.createdAt - a.createdAt);
        db.close();
        resolve(rows);
      };
      req.onerror = () => {
        db.close();
        resolve(Array.from(memoryFallbackStore.values()).sort((a, b) => b.createdAt - a.createdAt));
      };
    } catch {
      db.close();
      resolve(Array.from(memoryFallbackStore.values()).sort((a, b) => b.createdAt - a.createdAt));
    }
  });
}

async function putVaultRecord(record: ImportedFileRecord): Promise<void> {
  memoryFallbackStore.set(record.id, record);
  const db = await openVaultDb();
  if (!db) return;

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(record);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('Failed to save file locally.'));
    };
  });
}

export async function saveFilesToVault(
  files: File[],
  requiredKind?: ImportedFileKind
): Promise<{ saved: ImportedFileRecord[]; rejected: string[] }> {
  const saved: ImportedFileRecord[] = [];
  const rejected: string[] = [];

  for (const file of files) {
    const detectedKind = detectFileKind(file.name, file.type);
    if (!detectedKind) {
      rejected.push(`${file.name}: unsupported format.`);
      continue;
    }
    if (requiredKind && detectedKind !== requiredKind) {
      rejected.push(
        `${file.name}: expected ${requiredKind === 'audio' ? 'an audio file (MP3, WAV, M4A...)' : 'a text script file (.txt, .md, .srt)'}.`
      );
      continue;
    }

    if (detectedKind === 'audio' && file.size > MAX_AUDIO_BYTES) {
      rejected.push(`${file.name}: exceeds 15 MB audio limit.`);
      continue;
    }
    if (detectedKind === 'script' && file.size > MAX_SCRIPT_BYTES) {
      rejected.push(`${file.name}: exceeds 1 MB script limit.`);
      continue;
    }
    if (file.size === 0) {
      rejected.push(`${file.name}: file is empty.`);
      continue;
    }

    const formatLabel = detectFileFormatLabel(file.name, file.type);
    const id =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `file_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    if (detectedKind === 'audio') {
      const meta = await inspectAudioBlobMetadata(file);
      const record: ImportedFileRecord = {
        id,
        name: file.name,
        size: file.size,
        mimeType: normalizeCloneAudioMimeType(file.type, file.name),
        formatLabel,
        kind: 'audio',
        createdAt: Date.now(),
        durationSec: meta.durationSec,
        estimatedHz: meta.estimatedHz ?? null,
        blob: file,
      };
      await putVaultRecord(record);
      saved.push(record);
    } else {
      const rawText = (await file.text()).replace(/^\uFEFF/, '').trim();
      if (!rawText) {
        rejected.push(`${file.name}: text file contains no readable script.`);
        continue;
      }
      const record: ImportedFileRecord = {
        id,
        name: file.name,
        size: file.size,
        mimeType: file.type || 'text/plain',
        formatLabel,
        kind: 'script',
        createdAt: Date.now(),
        textContent: rawText,
        blob: file,
      };
      await putVaultRecord(record);
      saved.push(record);
    }
  }

  return { saved, rejected };
}

export async function deleteVaultFile(id: string): Promise<void> {
  memoryFallbackStore.delete(id);
  const db = await openVaultDb();
  if (!db) return;

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('Failed to delete file.'));
    };
  });
}

export async function clearVaultFiles(): Promise<void> {
  memoryFallbackStore.clear();
  const db = await openVaultDb();
  if (!db) return;

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('Failed to clear imported files.'));
    };
  });
}

export function canUseOpenFilePicker(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return 'showOpenFilePicker' in window && window.self === window.top;
  } catch {
    return false;
  }
}

export async function openSystemOpenFilePicker(
  mode: 'all' | 'audio' | 'script'
): Promise<File[] | 'fallback' | 'cancelled'> {
  if (typeof window === 'undefined' || !('showOpenFilePicker' in window)) {
    return 'fallback';
  }

  try {
    const picker = (
      window as unknown as {
        showOpenFilePicker: (options: any) => Promise<any[]>;
      }
    ).showOpenFilePicker;

    const types: any[] = [];
    if (mode === 'audio' || mode === 'all') {
      types.push({
        description: 'Audio Files (MP3, WAV, M4A, AAC, OGG, WebM, FLAC)',
        accept: {
          'audio/*': ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.opus', '.webm', '.flac', '.3gp'],
        },
      });
    }
    if (mode === 'script' || mode === 'all') {
      types.push({
        description: 'TTS Script Files (TXT, MD, SRT, VTT)',
        accept: {
          'text/plain': ['.txt', '.md', '.srt', '.vtt', '.csv'],
        },
      });
    }

    const handles = await picker({
      multiple: true,
      types,
      excludeAcceptAllOption: false,
    });

    const files = await Promise.all(handles.map((h) => h.getFile()));
    return files;
  } catch (err: any) {
    if (err?.name === 'AbortError') return 'cancelled';
    // SecurityError inside cross-origin iframe or unsupported mobile WebView -> fallback to <input type="file">
    return 'fallback';
  }
}
