/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ConversationBgmPreset,
  ConversationCharacter,
  ConversationLine,
  ConversationSfxCue,
} from '../types';
import { base64ToArrayBuffer, encodeAudioBufferToWavBlob } from './audioStudioPlayer';

export interface ConversationTimelineSegment {
  lineId: string;
  characterId: string;
  characterName: string;
  startSec: number;
  endSec: number;
}

export interface CharacterStemTrack {
  characterId: string;
  characterName: string;
  voiceName: string;
  lineCount: number;
  durationSec: number;
  audioBase64: string;
}

export interface MixedConversationResult {
  masterBase64: string;
  durationSec: number;
  segments: ConversationTimelineSegment[];
  characterTracks: CharacterStemTrack[];
}

export interface MixConversationOptions {
  lines: ConversationLine[];
  characters: ConversationCharacter[];
  pauseDurationSec: number;
  speed: number;
  pitchSemitones: number;
  bgmPreset: ConversationBgmPreset;
  bgmVolume: number; // 0 to 0.6
  sfxVolume: number; // 0 to 1.0
}

const TARGET_SAMPLE_RATE = 24000;

async function blobToBase64(blob: Blob): Promise<string> {
  const buffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return window.btoa(binary);
}

async function decodeAndProcessLineBuffer(
  baseCtx: AudioContext,
  base64Audio: string,
  speed: number,
  pitchSemitones: number
): Promise<AudioBuffer> {
  const raw = base64ToArrayBuffer(base64Audio);
  const decoded = await baseCtx.decodeAudioData(raw.slice(0));

  const clampedSpeed = Math.max(0.65, Math.min(1.55, speed));
  const clampedPitch = Math.max(-6, Math.min(6, pitchSemitones));
  const pitchRatio = Math.pow(2, clampedPitch / 12);
  const effectiveRate = clampedSpeed * pitchRatio;
  const outputDuration = Math.max(0.05, decoded.duration / effectiveRate);
  const outputFrames = Math.max(1, Math.ceil(outputDuration * TARGET_SAMPLE_RATE));

  const offline = new OfflineAudioContext(1, outputFrames, TARGET_SAMPLE_RATE);
  const src = offline.createBufferSource();
  src.buffer = decoded;
  src.playbackRate.value = clampedSpeed;
  if ('detune' in src) {
    src.detune.value = clampedPitch * 100;
  }
  src.connect(offline.destination);
  src.start(0);
  return await offline.startRendering();
}

function scheduleBgmBed(
  ctx: OfflineAudioContext,
  destination: AudioNode,
  preset: ConversationBgmPreset,
  totalDuration: number,
  volume: number
) {
  if (preset === 'none' || volume <= 0.005 || totalDuration <= 0.2) return;

  const masterBgmGain = ctx.createGain();
  masterBgmGain.gain.setValueAtTime(0.0001, 0);
  masterBgmGain.gain.linearRampToValueAtTime(volume * 0.28, Math.min(1.0, totalDuration * 0.15));
  masterBgmGain.gain.setValueAtTime(volume * 0.28, Math.max(0.1, totalDuration - 1.2));
  masterBgmGain.gain.linearRampToValueAtTime(0.0001, totalDuration);
  masterBgmGain.connect(destination);

  if (preset === 'horror-drone') {
    const sub = ctx.createOscillator();
    const fifth = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    sub.type = 'sawtooth';
    sub.frequency.value = 55; // A1 eerie bass
    fifth.type = 'triangle';
    fifth.frequency.value = 81.5; // slightly detuned tritone/fifth tension

    filter.type = 'lowpass';
    filter.frequency.value = 260;

    lfo.type = 'sine';
    lfo.frequency.value = 0.25;
    lfoGain.gain.value = 95;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);

    sub.connect(filter);
    fifth.connect(filter);
    filter.connect(masterBgmGain);

    sub.start(0);
    fifth.start(0);
    lfo.start(0);
    sub.stop(totalDuration);
    fifth.stop(totalDuration);
    lfo.stop(totalDuration);
    return;
  }

  // Chord progressions for Lo-Fi Podcast, Gaming Synth, or Comedy Groove
  const progressions: Record<Exclude<ConversationBgmPreset, 'none' | 'horror-drone'>, { freqs: number[]; stepSec: number; wave: OscillatorType; cutoff: number }> = {
    'podcast-lofi': {
      freqs: [220, 261.63, 329.63, 246.94], // Am -> C -> Em -> Bm feel
      stepSec: 2.0,
      wave: 'sine',
      cutoff: 900,
    },
    'gaming-synth': {
      freqs: [146.83, 174.61, 196.0, 220.0], // Energetic driving synth
      stepSec: 0.75,
      wave: 'triangle',
      cutoff: 1400,
    },
    'comedy-groove': {
      freqs: [261.63, 329.63, 293.66, 392.0], // Bouncy bright pizzicato feel
      stepSec: 0.85,
      wave: 'triangle',
      cutoff: 1200,
    },
  };

  const cfg = progressions[preset];
  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = cfg.cutoff;
  filter.connect(masterBgmGain);

  let cursor = 0;
  let idx = 0;
  while (cursor < totalDuration - 0.1) {
    const rootFreq = cfg.freqs[idx % cfg.freqs.length];
    const osc = ctx.createOscillator();
    const noteGain = ctx.createGain();
    osc.type = cfg.wave;
    osc.frequency.setValueAtTime(rootFreq, cursor);

    const noteDur = Math.min(cfg.stepSec * 0.9, totalDuration - cursor);
    noteGain.gain.setValueAtTime(0.0001, cursor);
    noteGain.gain.linearRampToValueAtTime(0.65, cursor + 0.04);
    noteGain.gain.exponentialRampToValueAtTime(0.02, cursor + Math.max(0.08, noteDur));

    osc.connect(noteGain);
    noteGain.connect(filter);
    osc.start(cursor);
    osc.stop(cursor + noteDur + 0.02);

    if (preset === 'gaming-synth' || preset === 'comedy-groove') {
      // Subtle upbeat pulse harmony
      const harmony = ctx.createOscillator();
      const harmGain = ctx.createGain();
      harmony.type = 'sine';
      harmony.frequency.setValueAtTime(rootFreq * 1.5, cursor + cfg.stepSec * 0.45);
      harmGain.gain.setValueAtTime(0.0001, cursor + cfg.stepSec * 0.45);
      harmGain.gain.linearRampToValueAtTime(0.32, cursor + cfg.stepSec * 0.48);
      harmGain.gain.exponentialRampToValueAtTime(0.01, Math.min(totalDuration, cursor + cfg.stepSec * 0.88));
      harmony.connect(harmGain);
      harmGain.connect(filter);
      if (cursor + cfg.stepSec * 0.45 < totalDuration - 0.05) {
        harmony.start(cursor + cfg.stepSec * 0.45);
        harmony.stop(Math.min(totalDuration, cursor + cfg.stepSec * 0.92));
      }
    }

    cursor += cfg.stepSec;
    idx += 1;
  }
}

function scheduleSfxCue(
  ctx: OfflineAudioContext,
  destination: AudioNode,
  cue: ConversationSfxCue,
  atSec: number,
  volume: number
) {
  if (cue === 'none' || volume <= 0.005) return;

  const gain = ctx.createGain();
  gain.connect(destination);
  const peak = Math.min(0.65, volume * 0.45);

  if (cue === 'comedy-pop') {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, atSec);
    osc.frequency.exponentialRampToValueAtTime(760, atSec + 0.09);
    gain.gain.setValueAtTime(peak, atSec);
    gain.gain.exponentialRampToValueAtTime(0.001, atSec + 0.14);
    osc.connect(gain);
    osc.start(atSec);
    osc.stop(atSec + 0.16);
  } else if (cue === 'gaming-ding') {
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    osc1.type = 'triangle';
    osc2.type = 'sine';
    osc1.frequency.setValueAtTime(880, atSec);
    osc2.frequency.setValueAtTime(1318.5, atSec + 0.06);
    gain.gain.setValueAtTime(peak * 0.85, atSec);
    gain.gain.exponentialRampToValueAtTime(0.001, atSec + 0.32);
    osc1.connect(gain);
    osc2.connect(gain);
    osc1.start(atSec);
    osc1.stop(atSec + 0.15);
    osc2.start(atSec + 0.06);
    osc2.stop(atSec + 0.34);
  } else if (cue === 'horror-sting') {
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc2.type = 'sawtooth';
    osc1.frequency.setValueAtTime(110, atSec);
    osc2.frequency.setValueAtTime(155.56, atSec); // minor tritone sting
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1800, atSec);
    filter.frequency.exponentialRampToValueAtTime(220, atSec + 0.75);
    gain.gain.setValueAtTime(peak, atSec);
    gain.gain.exponentialRampToValueAtTime(0.001, atSec + 0.8);
    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    osc1.start(atSec);
    osc2.start(atSec);
    osc1.stop(atSec + 0.82);
    osc2.stop(atSec + 0.82);
  } else if (cue === 'transition-whoosh') {
    const noiseLen = Math.floor(TARGET_SAMPLE_RATE * 0.35);
    const noiseBuf = ctx.createBuffer(1, noiseLen, TARGET_SAMPLE_RATE);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < noiseLen; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(250, atSec);
    bp.frequency.exponentialRampToValueAtTime(2200, atSec + 0.16);
    bp.frequency.exponentialRampToValueAtTime(400, atSec + 0.34);
    gain.gain.setValueAtTime(0.001, atSec);
    gain.gain.linearRampToValueAtTime(peak * 0.75, atSec + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.001, atSec + 0.35);
    noise.connect(bp);
    bp.connect(gain);
    noise.start(atSec);
    noise.stop(atSec + 0.36);
  } else if (cue === 'applause-swell') {
    const noiseLen = Math.floor(TARGET_SAMPLE_RATE * 0.65);
    const noiseBuf = ctx.createBuffer(1, noiseLen, TARGET_SAMPLE_RATE);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < noiseLen; i++) {
      // Modulated filtered bursts simulating short studio cheer/clap swell
      const burst = Math.sin((i / TARGET_SAMPLE_RATE) * 58) > 0 ? 1 : 0.4;
      data[i] = (Math.random() * 2 - 1) * burst;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1350;
    bp.Q.value = 0.7;
    gain.gain.setValueAtTime(0.001, atSec);
    gain.gain.linearRampToValueAtTime(peak * 0.65, atSec + 0.15);
    gain.gain.exponentialRampToValueAtTime(0.001, atSec + 0.64);
    noise.connect(bp);
    bp.connect(gain);
    noise.start(atSec);
    noise.stop(atSec + 0.65);
  }
}

export async function mixAndConcatenateConversation({
  lines,
  characters,
  pauseDurationSec,
  speed,
  pitchSemitones,
  bgmPreset,
  bgmVolume,
  sfxVolume,
}: MixConversationOptions): Promise<MixedConversationResult> {
  const readyLines = lines.filter((l) => l.status === 'ready' && Boolean(l.audioBase64));
  if (readyLines.length === 0) {
    throw new Error('Generate at least one dialogue line before mixing the conversation.');
  }

  const charMap = new Map<string, ConversationCharacter>();
  characters.forEach((c) => charMap.set(c.id, c));

  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const decodeCtx = new AudioCtx();

  try {
    const processedClips: Array<{
      line: ConversationLine;
      character: ConversationCharacter;
      buffer: AudioBuffer;
    }> = [];

    for (const line of readyLines) {
      if (!line.audioBase64) continue;
      const char = charMap.get(line.characterId) || {
        id: line.characterId,
        name: 'Speaker',
        role: 'Character',
        voiceName: 'Puck',
      };
      const buffer = await decodeAndProcessLineBuffer(
        decodeCtx,
        line.audioBase64,
        speed,
        pitchSemitones
      );
      processedClips.push({ line, character: char, buffer });
    }

    const pauseGap = Math.max(0.05, Math.min(2.5, pauseDurationSec));
    const leadInSec = bgmPreset !== 'none' ? 0.35 : 0.08;
    const tailOutSec = bgmPreset !== 'none' ? 0.65 : 0.15;

    const segments: ConversationTimelineSegment[] = [];
    let cursor = leadInSec;

    const scheduledItems = processedClips.map((item, idx) => {
      const startSec = cursor;
      const dur = item.buffer.duration;
      const endSec = startSec + dur;
      segments.push({
        lineId: item.line.id,
        characterId: item.character.id,
        characterName: item.character.name,
        startSec,
        endSec,
      });

      const sfxExtra = item.line.sfxCue !== 'none' ? 0.12 : 0;
      cursor = endSec + (idx < processedClips.length - 1 ? pauseGap + sfxExtra : 0);
      return { ...item, startSec, endSec };
    });

    const totalDuration = Math.max(0.4, cursor + tailOutSec);
    const totalFrames = Math.ceil(totalDuration * TARGET_SAMPLE_RATE);
    const masterOffline = new OfflineAudioContext(1, totalFrames, TARGET_SAMPLE_RATE);

    // Master dialogue + optional BGM + SFX mix
    const voiceBus = masterOffline.createGain();
    voiceBus.gain.value = 1.0;
    voiceBus.connect(masterOffline.destination);

    scheduledItems.forEach((item) => {
      const src = masterOffline.createBufferSource();
      src.buffer = item.buffer;
      src.connect(voiceBus);
      src.start(item.startSec);

      if (item.line.sfxCue && item.line.sfxCue !== 'none') {
        const cueAt = Math.max(0, item.startSec - 0.08);
        scheduleSfxCue(masterOffline, masterOffline.destination, item.line.sfxCue, cueAt, sfxVolume);
      }
    });

    scheduleBgmBed(masterOffline, masterOffline.destination, bgmPreset, totalDuration, bgmVolume);

    const renderedMaster = await masterOffline.startRendering();
    const masterWavBlob = encodeAudioBufferToWavBlob(renderedMaster);
    const masterBase64 = await blobToBase64(masterWavBlob);

    // Also build individual character dialogue tracks for stem exports
    const clipsByChar = new Map<string, typeof scheduledItems>();
    scheduledItems.forEach((item) => {
      const arr = clipsByChar.get(item.character.id) || [];
      arr.push(item);
      clipsByChar.set(item.character.id, arr);
    });

    const characterTracks: CharacterStemTrack[] = [];
    for (const [charId, charClips] of clipsByChar.entries()) {
      const stemPause = 0.35;
      let stemDur = 0.08;
      charClips.forEach((c, idx) => {
        stemDur += c.buffer.duration + (idx < charClips.length - 1 ? stemPause : 0);
      });
      stemDur += 0.1;

      const stemCtx = new OfflineAudioContext(
        1,
        Math.max(1, Math.ceil(stemDur * TARGET_SAMPLE_RATE)),
        TARGET_SAMPLE_RATE
      );
      let stemCursor = 0.08;
      charClips.forEach((c, idx) => {
        const src = stemCtx.createBufferSource();
        src.buffer = c.buffer;
        src.connect(stemCtx.destination);
        src.start(stemCursor);
        stemCursor += c.buffer.duration + (idx < charClips.length - 1 ? stemPause : 0);
      });

      const stemRendered = await stemCtx.startRendering();
      const stemBlob = encodeAudioBufferToWavBlob(stemRendered);
      const stemBase64 = await blobToBase64(stemBlob);
      const repChar = charClips[0].character;
      characterTracks.push({
        characterId: charId,
        characterName: repChar.name,
        voiceName: repChar.voiceName,
        lineCount: charClips.length,
        durationSec: stemRendered.duration,
        audioBase64: stemBase64,
      });
    }

    return {
      masterBase64,
      durationSec: renderedMaster.duration,
      segments,
      characterTracks,
    };
  } finally {
    await decodeCtx.close().catch(() => {});
  }
}
