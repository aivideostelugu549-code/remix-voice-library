/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Voice } from '../types';

let sharedAudioCtx: AudioContext | null = null;
let sharedAnalyser: AnalyserNode | null = null;
let activeCleanup: (() => void) | null = null;
let activeVoiceName: string | null = null;
let activePlayToken = 0;

function getAudioContext(): AudioContext {
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    sharedAudioCtx = new AudioCtx();
    sharedAnalyser = sharedAudioCtx.createAnalyser();
    sharedAnalyser.fftSize = 256;
    sharedAnalyser.smoothingTimeConstant = 0.75;
    sharedAnalyser.connect(sharedAudioCtx.destination);
  }
  return sharedAudioCtx;
}

export function unlockAudioContext(): void {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  } catch {
    // Ignore if Web Audio is unavailable
  }
}

export function getVoiceAnalyser(): AnalyserNode | null {
  return sharedAnalyser;
}

export function stopVoiceSample(onlyVoiceName?: string): void {
  if (onlyVoiceName && activeVoiceName !== onlyVoiceName) {
    return;
  }
  activePlayToken++;
  activeVoiceName = null;
  if (activeCleanup) {
    activeCleanup();
    activeCleanup = null;
  }
}

function hashVoiceName(name: string): number {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return hash;
}

export interface VoiceTechnicalProfile {
  fundamentalHz: number;
  formant1Hz: number;
  formant2Hz: number;
  cadence: string;
  texture: string;
  sampleDurationSec: number;
  sampleFormat: string;
  brightnessScore: number;
  warmthScore: number;
  energyScore: number;
}

export function getBaseFrequency(voice: Voice): number {
  const pitchText = `${voice.analysis.pitch} ${voice.pitch}`.toLowerCase();
  const isFemale = voice.analysis.gender.toLowerCase() === 'female';
  const hash = hashVoiceName(voice.name);
  const detuneOffset = ((hash % 17) - 8) * 2.2;

  let base = isFemale ? 220 : 132;
  if (pitchText.includes('high') && !pitchText.includes('medium')) {
    base = isFemale ? 275 : 175;
  } else if (pitchText.includes('medium-high') || pitchText.includes('higher')) {
    base = isFemale ? 245 : 158;
  } else if (pitchText.includes('medium-low') || pitchText.includes('lower middle')) {
    base = isFemale ? 195 : 122;
  } else if (pitchText.includes('low')) {
    base = isFemale ? 175 : 104;
  }

  return Math.max(85, base + detuneOffset);
}

export function getVoiceTechnicalProfile(voice: Voice): VoiceTechnicalProfile {
  const fundamentalHz = Math.round(getBaseFrequency(voice));
  const traits = `${voice.characteristics.join(' ')} ${voice.analysis.characteristics.join(' ')} ${voice.stylePrompt || ''}`.toLowerCase();
  const isFemale = voice.analysis.gender.toLowerCase() === 'female';
  const isBreathy = traits.includes('breathy') || traits.includes('soft') || traits.includes('gentle');
  const isGravelly = traits.includes('gravelly') || traits.includes('firm') || traits.includes('deep');
  const isUpbeat = traits.includes('upbeat') || traits.includes('bright') || traits.includes('energetic') || traits.includes('lively') || traits.includes('enthusiastic');
  const isWarm = traits.includes('warm') || traits.includes('smooth') || traits.includes('calm') || traits.includes('easy-going');

  const formant1Hz = isFemale ? 720 : 510;
  const formant2Hz = isFemale ? 1850 : 1320;
  const cadence = isUpbeat ? 'Rising / Dynamic' : 'Measured / Balanced';
  const texture = isBreathy
    ? 'Airy & Soft-Filtered'
    : isGravelly
    ? 'Textured & Sub-Harmonic'
    : isWarm
    ? 'Smooth & Resonant'
    : 'Crisp & Articulate';

  const hash = hashVoiceName(voice.name);
  const brightnessScore = Math.min(
    96,
    Math.max(24, Math.round(((fundamentalHz - 85) / 210) * 55 + (isUpbeat ? 28 : 14) + (isBreathy ? -6 : 6) + (hash % 7)))
  );
  const warmthScore = Math.min(
    96,
    Math.max(28, Math.round((isWarm ? 78 : 54) + (isFemale ? -4 : 12) + (isGravelly ? 10 : 0) + (hash % 6)))
  );
  const energyScore = Math.min(
    96,
    Math.max(25, Math.round((isUpbeat ? 82 : 48) + (traits.includes('confident') || traits.includes('forward') ? 10 : 0) + (hash % 8)))
  );

  return {
    fundamentalHz,
    formant1Hz,
    formant2Hz,
    cadence,
    texture,
    sampleDurationSec: voice.isCustom ? 2.5 : isUpbeat ? 1.34 : 1.5,
    sampleFormat: voice.isCustom ? '24 kHz 16-bit PCM WAV' : 'Web Audio Formant Synth',
    brightnessScore,
    warmthScore,
    energyScore,
  };
}

function createNoiseBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(1, length, sampleRate);
  const data = buffer.getChannelData(0);
  let lastOut = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    // Gentle pink-ish smoothing for breathiness
    lastOut = (lastOut + 0.08 * white) / 1.08;
    data[i] = lastOut * 2.2;
  }
  return buffer;
}

async function playDataUrlBuffer(
  ctx: AudioContext,
  analyser: AnalyserNode,
  dataUrl: string,
  token: number,
  onEnded: () => void
): Promise<boolean> {
  try {
    const res = await fetch(dataUrl);
    const arrayBuffer = await res.arrayBuffer();
    if (token !== activePlayToken) return true;

    const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
    if (token !== activePlayToken) return true;

    const source = ctx.createBufferSource();
    const gain = ctx.createGain();
    source.buffer = audioBuffer;
    gain.gain.value = 0.95;

    source.connect(gain);
    gain.connect(analyser);

    let finished = false;
    const cleanup = () => {
      if (finished) return;
      finished = true;
      try {
        source.stop();
        source.disconnect();
        gain.disconnect();
      } catch {
        // Ignore already stopped
      }
    };

    activeCleanup = cleanup;
    source.onended = () => {
      if (!finished) {
        cleanup();
        if (token === activePlayToken) {
          activeCleanup = null;
          activeVoiceName = null;
          onEnded();
        }
      }
    };

    source.start(0);
    return true;
  } catch {
    return false;
  }
}

export async function playVoiceSample(voice: Voice, onEnded: () => void): Promise<void> {
  stopVoiceSample();
  const token = ++activePlayToken;
  activeVoiceName = voice.name;

  const ctx = getAudioContext();
  if (ctx.state === 'suspended') {
    await ctx.resume().catch(() => {});
  }
  if (token !== activePlayToken || !sharedAnalyser) return;

  // Custom voices created in Voice Design Studio store their synthesized WAV as a data URL
  if (voice.isCustom && voice.audioSampleUrl.startsWith('data:audio/')) {
    const played = await playDataUrlBuffer(ctx, sharedAnalyser, voice.audioSampleUrl, token, onEnded);
    if (played || token !== activePlayToken) return;
  }

  // Synthesize a short, characteristic multi-syllable vocal sample via Web Audio API
  const baseFreq = getBaseFrequency(voice);
  const hash = hashVoiceName(voice.name);
  const traits = `${voice.characteristics.join(' ')} ${voice.analysis.characteristics.join(' ')}`.toLowerCase();
  const isFemale = voice.analysis.gender.toLowerCase() === 'female';
  const isBreathy = traits.includes('breathy') || traits.includes('soft') || traits.includes('gentle');
  const isGravelly = traits.includes('gravelly') || traits.includes('firm');
  const isUpbeat = traits.includes('upbeat') || traits.includes('bright') || traits.includes('energetic') || traits.includes('lively');

  const now = ctx.currentTime;
  // Three-syllable natural speaking cadence
  const syllables = isUpbeat
    ? [
        { start: 0.0, dur: 0.24, ratio: 1.0, endRatio: 1.12, f1: isFemale ? 740 : 540, f2: isFemale ? 1850 : 1320 },
        { start: 0.29, dur: 0.28, ratio: 1.16, endRatio: 1.24, f1: isFemale ? 620 : 470, f2: isFemale ? 2050 : 1480 },
        { start: 0.64, dur: 0.56, ratio: 1.18, endRatio: 0.98, f1: isFemale ? 790 : 580, f2: isFemale ? 1720 : 1220 },
      ]
    : [
        { start: 0.0, dur: 0.28, ratio: 1.04, endRatio: 0.98, f1: isFemale ? 680 : 490, f2: isFemale ? 1760 : 1240 },
        { start: 0.35, dur: 0.32, ratio: 1.08, endRatio: 1.02, f1: isFemale ? 560 : 430, f2: isFemale ? 1920 : 1380 },
        { start: 0.74, dur: 0.62, ratio: 1.0, endRatio: 0.84, f1: isFemale ? 720 : 510, f2: isFemale ? 1640 : 1140 },
      ];

  const totalDuration = syllables[syllables.length - 1].start + syllables[syllables.length - 1].dur + 0.14;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.45, now);
  masterGain.connect(sharedAnalyser);

  const primaryOsc = ctx.createOscillator();
  primaryOsc.type = isFemale ? 'triangle' : 'sawtooth';

  const harmonicOsc = ctx.createOscillator();
  harmonicOsc.type = isGravelly ? 'sawtooth' : 'sine';

  // Vibrato LFO for natural vocal warmth
  const vibratoLfo = ctx.createOscillator();
  const vibratoGain = ctx.createGain();
  vibratoLfo.frequency.value = 4.6 + (hash % 4) * 0.4;
  vibratoGain.gain.value = isUpbeat ? 4.2 : 2.8;
  vibratoLfo.connect(vibratoGain);
  vibratoGain.connect(primaryOsc.frequency);
  vibratoGain.connect(harmonicOsc.frequency);

  // Dual formant bandpass filters to give vowel-like vocal resonance
  const formant1 = ctx.createBiquadFilter();
  formant1.type = 'bandpass';
  formant1.Q.value = isFemale ? 4.2 : 3.6;

  const formant2 = ctx.createBiquadFilter();
  formant2.type = 'bandpass';
  formant2.Q.value = 5.0;

  const warmthFilter = ctx.createBiquadFilter();
  warmthFilter.type = 'lowpass';
  warmthFilter.frequency.value = isFemale ? 3400 : 2400;

  const primaryMix = ctx.createGain();
  primaryMix.gain.value = 0.75;

  const harmonicMix = ctx.createGain();
  harmonicMix.gain.value = isGravelly ? 0.35 : 0.25;

  const envelopeGain = ctx.createGain();
  envelopeGain.gain.setValueAtTime(0.0001, now);

  primaryOsc.connect(primaryMix);
  harmonicOsc.connect(harmonicMix);
  primaryMix.connect(formant1);
  primaryMix.connect(formant2);
  harmonicMix.connect(formant1);
  formant1.connect(warmthFilter);
  formant2.connect(warmthFilter);
  warmthFilter.connect(envelopeGain);
  envelopeGain.connect(masterGain);

  // Optional breathiness / vocal texture layer
  let noiseSource: AudioBufferSourceNode | null = null;
  let noiseGain: GainNode | null = null;
  if (isBreathy || isGravelly) {
    noiseSource = ctx.createBufferSource();
    noiseSource.buffer = createNoiseBuffer(ctx, totalDuration);
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.value = isBreathy ? 2200 : 900;
    noiseFilter.Q.value = 1.8;
    noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.0001, now);
    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(masterGain);
  }

  for (const syl of syllables) {
    const t0 = now + syl.start;
    const tEnd = t0 + syl.dur;
    const attack = Math.min(0.045, syl.dur * 0.25);
    const release = Math.min(0.075, syl.dur * 0.3);

    primaryOsc.frequency.setValueAtTime(baseFreq * syl.ratio, t0);
    primaryOsc.frequency.exponentialRampToValueAtTime(baseFreq * syl.endRatio, tEnd);

    harmonicOsc.frequency.setValueAtTime(baseFreq * (isGravelly ? 0.5 : 2) * syl.ratio, t0);
    harmonicOsc.frequency.exponentialRampToValueAtTime(baseFreq * (isGravelly ? 0.5 : 2) * syl.endRatio, tEnd);

    formant1.frequency.setValueAtTime(syl.f1, t0);
    formant2.frequency.setValueAtTime(syl.f2, t0);

    envelopeGain.gain.setValueAtTime(0.0001, t0);
    envelopeGain.gain.linearRampToValueAtTime(0.85, t0 + attack);
    envelopeGain.gain.setValueAtTime(0.75, Math.max(t0 + attack, tEnd - release));
    envelopeGain.gain.exponentialRampToValueAtTime(0.0001, tEnd);

    if (noiseGain) {
      const nLevel = isBreathy ? 0.14 : 0.08;
      noiseGain.gain.setValueAtTime(0.0001, t0);
      noiseGain.gain.linearRampToValueAtTime(nLevel, t0 + attack);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, tEnd);
    }
  }

  let finished = false;
  let endTimer = 0;

  const cleanup = () => {
    if (finished) return;
    finished = true;
    window.clearTimeout(endTimer);
    try {
      primaryOsc.stop();
      harmonicOsc.stop();
      vibratoLfo.stop();
      noiseSource?.stop();
    } catch {
      // Ignore already stopped
    }
    try {
      primaryOsc.disconnect();
      harmonicOsc.disconnect();
      vibratoLfo.disconnect();
      noiseSource?.disconnect();
      masterGain.disconnect();
    } catch {
      // Ignore disconnect errors
    }
  };

  activeCleanup = cleanup;

  primaryOsc.start(now);
  harmonicOsc.start(now);
  vibratoLfo.start(now);
  noiseSource?.start(now);

  primaryOsc.stop(now + totalDuration);
  harmonicOsc.stop(now + totalDuration);
  vibratoLfo.stop(now + totalDuration);
  noiseSource?.stop(now + totalDuration);

  endTimer = window.setTimeout(() => {
    if (!finished) {
      cleanup();
      if (token === activePlayToken) {
        activeCleanup = null;
        activeVoiceName = null;
        onEnded();
      }
    }
  }, totalDuration * 1000 + 40);
}
